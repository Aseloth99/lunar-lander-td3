"""Hız ölçümü: algoritma / ağ boyutu / batch için ortam-adımı-başına-saniye (adım/sn).

Kullanım:
  python3 bench.py --algo sac --net 400,300 --batch 256 --threads 1 --steps 600
Birden çok süreci paralel ölçmek için scripts/bench_all.sh kullanılır.
Çıktı tek satırlık JSON'dur (results/bench.jsonl'a eklenir).
"""
import _deps  # noqa: F401

import argparse
import json
import os
import time

p = argparse.ArgumentParser()
p.add_argument("--algo", choices=["sac", "td3", "ppo"], required=True)
p.add_argument("--net", default="400,300", help="virgülle ayrılmış gizli katman boyutları")
p.add_argument("--batch", type=int, default=256)
p.add_argument("--threads", type=int, default=1)
p.add_argument("--steps", type=int, default=600)
p.add_argument("--device", default="cpu")
p.add_argument("--tag", default="")
args = p.parse_args()

import torch
torch.set_num_threads(args.threads)

import gymnasium as gym
from stable_baselines3 import PPO, SAC, TD3
from stable_baselines3.common.env_util import make_vec_env

net = [int(x) for x in args.net.split(",")]
mk = lambda: gym.make("LunarLander-v3", continuous=True)  # noqa: E731

if args.algo == "ppo":
    env = make_vec_env(mk, n_envs=16)
    model = PPO("MlpPolicy", env, n_steps=1024, batch_size=args.batch, gae_lambda=0.98, gamma=0.999,
                n_epochs=4, ent_coef=0.01, device=args.device, seed=0, verbose=0,
                policy_kwargs=dict(net_arch=dict(pi=net, vf=net)))
    model.learn(16 * 1024)  # ısınma (bir tam toplama+güncelleme turu)
    n = 16 * 1024
    t0 = time.perf_counter()
    model.learn(n, reset_num_timesteps=False)
else:
    env = mk()
    cls = SAC if args.algo == "sac" else TD3
    model = cls("MlpPolicy", env, learning_starts=100, batch_size=args.batch, device=args.device, seed=0,
                verbose=0, policy_kwargs=dict(net_arch=net))
    model.learn(150)  # ısınma: rastgele toplama + ilk birkaç güncelleme
    n = args.steps
    t0 = time.perf_counter()
    model.learn(n, reset_num_timesteps=False)
dt = time.perf_counter() - t0
row = dict(tag=args.tag, algo=args.algo, net=args.net, batch=args.batch, threads=args.threads,
           device=args.device, steps=n, seconds=round(dt, 2), sps=round(n / dt, 1))
print(json.dumps(row, ensure_ascii=False))
os.makedirs("results", exist_ok=True)
with open("results/bench.jsonl", "a", encoding="utf-8") as f:
    f.write(json.dumps(row, ensure_ascii=False) + "\n")
