#!/usr/bin/env bash
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
python3 scripts/prep_v3long.py
[ -f logs/queue.log ] && mv logs/queue.log logs/queue_asama4.log
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
bash scripts/start_queue.sh jobs/stage5_td3.txt 5
pkill -f "status.py --loop"; sleep 1
bash scripts/start_status.sh
sleep 20
pgrep -af "train.py" | cut -c1-120
grep -h "devam" logs/td3_v3long_seed*.log 2>/dev/null
