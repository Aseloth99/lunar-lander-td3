#!/usr/bin/env bash
# Kuyruğu ve eğitim süreçlerini durdurur. Eğitimler resume/ kayıtlarından --resume ile devam ettirilebilir.
pkill -f queue_runner.py
pkill -f "train.py --algo"
pkill -f "tune.py"
echo "durduruldu"
