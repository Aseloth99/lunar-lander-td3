#!/usr/bin/env bash
# SON ADIM (bir kez): ayarları dondur, TÜM koşuları test tohumlarında değerlendir, test raporu + video üret.
# Önkoşul: results/ana_sonuc_secimi.json (select_main.py ile, yalnızca doğrulama verisinden).
set -e
cd "$(dirname "${BASH_SOURCE[0]}")/.."
[ -f results/ana_sonuc_secimi.json ] || { echo "önce select_main.py"; exit 1; }
# (dikkat: "GROUPS" bash'te ayrılmış bir değişkendir; kullanmayın)
RUN_GROUPS="sac/fuel2x sac/zoo ppo/tuned td3/tuned ppo/zoo td3/zoo"
if [ ! -f FROZEN ]; then
  { echo "Donduruldu: $(date '+%F %T')"; echo "Ana sonuç seçimi: $(cat results/ana_sonuc_secimi.json | tr -d '\n')"; } > FROZEN
fi
for g in $RUN_GROUPS; do
  for d in runs/$g/seed*; do
    [ -f "$d/DONE" ] || { echo "[atla, bitmemiş] $d"; continue; }
    if [ -f "$d/test_summary.json" ]; then echo "[zaten test edildi] $d"; continue; fi
    python3 evaluate.py --run-dir "$d" --split test --ckpt best | python3 -c "
import sys, json; s = json.loads(sys.stdin.read()); print(f\"$d: ort {s['mean']:.1f} başarı {100*s['success']:.0f}% çakılma {100*s['crash']:.0f}% en kötü {s['min']:.1f}\")"
  done
done
python3 report.py --split test --groups sac/fuel2x sac/zoo ppo/tuned td3/tuned ppo/zoo --out results/final_test --no-curves
python3 report.py --split test --groups $RUN_GROUPS --out results/final_test_tum --table-only > /dev/null
MAIN=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi.json'))['main'])")
python3 make_video.py --algo "${MAIN%/*}" --tag "${MAIN#*/}" --episodes 4 --out results/en_iyi_ajan
echo "TEST TAMAMLANDI"
