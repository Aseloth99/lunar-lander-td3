#!/usr/bin/env bash
# Aşama 2'yi arka planda başlatır (bu betik biter, iş sürer) ve başladığını doğrular.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
if pgrep -f "scripts/stage2.sh" > /dev/null; then echo "aşama 2 zaten çalışıyor"; exit 0; fi
setsid nohup bash scripts/stage2.sh > logs/stage2.log 2>&1 < /dev/null &
echo "aşama 2 başlatıldı (pid $!)"
sleep 12
echo "--- süreçler ---"
pgrep -af "stage2.sh|train.py|tune.py" | cut -c1-140
echo "--- uptime ---"; uptime
bash scripts/start_status.sh
