"""300 ortalama fiziksel olarak mümkün mü? (doğrulama tohumları 5000-5049; öğrenen ajan kullanılmaz)

Basit "intihar freni" kontrolcüsü: motor kapalı serbest düşüş, araç belirli bir yüksekliğin altına inip hâlâ
düşüyorsa ana motor TAM güç; bacak yere değince motor kapalı. Her bölüm için ateşleme yüksekliği taranır ve
çakılmadan inen en az yakıtlı çözüm alınır. Yan motor kullanılmaz (yatay sapma düzeltilmez) -> bu, dikey frenleme
için gereken ANA MOTOR yakıtının kabaca alt sınırını verir.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import numpy as np  # noqa: E402
import common  # noqa: E402


def shp(s):
    return (-100 * np.sqrt(s[0] ** 2 + s[1] ** 2) - 100 * np.sqrt(s[2] ** 2 + s[3] ** 2) - 100 * abs(s[4])
            + 10 * s[6] + 10 * s[7])


def episode(env, seed, h):
    obs, _ = env.reset(seed=int(seed))
    s0 = shp(obs)
    fuel, ret = 0.0, 0.0
    while True:
        touching = obs[6] > 0 or obs[7] > 0
        fire = (obs[1] < h) and (obs[3] < 0) and not touching
        a = np.array([1.0 if fire else -1.0, 0.0], dtype=np.float32)
        obs, r, term, trunc, _ = env.step(a)
        ret += r
        if term or trunc:
            return dict(ret=ret, fuel=fuel, landed=term and r >= 99.9, s0=s0)
        fuel += 0.30 if fire else 0.0


env = common.make_env()
best = []
for sd in common.VAL_SEEDS[:50]:
    cands = [episode(env, sd, h) for h in np.linspace(0.05, 1.2, 47)]
    ok = [c for c in cands if c["landed"]]
    if ok:
        b = min(ok, key=lambda c: c["fuel"])
        best.append(dict(b, ceiling=120 - b["s0"]))
f = np.array([b["fuel"] for b in best])
c = np.array([b["ceiling"] for b in best])
print(f"çakılmadan inilen bölüm: {len(best)}/50")
print(f"en az ANA MOTOR yakıtı (dikey fren): ortalama {f.mean():.1f}, medyan {np.median(f):.1f}, aralık {f.min():.1f}-{f.max():.1f}")
print(f"bu bölümlerde yakıtsız tavan ortalaması: {c.mean():.1f}")
print(f"=> kusursuz iniş + EN AZ yakıtla ulaşılabilecek ortalama ≈ {np.mean(c - f):.1f}")
print(f"   (TD3 v2b'nin ana motor yakıtı ≈ 24.7; iniş sapması kaybı ≈ 4.5)")
