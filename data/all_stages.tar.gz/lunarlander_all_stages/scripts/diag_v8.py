"""Aşama 10 tanısı (YALNIZCA test donduktan sonra; seçimde kullanılmaz): her aday için yakıt, iniş süresi, yere değme hızı
(doğrulama 5000-5099, tohum başına 100 bölüm) ve test 100000-101999'daki çakılmaların durumu.
Çıktı: ekrana (finalize_test8.sh bunu results/tani_v8.txt'ye yazar) + results/cakilma_analizi_v8.csv"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402
from crash_analysis_v5 import replay  # noqa: E402
import reward_decomposition as rd  # noqa: E402
from diag_v7 import contact_vy  # noqa: E402

CANDS = ["td3/v4big@1600k", "td3/v6brake@1600k", "td3/v6soft@800k", "sac/v9lowent@800k", "sac/v9lowent@1600k",
         "sac/v9big@800k", "sac/v9big@1600k", "sac/v10brake@800k", "sac/v10brake@1600k", "sac/v10soft@800k",
         "sac/v10soft@1600k"]


def main():
    env = common.make_env()
    rows, crashes = [], []
    for c in CANDS:
        base, suf = c.split("@")
        algo, tag = base.split("/")
        dec, vys, rets, n_crash = [], [], [], 0
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            rd.load_for_eval = lambda run_dir, a_, _c, ck=f"best_{suf}": load_for_eval(run_dir, a_, ck)
            dec += rd.decompose(d)
            act = common.policy_act_fn(load_for_eval(d, algo, f"best_{suf}"))
            vys += [contact_vy(act, s, env) for s in common.VAL_SEEDS[:50]]
            e = pd.concat([pd.read_csv(d / f"test8_best_{suf}_episodes.csv"), pd.read_csv(d / f"test8x_best_{suf}_episodes.csv")])
            rets.append(e.ret.values)
            for s in e[e.outcome == "crash"].seed:
                n_crash += 1
                crashes.append(dict(group=c, run=d.name, ep_seed=int(s), **replay(act, s, env)))
        v, r = -np.array(vys), np.concatenate(rets)
        rows.append(dict(grup=c, dogrulama_puani=np.mean([x["ret"] for x in dec]),
                         yakit=np.mean([x["fuel_main"] + x["fuel_side"] for x in dec]),
                         inis_sapmasi=np.mean([20 - x["Sfin"] for x in dec]), adim=np.mean([x["steps"] for x in dec]),
                         yere_degme_p95=np.nanpercentile(v, 95), test_ortalama=r.mean(), test_cakilma=n_crash, test_bolum=len(r)))
    print("YAKIT / İNİŞ (doğrulama 5000-5099) ve TEST 100000-101999")
    print(pd.DataFrame(rows).round(3).to_string(index=False))
    if crashes:
        cr = pd.DataFrame(crashes)
        cr.round(3).to_csv(common.ROOT / "results" / "cakilma_analizi_v8.csv", index=False)
        print(f"\nÇAKILMALAR ({len(cr)}):")
        print(cr[["group", "run", "ep_seed", "steps", "first_contact", "steps_after_contact", "legs_at_end", "angle",
                  "vx", "vy", "on_helipad"]].round(2).to_string(index=False))
    else:
        print("\nAdayların hiçbiri test 100000-101999'da çakılmadı.")


if __name__ == "__main__":
    main()
