"""Aşama 8 tanısı (YALNIZCA test donduktan sonra; seçimde kullanılmaz): her adayın yere değme hızı ve test 60000-61999'daki
çakılmaların nedeni. Çıktı: ekrana (finalize_test6.sh bunu results/yere_degme_v6.txt'ye yazar) + results/cakilma_analizi_v6.csv"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402
from crash_analysis_v5 import replay  # noqa: E402

CANDS = ["td3/v4big@800k", "td3/v4big@1600k", "td3/v6brake@800k", "td3/v6brake@1600k", "td3/v6soft@800k", "td3/v6soft@1600k"]


def contact_vy(act, seed, env):
    obs, _ = env.reset(seed=int(seed))
    prev, done = obs, False
    while not done:
        obs, r, term, trunc, _ = env.step(act(obs))
        if obs[6] > 0 or obs[7] > 0:
            return float(prev[3])
        prev, done = obs, term or trunc
    return np.nan


def main():
    env = common.make_env()
    rows, crashes = [], []
    for c in CANDS:
        base, suf = c.split("@")
        algo, tag = base.split("/")
        vys, n_crash, rets = [], 0, []
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            act = common.policy_act_fn(load_for_eval(d, algo, f"best_{suf}"))
            vys += [contact_vy(act, s, env) for s in common.TEST6_SEEDS[:50]]
            e = pd.concat([pd.read_csv(d / f"test6_best_{suf}_episodes.csv"), pd.read_csv(d / f"test6x_best_{suf}_episodes.csv")])
            rets.append(e.ret.values)
            for s in e[e.outcome == "crash"].seed:
                n_crash += 1
                crashes.append(dict(group=c, run=d.name, ep_seed=int(s), **replay(act, s, env)))
        v = -np.array(vys)
        r = np.concatenate(rets)
        rows.append(dict(grup=c, yere_degme_hizi_ortanca=np.nanmedian(v), yere_degme_hizi_p95=np.nanpercentile(v, 95),
                         yere_degme_hizi_max=np.nanmax(v), test_ortalama=r.mean(), cakilma=n_crash, bolum=len(r)))
    df = pd.DataFrame(rows).round(3)
    print("YERE DEĞME HIZI (|vy|, temastan hemen önce; tohum başına 50 test bölümü) ve TEST 60000-61999")
    print(df.to_string(index=False))
    if crashes:
        cr = pd.DataFrame(crashes)
        cr.round(3).to_csv(common.ROOT / "results" / "cakilma_analizi_v6.csv", index=False)
        print(f"\nÇAKILMALAR ({len(cr)}):")
        print(cr[["group", "run", "ep_seed", "steps", "first_contact", "steps_after_contact", "legs_at_end", "angle", "vx",
                  "vy", "out_of_screen", "on_helipad"]].round(2).to_string(index=False))
    else:
        print("\nAdayların hiçbiri test 60000-61999'da çakılmadı.")


if __name__ == "__main__":
    main()
