#!/usr/bin/env bash
# Aşama 9 SON ADIM (bir kez): sac/v9big + sac/v9lowent için 800k/1600k kontrol noktası seçimi -> bağımsız doğrulama
# (70000-71999, 2000/tohum) -> v7 kuralıyla seçim (results/secim_kurali_v7.md) -> FROZEN7 -> en yeni test (80000-81999,
# 2000/tohum) -> rapor + video + tanı + sayfa. Paralellik 6 (kullanıcı: en çok ~6 çekirdek).
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
NEW="sac/v9big sac/v9lowent"
CANDS="td3/v4big@1600k td3/v6brake@1600k sac/v4@1600k sac/v9big@800k sac/v9big@1600k sac/v9lowent@800k sac/v9lowent@1600k"
DESKTOP=<kopyalanacak_klasör>
# en çok 6 süreç: Aşama 10'un o an süren eğitimleri (kapı betiği yenilerini bekletir) kadar az paralel değerlendirme
RUN=$(pgrep -fc "lunarlander/train.py" || true)
P=$(( 6 - RUN )); if [ "$P" -lt 2 ]; then P=2; fi
echo "paralellik: $P (süren eğitim: $RUN)"
[ "$(ls runs/sac/v9big/seed*/DONE runs/sac/v9lowent/seed*/DONE 2>/dev/null | wc -l)" = 10 ] || { echo "10 koşunun hepsi bitmemiş"; exit 1; }
[ -f FROZEN7 ] && echo "UYARI: FROZEN7 zaten var (seçim önceden yapılmış); yalnızca eksik adımlar tamamlanacak"
# 1) kontrol noktası seçimi (yalnızca 5100-5599): 800k (400k-800k) ve 1600k (800k-1.6M)
for g in $NEW; do for d in runs/$g/seed*; do
  [ -f "$d/best_policy_800k.pt" ] || echo "$d 800k 400000 800000"
  [ -f "$d/best_policy_1600k.pt" ] || echo "$d 1600k 800000 1600000"
done; done | xargs -r -P $P -L 1 bash -c 'python3 reselect.py --run-dir $0 --suffix $1 --min-step $2 --max-step $3 >> logs/reselect_v7.log 2>&1'
# 2) bağımsız doğrulama 70000-71999 (bütün adaylar, 2000 bölüm/tohum)
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | \
  xargs -P $P -L 1 bash -c '[ -f $0/val8_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split val8 --ckpt $1 > /dev/null'
# 3) seçim ve dondurma (test tohumlarına bundan ÖNCE hiç bakılmaz)
[ -f FROZEN7 ] || python3 select_main_v7.py
[ -f FROZEN7 ] || { echo "Donduruldu (v7): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v7.json; } > FROZEN7
# 4) en yeni test: resmi (80000-80099) + ek (80100-81999); evaluate.py ikinci kez ölçmeyi reddeder
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | xargs -P $P -L 1 bash -c '
  [ -f $0/test7_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test7 --ckpt $1 > /dev/null
  [ -f $0/test7x_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test7x --ckpt $1 > /dev/null'
python3 - $CANDS <<'EOF'
import json, sys, glob, os
bad = []
for c in sys.argv[1:]:
    g, suf = c.split("@")
    for d in sorted(glob.glob(f"runs/{g}/seed*")):
        for sp, n in [("test7", 100), ("test7x", 1900)]:
            f = f"{d}/{sp}_best_{suf}_summary.json"
            if not os.path.exists(f) or json.load(open(f))["n"] != n:
                bad.append(f)
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
# 5) raporlar, video (SAC şampiyonu ve kural seçimi), tanı, sonuç sayfası, masaüstü kopyası
python3 report.py --split test7 --groups $CANDS --out results/final_test7 --no-curves
python3 report.py --split test7all --groups $CANDS --out results/final_test7_1000 --no-curves > /dev/null
python3 report.py --split val8 --groups $CANDS --out results/final_val8 > /dev/null
SEL=results/ana_sonuc_secimi_v7.json
MAIN=$(python3 -c "import json; print(json.load(open('$SEL'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('$SEL'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/${MAIN%@*}/seed$VSEED" --ckpt "best_${MAIN#*@}" --split test7 --episodes 4 --out results/en_iyi_ajan_v7
SACC=$(python3 -c "import json; print(json.load(open('$SEL'))['sac_champion'])")
SSEED=$(python3 -c "import json; d=json.load(open('$SEL')); r=[t for t in d['table'] if t['group']==d['sac_champion']][0]; print(r['best_seed'])")
python3 make_video.py --run-dir "runs/${SACC%@*}/seed$SSEED" --ckpt "best_${SACC#*@}" --split test7 --episodes 4 --out results/sac_sampiyonu_v7
python3 scripts/diag_v7.py > results/tani_v7.txt 2>&1 || echo "tanı betiği hata verdi (sonuçları etkilemez)"
python3 make_dashboard.py || echo "sayfa güncellenemedi (sonuçları etkilemez)"
if [ -d "$DESKTOP" ]; then rsync -rt results/ "$DESKTOP/results/"; fi
echo "TEST7 TAMAMLANDI"
