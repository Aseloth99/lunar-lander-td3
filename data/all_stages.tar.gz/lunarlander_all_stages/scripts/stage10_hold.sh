#!/usr/bin/env bash
# Aşama 10 kuyruğunun kapısı (queue_runner.py --hold-cmd): çıkış 0 = yeni iş BAŞLATMA, 1 = başlatılabilir.
#  - Aşama 9 eğitimi sürerken: yalnızca onun ikinci yarıda boş bıraktığı 2 yere (en çok 2 Aşama 10 eğitimi).
#  - Aşama 9 eğitimi bitti ama son adımı (finalize_test7.sh) bitmedi: bekle (değerlendirme önce, toplam 6 süreç).
#  - Aşama 9'un son adımı bitti: serbest (toplam sınırı yine --max-total 6).
cd "$(dirname "${BASH_SOURCE[0]}")/.."
if pgrep -f "queue_runner.py --jobs jobs/stage9.txt" > /dev/null; then
  [ "$(pgrep -fc 'train.py .*--tag v10')" -lt 2 ] && exit 1
  exit 0
fi
grep -qE "BEKÇİ|EKSİK" logs/finalize_test7.log 2>/dev/null && exit 1
exit 0
