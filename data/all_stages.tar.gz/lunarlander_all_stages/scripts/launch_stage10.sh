#!/usr/bin/env bash
# Aşama 10'u başlatır: 10 eğitim (sac/v10brake + sac/v10soft, tohum 0-4) AYRI bir kuyrukta. Aşama 9 kuyruğu sürerken onun
# boş bıraktığı yerleri doldurur; makinedeki toplam eğitim+değerlendirme süreci en çok 6 (kullanıcı isteği). Kapı:
# scripts/stage10_hold.sh (Aşama 9'un son adımı önce). Bekçi: kuyruk bitince ve Aşama 9'un son adımı da bitmişse
# finalize_test8.sh'i kendisi çalıştırır. Yeniden başlatma sonrası da aynı komut (önce launch_stage9.sh).
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
python3 -m py_compile common.py report.py train.py evaluate.py queue_runner.py select_main_v8.py && echo "derleme tamam" || exit 1
[ -f results/secim_kurali_v8.md ] || { echo "önceden kayıt (secim_kurali_v8.md) yok"; exit 1; }
if pgrep -f "queue_runner.py --jobs jobs/stage10.txt" > /dev/null; then echo "Aşama 10 kuyruğu zaten çalışıyor"; exit 1; fi
echo "$(date '+%F %T') AŞAMA 10 BAŞLAT/DEVAM" >> logs/queue.log
setsid nohup python3 queue_runner.py --jobs jobs/stage10.txt --workers 6 --max-total 6 --after jobs/stage9.txt \
  --hold-cmd "bash scripts/stage10_hold.sh" > logs/queue10_stdout.log 2>&1 < /dev/null &
echo "Aşama 10 kuyruğu başladı (pid $!)"
cat > logs/wait_stage10_bg.sh << 'EOF'
#!/bin/bash
cd <proje_klasörü>
sleep 30
while pgrep -f "queue_runner.py --jobs jobs/stage10.txt" > /dev/null; do sleep 120; done
# Aşama 9'un son adımı sürüyorsa onu bekle (iki değerlendirme aynı anda çalışmasın)
while pgrep -f "finalize_test7.sh" > /dev/null; do sleep 120; done
grep -q "TEST8 BEKÇİ: TAMAM" logs/finalize_test8.log 2>/dev/null && exit 0
if [ "$(ls runs/sac/v10brake/seed*/DONE runs/sac/v10soft/seed*/DONE 2>/dev/null | wc -l)" = 10 ]; then
  bash scripts/finalize_test8.sh > logs/finalize_test8.log 2>&1 && echo "TEST8 BEKÇİ: TAMAM" >> logs/finalize_test8.log \
    || echo "TEST8 BEKÇİ: HATA (ayrıntı yukarıda)" >> logs/finalize_test8.log
else
  echo "KUYRUK EKSİK BİTTİ: $(ls runs/sac/v10brake/seed*/DONE runs/sac/v10soft/seed*/DONE 2>/dev/null | wc -l)/10" > logs/finalize_test8.log
fi
EOF
pkill -f "wait_stage10_bg.sh" 2>/dev/null
setsid nohup bash logs/wait_stage10_bg.sh > /dev/null 2>&1 < /dev/null &
sleep 15
echo "== çalışanlar =="; pgrep -af "queue_runner|train.py|wait_stage|status.py" | cut -c1-140
