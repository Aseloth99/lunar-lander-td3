"""Aşama 5 kontrolü: TD3 v3 uzun sonuçlarını ham veriden yeniden hesaplar, yeniden oynatır, sırayı denetler; ayrıca
v2b ile yakıt/iniş süresi karşılaştırması (doğrulama 5000-5099). Dosya yazmaz."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import hashlib, json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402
import reward_decomposition as rd  # noqa: E402

R = common.ROOT
fails = []


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


groups = ["td3/v2b", "td3/v3long", "td3/v3big", "td3/v3fuel"]
sel = json.load(open(R / "results" / "ana_sonuc_secimi_v3.json"))
check("ana sonuç = td3/v3long", sel["main"] == "td3/v3long")
t_sel = (R / "results" / "ana_sonuc_secimi_v3.json").stat().st_mtime
t3 = [p.stat().st_mtime for g in groups for p in (R / "runs" / g).glob("seed*/test3_summary.json")]
v4 = [p.stat().st_mtime for g in groups for p in (R / "runs" / g).glob("seed*/val4_best_v2_summary.json")]
check("20 koşunun hepsinde test var", len(t3) == 20, str(len(t3)))
check("seçim ve doğrulama testten önce", max(v4) < min(t3) and t_sel < min(t3))
check("hiçbir eski test/doğrulama kümesiyle çakışma yok",
      not (set(common.TEST3_SEEDS + common.TEST3X_SEEDS) & set(common.VAL_SEEDS + common.VAL2_SEEDS + common.VAL3_SEEDS +
           common.VAL4_SEEDS + common.TEST_SEEDS + common.TEST2_SEEDS + common.TEST2X_SEEDS)))

d0 = R / "runs" / "td3" / "v3long"
means, crash100, crash1000, succ = [], 0, 0, []
maxdiff = 0.0
for d in sorted(d0.glob("seed*")):
    a, b = pd.read_csv(d / "test3_episodes.csv"), pd.read_csv(d / "test3x_episodes.csv")
    check(f"{d.name}: tohum listesi doğru", list(a.seed) == list(range(30000, 30100)) and list(b.seed) == list(range(30100, 31000)))
    means.append(a.ret.mean()); succ.append((a.ret >= 200).mean())
    crash100 += int((a.outcome == "crash").sum()); crash1000 += int((a.outcome == "crash").sum() + (b.outcome == "crash").sum())
    cfg = json.load(open(d / "config.json"))
    check(f"{d.name}: orijinal ödül, 800 bin adım, v2b'den devam",
          float(cfg["cfg"].get("train_fuel_k", 0)) == 0 and cfg["cfg"]["steps"] == 800000 and "v2b" in cfg.get("continued_from", ""))
    ck = json.load(open(d / "selection_v2.json"))["chosen"]["ckpt"]
    if (d / "ckpt" / ck).exists():
        check(f"{d.name}: seçilen model = {ck} (aynı dosya)",
              hashlib.md5(open(d / "best_policy_v2.pt", "rb").read()).hexdigest() == hashlib.md5(open(d / "ckpt" / ck, "rb").read()).hexdigest())
    else:
        print(f"  --  {d.name}: ara kayıtlar temizlendiği için model-dosya eşleşmesi atlandı (temizlikten önce geçmişti)")
    rows = common.evaluate_episodes(common.policy_act_fn(load_for_eval(d, "td3", "best_v2")), common.TEST3_SEEDS)
    maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rows]) - a.ret.values))))
m, ci = np.mean(means), stats.t.ppf(0.975, 4) * np.std(means, ddof=1) / np.sqrt(5)
check("v3 uzun: 290.0 ± 2.1", f"{m:.1f}" == "290.0" and f"{ci:.1f}" == "2.1", f"{m:.2f} ± {ci:.2f}")
check("v3 uzun: 0/500 çakılma (resmi), 1/5000 (genişletilmiş)", crash100 == 0 and crash1000 == 1, f"{crash100}, {crash1000}")
check("v3 uzun: her tohumda başarı ≥ %99", min(succ) >= 0.99, str([round(x, 2) for x in succ]))
check("yeniden oynatma aynı puanlar", maxdiff < 1e-6, f"{maxdiff:.1e}")

print("\nNEDEN (doğrulama 5000-5099, seçilmiş modeller):")
rd.load_for_eval = lambda run_dir, algo, ckpt: load_for_eval(run_dir, algo, "best_v2")
for g in ["td3/v2b", "td3/v3long"]:
    rows = [r for k in range(5) for r in rd.decompose(R / "runs" / g / f"seed{k}")]
    print(f"  {g:11s} puan {np.mean([r['ret'] for r in rows]):.1f} | yakıt {np.mean([r['fuel_main'] + r['fuel_side'] for r in rows]):.1f} | "
          f"iniş sapması {np.mean([20 - r['Sfin'] for r in rows]):.1f} | adım {np.mean([r['steps'] for r in rows]):.0f}")
print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
