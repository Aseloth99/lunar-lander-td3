#!/usr/bin/env bash
# Grafikleri yalnızca ÇİZİM için yeniden üretir (ör. işaret boyutu düzeltmesi). Önce geçici klasöre çizer; tablolar
# (sonuc_tablosu.md, tohum_tablosu.md, ozet.json) mevcut olanlarla BİREBİR aynıysa yalnızca PNG/SVG'leri kopyalar.
# Sayılar dondurulmuş test/doğrulama kayıtlarından okunur; hiçbir değerlendirme yeniden çalıştırılmaz.
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
TMP=$(mktemp -d)
C5="td3/v2b td3/v3long td3/v3big td3/v3fuel"
C6="td3/v3long@v2 td3/v4big@800k td3/v4big@1600k td3/v4small@800k td3/v4small@1600k sac/v4@800k sac/v4@1600k ppo/tuned@v2"
C7="td3/v4big@800k td3/v4big@1600k td3/v5big@800k td3/v5big@1600k"
while read -r split out flags groups; do
  [ "$flags" = "-" ] && flags=""
  python3 report.py --split "$split" --groups $groups --out "$TMP/$out" $flags > /dev/null
  for f in sonuc_tablosu.md tohum_tablosu.md ozet.json; do
    cmp -s "$TMP/$out/$f" "results/$out/$f" || { echo "FARK: $out/$f -> hiçbir şey kopyalanmadı"; exit 1; }
  done
  cp "$TMP/$out"/*.png "$TMP/$out"/*.svg "results/$out/"
  echo "yeniden çizildi (tablolar aynı): results/$out"
done << EOF
test3 final_test3 --no-curves $C5
test3all final_test3_1000 --no-curves $C5
val4 final_val4 - $C5
test4 final_test4 --no-curves $C6
test4all final_test4_1000 --no-curves $C6
val5 final_val5 - $C6
test5 final_test5 --no-curves $C7
test5all final_test5_1000 --no-curves $C7
val6 final_val6 - $C7
EOF
rm -rf "$TMP"
