#!/usr/bin/env bash
# Aşama 9.u başlatır: 10 eğitim (sac/v9big + sac/v9lowent, tohum 0-4), 6 işçi (her süreç tek çekirdek -> en çok ~6
# çekirdek; kullanıcı isteği: bilgisayar yorulmasın) + DURUM yazıcısı + bekçi.
# Bekçi oturumdan bağımsız arka planda çalışır; kuyruk bitince son adımı (finalize_test7.sh) kendisi yapar.
# Yeniden başlatma sonrası da aynı komut kullanılır: biten koşular atlanır, yarım kalanlar resume/ kayıtlarından sürer.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
python3 -m py_compile common.py status.py report.py train.py evaluate.py && echo "derleme tamam" || exit 1
[ -f results/secim_kurali_v7.md ] || { echo "önceden kayıt (secim_kurali_v7.md) yok"; exit 1; }
if pgrep -f "queue_runner.py --jobs jobs/stage9.txt" > /dev/null; then echo "Aşama 9 kuyruğu zaten çalışıyor"; exit 1; fi
[ -f logs/queue.log ] && [ ! -f logs/queue_asama8.log ] && mv logs/queue.log logs/queue_asama8.log
echo "$(date '+%F %T') AŞAMA 9 BAŞLAT/DEVAM" >> logs/queue.log
bash scripts/start_queue.sh jobs/stage9.txt 6
pkill -f "status.py --loop"; sleep 1
bash scripts/start_status.sh
cat > logs/wait_stage9_bg.sh << 'EOF'
#!/bin/bash
cd <proje_klasörü>
sleep 30
while pgrep -f "queue_runner.py --jobs jobs/stage9.txt" > /dev/null; do sleep 60; done
grep -q "TEST7 BEKÇİ: TAMAM" logs/finalize_test7.log 2>/dev/null && exit 0
if [ "$(ls runs/sac/v9big/seed*/DONE runs/sac/v9lowent/seed*/DONE 2>/dev/null | wc -l)" = 10 ]; then
  bash scripts/finalize_test7.sh > logs/finalize_test7.log 2>&1 && echo "TEST7 BEKÇİ: TAMAM" >> logs/finalize_test7.log \
    || echo "TEST7 BEKÇİ: HATA (ayrıntı yukarıda)" >> logs/finalize_test7.log
else
  echo "KUYRUK EKSİK BİTTİ: $(ls runs/sac/v9big/seed*/DONE runs/sac/v9lowent/seed*/DONE 2>/dev/null | wc -l)/10" > logs/finalize_test7.log
fi
EOF
pkill -f "wait_stage9_bg.sh" 2>/dev/null
setsid nohup bash logs/wait_stage9_bg.sh > /dev/null 2>&1 < /dev/null &
sleep 20
echo "== çalışanlar =="; pgrep -af "train.py|wait_stage9_bg|status.py" | cut -c1-120
