"""Ani kapanma sonrası onarım (scripts/auto_resume.sh yeniden başlatmadan önce çağırır): bitmemiş koşuların CSV
kayıtlarından (val_curve.csv, monitor/*/*.csv) NUL baytlarını ve yarım kalan son satırı atar; değişen her dosyanın
özgün hali yanına *.bozuk_yedek olarak kopyalanır. Modellere ve seçimlere dokunmaz.
  python3 scripts/repair_after_crash.py [iş dosyası ...]      (varsayılan: jobs/stage9.txt jobs/stage10.txt)"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import shutil  # noqa: E402

import common  # noqa: E402
from queue_runner import job_run_dir, read_jobs  # noqa: E402


def repair(f):
    b = f.read_bytes()
    if b"\x00" not in b:
        return False
    shutil.copy2(f, f.with_name(f.name + ".bozuk_yedek"))
    c = b.replace(b"\x00", b"")
    if c and not c.endswith(b"\n"):
        c = c[: c.rfind(b"\n") + 1]
    f.write_bytes(c)
    print(f"{common.now_iso()} onarıldı: {f} ({len(b)} -> {len(c)} bayt)")
    return True


def main():
    files = sys.argv[1:] or ["jobs/stage9.txt", "jobs/stage10.txt"]
    n = 0
    for jf in files:
        if not (common.ROOT / jf).exists():
            continue
        for argv in read_jobs(common.ROOT / jf):
            rd = job_run_dir(argv)[0]
            if not rd.exists() or (rd / "DONE").exists():
                continue
            for f in [rd / "val_curve.csv", *sorted(rd.glob("monitor/*/*.csv"))]:
                if f.exists():
                    n += repair(f)
    print(f"{common.now_iso()} onarım taraması bitti: {n} dosya düzeltildi")


if __name__ == "__main__":
    main()
