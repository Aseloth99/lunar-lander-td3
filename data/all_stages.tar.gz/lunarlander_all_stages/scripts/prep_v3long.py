"""td3/v3long: td3/v2b koşularını 400 bin adımdaki kayıtlarından (model + tekrar belleği) 800 bin adıma sürdürmek için
yeni klasörlere kopyalar. Test/seçim sonuçları KOPYALANMAZ (yeni koşu bunları kendisi üretir)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import json  # noqa: E402
import shutil  # noqa: E402
import common  # noqa: E402

KEEP = ["config.json", "val_curve.csv", "monitor", "ckpt", "resume"]
for k in range(5):
    src = common.RUNS / "td3" / "v2b" / f"seed{k}"
    dst = common.RUNS / "td3" / "v3long" / f"seed{k}"
    if dst.exists():
        print("zaten var:", dst)
        continue
    dst.mkdir(parents=True)
    for name in KEEP:
        s = src / name
        (shutil.copytree if s.is_dir() else shutil.copyfile)(s, dst / name)
    c = json.load(open(dst / "config.json", encoding="utf-8"))
    c.update(tag="v3long", continued_from=f"td3/v2b/seed{k} (400000 adımdaki kayıt)")
    c["cfg"]["steps"] = 800000
    json.dump(c, open(dst / "config.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("hazır:", dst)
