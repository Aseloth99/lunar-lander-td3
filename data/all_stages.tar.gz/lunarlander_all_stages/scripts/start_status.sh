#!/usr/bin/env bash
# DURUM.md'yi her 60 sn'de yenileyen arka plan süreci. İsteğe bağlı 1. argüman: ek kopya klasörü
#   bash scripts/start_status.sh
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
if pgrep -f "status.py --loop" > /dev/null; then echo "durum yazıcısı zaten çalışıyor"; exit 0; fi
SYNC_ARGS=()
[ -n "$1" ] && SYNC_ARGS=(--sync "$1")
setsid nohup python3 status.py --loop 60 "${SYNC_ARGS[@]}" > logs/status_stdout.log 2>&1 < /dev/null &
echo "durum yazıcısı başladı (pid $!)"
