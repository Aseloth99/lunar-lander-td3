#!/usr/bin/env bash
# Aşama 10 SON ADIM (bir kez): sac/v10brake + sac/v10soft için 800k/1600k kontrol noktası seçimi -> bağımsız doğrulama
# (90000-91999, 2000/tohum) -> v8 kuralıyla seçim (results/secim_kurali_v8.md) -> FROZEN8 -> en yeni test (100000-101999,
# 2000/tohum) -> rapor + video + tanı + sayfa. Paralellik 6 (kullanıcı: en çok ~6 çekirdek).
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
NEW="sac/v10brake sac/v10soft"
CANDS="td3/v4big@1600k td3/v6brake@1600k td3/v6soft@800k sac/v9lowent@800k sac/v9lowent@1600k sac/v9big@800k sac/v9big@1600k sac/v10brake@800k sac/v10brake@1600k sac/v10soft@800k sac/v10soft@1600k"
DESKTOP=<kopyalanacak_klasör>
P=6
[ "$(ls runs/sac/v10brake/seed*/DONE runs/sac/v10soft/seed*/DONE 2>/dev/null | wc -l)" = 10 ] || { echo "10 koşunun hepsi bitmemiş"; exit 1; }
[ -f FROZEN8 ] && echo "UYARI: FROZEN8 zaten var (seçim önceden yapılmış); yalnızca eksik adımlar tamamlanacak"
# 1) kontrol noktası seçimi (yalnızca 5100-5599): 800k (400k-800k) ve 1600k (800k-1.6M); Aşama 9'unkiler zaten varsa atlanır
for g in $NEW sac/v9big sac/v9lowent; do for d in runs/$g/seed*; do
  [ -f "$d/best_policy_800k.pt" ] || echo "$d 800k 400000 800000"
  [ -f "$d/best_policy_1600k.pt" ] || echo "$d 1600k 800000 1600000"
done; done | xargs -r -P $P -L 1 bash -c 'python3 reselect.py --run-dir $0 --suffix $1 --min-step $2 --max-step $3 >> logs/reselect_v8.log 2>&1'
# 2) bağımsız doğrulama 90000-91999 (bütün adaylar, 2000 bölüm/tohum)
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | \
  xargs -P $P -L 1 bash -c '[ -f $0/val9_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split val9 --ckpt $1 > /dev/null'
# 3) seçim ve dondurma (test tohumlarına bundan ÖNCE hiç bakılmaz)
[ -f FROZEN8 ] || python3 select_main_v8.py
[ -f FROZEN8 ] || { echo "Donduruldu (v8): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v8.json; } > FROZEN8
# 4) en yeni test: resmi (100000-100099) + ek (100100-101999); evaluate.py ikinci kez ölçmeyi reddeder
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | xargs -P $P -L 1 bash -c '
  [ -f $0/test8_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test8 --ckpt $1 > /dev/null
  [ -f $0/test8x_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test8x --ckpt $1 > /dev/null'
python3 - $CANDS <<'EOF'
import json, sys, glob, os
bad = []
for c in sys.argv[1:]:
    g, suf = c.split("@")
    for d in sorted(glob.glob(f"runs/{g}/seed*")):
        for sp, n in [("test8", 100), ("test8x", 1900)]:
            f = f"{d}/{sp}_best_{suf}_summary.json"
            if not os.path.exists(f) or json.load(open(f))["n"] != n:
                bad.append(f)
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
# 5) raporlar, video (kural seçimi ve frenli SAC seçimi), tanı, sonuç sayfası, masaüstü kopyası
python3 report.py --split test8 --groups $CANDS --out results/final_test8 --no-curves
python3 report.py --split test8all --groups $CANDS --out results/final_test8_1000 --no-curves > /dev/null
python3 report.py --split val9 --groups $CANDS --out results/final_val9 > /dev/null
SEL=results/ana_sonuc_secimi_v8.json
MAIN=$(python3 -c "import json; print(json.load(open('$SEL'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('$SEL'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/${MAIN%@*}/seed$VSEED" --ckpt "best_${MAIN#*@}" --split test8 --episodes 4 --out results/en_iyi_ajan_v8
PICK=$(python3 -c "import json; print(json.load(open('$SEL'))['stage10_pick'])")
PSEED=$(python3 -c "import json; d=json.load(open('$SEL')); r=[t for t in d['table'] if t['group']==d['stage10_pick']][0]; print(r['best_seed'])")
python3 make_video.py --run-dir "runs/${PICK%@*}/seed$PSEED" --ckpt "best_${PICK#*@}" --split test8 --episodes 4 --out results/frenli_sac_v8
python3 scripts/diag_v8.py > results/tani_v8.txt 2>&1 || echo "tanı betiği hata verdi (sonuçları etkilemez)"
python3 make_dashboard.py || echo "sayfa güncellenemedi (sonuçları etkilemez)"
if [ -d "$DESKTOP" ]; then rsync -rt results/ "$DESKTOP/results/"; fi
echo "TEST8 TAMAMLANDI"
