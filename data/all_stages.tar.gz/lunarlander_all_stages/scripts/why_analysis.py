"""Neden bazı ajanlar çakılmıyor? Grupların iniş davranışı (DOĞRULAMA 5000-5099; seçilmiş v2 kontrol noktaları).
Ölçülenler (bölüm başına, sonra grup ortalaması):
  temas_vy   : ilk bacak teması anındaki dikey hız (küçük = yumuşak iniş)
  temas_aci  : ilk temas anındaki gövde eğimi (rad, mutlak)
  maks_aci   : temastan sonraki en büyük eğim (devrilmeye yaklaşma)
  yan_motor  : temastan sonra yan motorun açık olduğu adım oranı
  ana_motor  : temastan sonra ana motorun açık olduğu adım oranı
  uyuma      : temastan uyumaya (bölüm sonu) kadar geçen adım
  yakit      : bölüm boyunca yakıt cezası
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import json
import numpy as np
import common
from evaluate import load_for_eval

GROUPS = ["td3/v2b", "td3/v2a", "ppo/tuned", "sac/fuel2x"]


def episode(act, seed, env):
    obs, _ = env.reset(seed=int(seed))
    done, contact_t, t = False, None, 0
    rec = dict(side=[], main=[], ang=[], fuel=0.0)
    while not done:
        a = act(obs)
        if contact_t is None and (obs[6] > 0 or obs[7] > 0):
            contact_t = t
            rec["vy"], rec["ang0"] = float(obs[3]), abs(float(obs[4]))
        if contact_t is not None:
            rec["side"].append(abs(a[1]) > 0.5)
            rec["main"].append(a[0] > 0)
            rec["ang"].append(abs(float(obs[4])))
        rec["fuel"] += common._fuel_cost(a)
        obs, r, term, trunc, _ = env.step(a)
        t += 1
        done = term or trunc
    if contact_t is None:
        return None
    return dict(temas_vy=rec["vy"], temas_aci=rec["ang0"], maks_aci=max(rec["ang"]), yan_motor=np.mean(rec["side"]),
                ana_motor=np.mean(rec["main"]), uyuma=t - contact_t, yakit=rec["fuel"], adim=t)


env = common.make_env()
out = {}
for g in GROUPS:
    algo, tag = g.split("/")
    rows = []
    for d in sorted((common.RUNS / algo / tag).glob("seed*")):
        act = common.policy_act_fn(load_for_eval(d, algo, "best_v2"))
        rows += [x for x in (episode(act, s, env) for s in common.VAL_SEEDS) if x]
    keys = rows[0].keys()
    out[g] = {k: float(np.mean([r[k] for r in rows])) for k in keys}
    out[g]["maks_aci_p99"] = float(np.percentile([r["maks_aci"] for r in rows], 99))
    out[g]["n"] = len(rows)
print(f"{'grup':11s} " + " ".join(f"{k:>12s}" for k in out[GROUPS[0]]))
for g, v in out.items():
    print(f"{g:11s} " + " ".join(f"{v[k]:12.3f}" for k in v))
json.dump(out, open(common.ROOT / "results" / "neden_analizi.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
