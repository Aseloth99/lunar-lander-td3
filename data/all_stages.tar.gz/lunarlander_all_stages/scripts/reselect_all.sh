#!/usr/bin/env bash
# Verilen grupların tüm tohumlarında reselect.py + bağımsız doğrulama (val3: 5600-5999) çalıştırır (3 paralel).
#   bash scripts/reselect_all.sh sac/fuel2x ppo/tuned td3/tuned
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
for g in "$@"; do
  for d in runs/$g/seed*; do
    [ -f "$d/DONE" ] && [ ! -f "$d/val3_best_v2_summary.json" ] && echo "$d"
  done
done | xargs -P 3 -I{} bash -c 'nice -n 5 python3 reselect.py --run-dir {} >> logs/reselect.log 2>&1 && \
    nice -n 5 python3 evaluate.py --run-dir {} --split val3 --ckpt best_v2 > /dev/null 2>> logs/reselect.log'
echo "RESELECT BİTTİ: $*" >> logs/reselect.log
