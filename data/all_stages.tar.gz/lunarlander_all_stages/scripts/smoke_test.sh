#!/usr/bin/env bash
# Hızlı duman testi (birkaç dakika): train/evaluate/resume/status zinciri. runs/*/smoke altına yazar.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
rm -rf runs/sac/smoke runs/td3/smoke runs/ppo/smoke
set -x
# 1) SAC: ortada öldür (resume kaydından sonra), sonra --resume ile bitir
timeout 40 python3 train.py --algo sac --seed 0 --tag smoke --steps 4000 --eval-every 500 --resume-every 1000 \
    --set learning_starts=300 net=64,64 batch=64
echo "ilk koşu çıkış kodu: $? (124 = zaman aşımıyla öldürüldü)"
ls runs/sac/smoke/seed0/resume/ 2>&1
python3 train.py --algo sac --seed 0 --tag smoke --steps 4000 --eval-every 500 --resume-every 1000 \
    --set learning_starts=300 net=64,64 batch=64 --resume
cat runs/sac/smoke/seed0/val_curve.csv
cat runs/sac/smoke/seed0/selection.json | head -30
# 2) TD3 ve PPO kısa
python3 train.py --algo td3 --seed 0 --tag smoke --steps 1500 --eval-every 500 --set learning_starts=300 net=64,64 batch=64
python3 train.py --algo ppo --seed 0 --tag smoke --steps 6000 --eval-every 2000 --set n_envs=4 n_steps=256 batch=64
# 3) Değerlendirme (doğrulama) + test korumaları
python3 evaluate.py --run-dir runs/sac/smoke/seed0 --split val --ckpt best --episodes 10
python3 evaluate.py --run-dir runs/sac/smoke/seed0 --split val --ckpt final --episodes 10
python3 evaluate.py --run-dir runs/sac/smoke/seed0 --split test    # REDDEDİLMELİ (FROZEN yok)
python3 status.py && cat DURUM.md
