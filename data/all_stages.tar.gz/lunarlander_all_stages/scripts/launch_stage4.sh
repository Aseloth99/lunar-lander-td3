#!/usr/bin/env bash
# Aşama 4 eğitimlerini arka planda başlatır (5 işçi: 1 çekirdek değerlendirmelere kalsın).
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
[ -f logs/queue.log ] && mv logs/queue.log logs/queue_asama3.log
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
bash scripts/start_queue.sh jobs/stage4_td3.txt 5
bash scripts/start_status.sh
sleep 15
pgrep -af "train.py" | cut -c1-160
