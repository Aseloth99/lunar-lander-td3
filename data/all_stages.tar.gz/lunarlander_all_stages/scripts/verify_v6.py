"""Aşama 8 kontrolü: önceden kaydın zamanı, seçimin/testin sırası, küme ayrıklığı, yeni çeşitlerin ayarı, seçimin ham
doğrulama verisinden yeniden yapılması, test tablolarının ham bölümlerden yeniden hesaplanması, ana sonucun yeniden
oynatılması ve önceden tanımlı "sıfır çakılma?" sorusunun cevabı. Dosya yazmaz."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import datetime as dt  # noqa: E402
import json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

R = common.ROOT
fails = []
CANDS = ["td3/v4big@800k", "td3/v4big@1600k", "td3/v6brake@800k", "td3/v6brake@1600k", "td3/v6soft@800k",
         "td3/v6soft@1600k"]
NEW = {"td3/v6brake": (100.0, 0.25), "td3/v6soft": (50.0, 0.30)}


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


def files(c, split):
    g, suf = c.split("@")
    return sorted((R / "runs" / g).glob(f"seed*/{split}_best_{suf}_summary.json"))


mt = lambda ps: [p.stat().st_mtime for p in ps]  # noqa: E731
rule = (R / "results" / "secim_kurali_v6.md").stat().st_mtime
starts = [json.load(open(d / "config.json"))["started"] for g in NEW for d in sorted((R / "runs" / g).glob("seed*"))]
start_ts = min(dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S").timestamp() for s in starts)
check("önceden kayıt (secim_kurali_v6.md) eğitimden önce yazılmış", rule < start_ts,
      f"kural {dt.datetime.fromtimestamp(rule):%F %T}, ilk eğitim {min(starts)}")
v7 = [t for c in CANDS for t in mt(files(c, "val7"))]
t6 = [t for c in CANDS for t in mt(files(c, "test6")) + mt(files(c, "test6x"))]
check("30 aday-koşunun hepsinde val7 ve test (100 + 1900) var", len(v7) == 30 and len(t6) == 60, f"{len(v7)}, {len(t6)}")
sel_f = R / "results" / "ana_sonuc_secimi_v6.json"
check("bağımsız doğrulama -> seçim -> FROZEN6 -> test sırası",
      max(v7) <= sel_f.stat().st_mtime <= (R / "FROZEN6").stat().st_mtime < min(t6))
old = (common.VAL_SEEDS + common.VAL2_SEEDS + common.VAL3_SEEDS + common.VAL4_SEEDS + common.VAL5_SEEDS + common.VAL6_SEEDS +
       common.TEST_SEEDS + common.TEST2_SEEDS + common.TEST2X_SEEDS + common.TEST3_SEEDS + common.TEST3X_SEEDS +
       common.TEST4_SEEDS + common.TEST4X_SEEDS + common.TEST5_SEEDS + common.TEST5X_SEEDS)
new = set(common.VAL7_SEEDS + common.TEST6_SEEDS + common.TEST6X_SEEDS)
check("7200-9199 ve 60000-61999 önceki hiçbir kümeyle çakışmıyor", not (new & set(old)))

for g, (k, v0) in NEW.items():
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = json.load(open(d / "config.json"))["cfg"]
        b = json.load(open(R / "runs/td3/v4big" / d.name / "config.json"))["cfg"]
        diff = sorted(x for x in set(a) | set(b) if a.get(x) != b.get(x))
        check(f"{g} {d.name}: v4big'den tek fark eğitim cezası (k={k}, v0={v0})",
              diff == ["train_touchdown_k", "train_touchdown_v0"] and a["train_touchdown_k"] == k and
              abs(a["train_touchdown_v0"] - v0) < 1e-9, str(diff))
        for sx, lo, hi in [("800k", 400000, 800000), ("1600k", 800000, 1600000)]:
            st = json.load(open(d / f"selection_{sx}.json"))["chosen"]["step"]
            check(f"{g} {d.name}: {sx} seçimi {lo // 1000}k-{hi // 1000}k aralığında ({st})", lo <= st <= hi)

# seçimi ham val7 verisinden yeniden yap (kural v6)
rows = []
for c in CANDS:
    g, suf = c.split("@")
    per = []
    for d in sorted((R / "runs" / g).glob("seed*")):
        e = pd.read_csv(d / f"val7_best_{suf}_episodes.csv")
        assert list(e.seed) == common.VAL7_SEEDS
        per.append(dict(crash=int((e.outcome == "crash").sum()), below=int((e.ret < 200).sum()), mean=e.ret.mean()))
    ok = all(p["mean"] >= 280 for p in per)
    rows.append((c, ok, sum(p["crash"] for p in per), sum(p["below"] for p in per), np.mean([p["mean"] for p in per])))
rows.sort(key=lambda r: (0 if r[1] else 1, r[2], r[3], -r[4]))
sel = json.load(open(sel_f))
check("seçim ham val7 verisinden yeniden yapıldığında aynı", rows[0][0] == sel["main"], f"yeniden: {rows[0][0]}, kayıt: {sel['main']}")

print("\nTEST (ham bölümlerden): resmi 60000-60099 | genişletilmiş 60000-61999")
res = {}
for c in CANDS:
    g, suf = c.split("@")
    m100, mall, c100, call, b100, ball = [], [], 0, 0, 0, 0
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / f"test6_best_{suf}_episodes.csv")
        b = pd.read_csv(d / f"test6x_best_{suf}_episodes.csv")
        assert list(a.seed) == common.TEST6_SEEDS and list(b.seed) == common.TEST6X_SEEDS
        ab = pd.concat([a, b])
        m100.append(a.ret.mean()); mall.append(ab.ret.mean())
        c100 += int((a.outcome == "crash").sum()); call += int((ab.outcome == "crash").sum())
        b100 += int((a.ret < 200).sum()); ball += int((ab.ret < 200).sum())
    ci = lambda x: stats.t.ppf(0.975, len(x) - 1) * np.std(x, ddof=1) / np.sqrt(len(x))  # noqa: E731
    res[c] = (np.mean(m100), c100, b100, np.mean(mall), call, ball)
    print(f"  {c:18s} {np.mean(m100):6.1f} ± {ci(m100):.1f} | çakılma {c100}/500 | 200 altı {b100}/500 || "
          f"{np.mean(mall):6.1f} ± {ci(mall):.1f} | çakılma {call}/10000 | 200 altı {ball}/10000")

main = sel["main"]
g, suf = main.split("@")
maxdiff, nrep = 0.0, 0
for d in sorted((R / "runs" / g).glob("seed*")):
    a = pd.read_csv(d / f"test6_best_{suf}_episodes.csv")
    rr = common.evaluate_episodes(common.policy_act_fn(load_for_eval(d, "td3", f"best_{suf}")), common.TEST6_SEEDS)
    maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rr]) - a.ret.values))))
    nrep += len(rr)
check(f"ana sonuç ({main}) yeniden oynatıldı: aynı puanlar", maxdiff < 1e-6, f"{nrep} bölüm, en büyük fark {maxdiff:.1e}")

m100, c100, b100, mall, call, ball = res[main]
print(f"\nÖNCEDEN TANIMLI SORULAR (ana sonuç {main}):")
print(f"  'Sıfır çakılma?' genişletilmiş test (10 000 bölüm): {call} çakılma -> {'EVET' if call == 0 else 'HAYIR'}")
print(f"  'Puan ne oldu?' aynı 10 000 bölümde ortalama {mall:.2f} ({'290 üstü' if mall >= 290 else '290 altı'}); "
      f"resmi test (500): {m100:.2f}, çakılma {c100}, 200 altı {b100}")
ref = res["td3/v4big@1600k"]
print(f"  tanı: aynı test bölümlerinde v4big@1600k {ref[4]} çakılma, ort {ref[3]:.2f} -> ana sonuç {call} çakılma, "
      f"ort {mall:.2f} (fark {mall - ref[3]:+.2f})")
print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
