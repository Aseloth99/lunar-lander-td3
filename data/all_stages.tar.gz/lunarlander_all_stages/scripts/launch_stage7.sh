#!/usr/bin/env bash
# Aşama 7'yi başlatır: 5 eğitim (td3/v5big, tohum 0-4) paralel + DURUM yazıcısı + bekçi.
# Bekçi oturumdan bağımsız arka planda çalışır; kuyruk bitince son adımı (finalize_test5.sh) kendisi yapar.
# Yeniden başlatma sonrası da aynı komut kullanılır: biten koşular atlanır, yarım kalanlar resume/ kayıtlarından sürer.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
python3 -m py_compile status.py report.py train.py evaluate.py select_main_v5.py make_dashboard.py make_video.py \
  && echo "derleme tamam" || exit 1
[ -f results/secim_kurali_v5.md ] || { echo "önceden kayıt (secim_kurali_v5.md) yok"; exit 1; }
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
[ -f logs/queue.log ] && [ ! -f logs/queue_asama6.log ] && mv logs/queue.log logs/queue_asama6.log
echo "$(date '+%F %T') AŞAMA 7 BAŞLAT/DEVAM" >> logs/queue.log
bash scripts/start_queue.sh jobs/stage7.txt 5
pkill -f "status.py --loop"; sleep 1
bash scripts/start_status.sh
cat > logs/wait_stage7_bg.sh << 'EOF'
#!/bin/bash
cd <proje_klasörü>
sleep 30
while pgrep -f "queue_runner.py" > /dev/null; do sleep 120; done
if [ "$(ls runs/td3/v5big/seed*/DONE 2>/dev/null | wc -l)" = 5 ]; then
  bash scripts/finalize_test5.sh > logs/finalize_test5.log 2>&1 && echo "TEST5 BEKÇİ: TAMAM" >> logs/finalize_test5.log \
    || echo "TEST5 BEKÇİ: HATA (ayrıntı yukarıda)" >> logs/finalize_test5.log
else
  echo "KUYRUK EKSİK BİTTİ: $(ls runs/td3/v5big/seed*/DONE 2>/dev/null | wc -l)/5" > logs/finalize_test5.log
fi
EOF
pkill -f "wait_stage7_bg.sh" 2>/dev/null
setsid nohup bash logs/wait_stage7_bg.sh > /dev/null 2>&1 < /dev/null &
sleep 20
echo "== çalışanlar =="; pgrep -af "train.py|wait_stage7_bg|status.py" | cut -c1-120
