#!/usr/bin/env bash
# Tek süreçte hız ölçümleri (sırayla), sonra N eşzamanlı süreçle ölçeklenme testi.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1

echo "### Tek süreç (1 iş parçacığı)"
python3 bench.py --algo sac --net 400,300 --batch 256 --tag tek
python3 bench.py --algo sac --net 256,256 --batch 256 --tag tek
python3 bench.py --algo sac --net 256,256 --batch 128 --tag tek
python3 bench.py --algo sac --net 128,128 --batch 256 --tag tek
python3 bench.py --algo td3 --net 400,300 --batch 256 --tag tek
python3 bench.py --algo td3 --net 256,256 --batch 256 --tag tek
python3 bench.py --algo ppo --net 64,64 --batch 64 --tag tek

for N in 4 6; do
  echo "### $N eşzamanlı SAC [256,256] süreci"
  for i in $(seq 1 $N); do
    python3 bench.py --algo sac --net 256,256 --batch 256 --tag par$N &
  done
  wait
done
