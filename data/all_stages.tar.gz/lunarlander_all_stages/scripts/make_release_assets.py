"""GitHub vitrini için grafikler (assets/; İngilizce, `tr` verilirse Türkçe ve dosya adları _tr ekli): yayımlanmış sonuçlarla karşılaştırma, ana sonucun puan dağılımı,
aşamalar boyunca ilerleme. Sayılar dondurulmuş test kayıtlarından ve results/*.json'dan okunur; hiçbir şey yeniden
değerlendirilmez. Ana sonuç = en son tamamlanmış turun önceden kayıtlı kurala göre seçtiği grup (common.latest_main).

  python3 scripts/make_release_assets.py [çıktı_klasörü] [grup] [en|tr]     (varsayılan: assets/, kural seçimi, en)
Renkler: report.py ile aynı, dataviz doğrulayıcısından geçti (#6F5BC4 vurgu; gri = bağlam).
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import json  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

import common  # noqa: E402

R = common.ROOT
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else R / "assets"
GROUP = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else None  # vitrin ajanı (verilmezse son turun kural seçimi)
LANG = sys.argv[3] if len(sys.argv) > 3 else "en"
SFX = "" if LANG == "en" else f"_{LANG}"
ACCENT, CONTEXT = "#6F5BC4", "#AEB5BD"
INK, MUTED, GRID, SURF = "#1f2328", "#59636e", "#d8dee4", "#fcfcfb"
plt.rcParams.update({
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "axes.edgecolor": GRID,
    "axes.labelcolor": INK, "text.color": INK, "xtick.color": MUTED, "ytick.color": MUTED, "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
    "axes.axisbelow": True, "svg.fonttype": "path"})

# Yayımlanmış sonuçlar: rl-baselines3-zoo benchmark.md (LunarLanderContinuous-v2, deterministik, TEK koşu)
# https://github.com/DLR-RM/rl-baselines3-zoo/blob/master/benchmark.md  (2026-10-22'de kaynağından doğrulandı)
ZOO = [("TQC", 277.956, 25.466, 706), ("PPO", 270.863, 32.072, 526), ("TRPO", 262.387, 21.428, 501),
       ("SAC", 260.390, 65.467, 672), ("DDPG", 230.217, 92.372, 556), ("TD3", 207.451, 67.562, 337)]

# (aşama, test öneki, seçim dosyası, resmi test bölümü/tohum)
ROUNDS = [("Stage 3", "test", "ana_sonuc_secimi.json", 100), ("Stage 4", "test2", "ana_sonuc_secimi_v2.json", 100),
          ("Stage 5", "test3", "ana_sonuc_secimi_v3.json", 100), ("Stage 6", "test4", "ana_sonuc_secimi_v4.json", 100),
          ("Stage 7", "test5", "ana_sonuc_secimi_v5.json", 100), ("Stage 8", "test6", "ana_sonuc_secimi_v6.json", 100)]
EXT = {"test2": "test2x", "test3": "test3x", "test4": "test4x", "test5": "test5x", "test6": "test6x"}
NAME = {"en": {"td3/v4big@1600k": "TD3, 1.6 M steps", "td3/v6brake@1600k": "TD3 + early braking, 1.6 M steps"},
        "tr": {"td3/v4big@1600k": "TD3, 1,6 milyon adım", "td3/v6brake@1600k": "TD3 + erken fren, 1,6 milyon adım"}}
T = {
    "en": dict(
        repo="this repo", official="official test", extended="extended test", episodes="episodes", solved="solved (200)",
        cmp_x="Mean episode score on unseen episodes (deterministic policy)",
        cmp_title="LunarLanderContinuous: this repo vs. the rl-baselines3-zoo benchmark",
        cmp_note="This repo: Gymnasium v3, mean of {n} independently trained agents; official test = 100 never-seen episodes "
                 "per agent, extended test = {k} per agent (± = per-episode std).\nrl-zoo: v2, one training run each "
                 "(benchmark.md). v3 only fixed bugs and widened observation bounds; reward and physics are unchanged, so the "
                 "comparison is approximate.",
        dist_box="{n} unseen episodes\nmean {m}  ·  median {md}\n{p300}% score ≥ 300  ·  best {b}\n{p200}% ≥ 200  ·  {c}",
        crash1="crash", crashN="crashes", dist_x="Episode score", dist_y="Episodes", headline_agent="headline agent",
        dist_title="Score distribution: {name} ({stage} test, {n} episodes)",
        prog_crash="{c}/{n} crashes", target="target 280", prog_y="Mean score, official test",
        prog_title="Pre-registered pick per stage (official test, 5 agents × 100 unseen episodes)",
        prog_note="Every stage uses a fresh, never-reused test set; episode difficulty differs between sets (±2–3 points is "
                  "normal: for every agent tested, Stage 7's\nfirst 100 episodes were ~3 points harder and Stage 8's ~3 points "
                  "easier than their 1,000–2,000-episode sets). Stage 3 = SAC with a training-time fuel penalty;\nStages 4–7 = "
                  "TD3 with the original reward; Stage 8 = TD3 trained with a hard-touchdown penalty (tested with the original "
                  "reward)."),
    "tr": dict(
        repo="bu depo", official="resmi test", extended="genişletilmiş test", episodes="bölüm", solved="çözüldü (200)",
        cmp_x="Hiç görülmemiş bölümlerde ortalama puan (deterministik politika)",
        cmp_title="LunarLanderContinuous: bu depo ile rl-baselines3-zoo karşılaştırması",
        cmp_note="Bu depo: Gymnasium v3, bağımsız eğitilmiş {n} ajanın ortalaması; resmi test = ajan başına hiç görülmemiş 100 "
                 "bölüm, genişletilmiş test = ajan başına {k} bölüm (± = bölümler arası std).\nrl-zoo: v2, her biri tek eğitim "
                 "koşusu (benchmark.md). v3 yalnızca hataları düzeltti ve gözlem sınırlarını genişletti; puanlama ve fizik aynı, "
                 "karşılaştırma yaklaşık.",
        dist_box="hiç görülmemiş {n} bölüm\nortalama {m}  ·  ortanca {md}\n%{p300} bölüm ≥ 300  ·  en iyi {b}\n"
                 "%{p200} ≥ 200  ·  {c}",
        crash1="çakılma", crashN="çakılma", dist_x="Bölüm puanı", dist_y="Bölüm sayısı", headline_agent="ana ajan",
        dist_title="Puan dağılımı: {name} ({stage} testi, {n} bölüm)",
        prog_crash="{c}/{n} çakılma", target="hedef 280", prog_y="Ortalama puan, resmi test",
        prog_title="Aşama başına önceden kayıtlı seçim (resmi test, 5 ajan × 100 görülmemiş bölüm)",
        prog_note="Her aşamada yeni, bir kez kullanılan test kümesi; kümeler arasında bölüm zorluğu farklı (±2–3 puan normal: "
                  "test edilen her ajan için Aşama 7'nin\nilk 100 bölümü ~3 puan zor, Aşama 8'inki ~3 puan kolay çıktı; "
                  "1000–2000 bölümlük kümelerine göre). Aşama 3 = eğitimde yakıt cezalı SAC;\nAşama 4–7 = orijinal ödülle TD3; "
                  "Aşama 8 = sert inişe ceza verilerek eğitilmiş TD3 (orijinal puanlamayla test edildi)."),
}[LANG]
STAGE = (lambda st: st) if LANG == "en" else (lambda st: st.replace("Stage", "Aşama"))


def fmt(x, spec):
    """Sayı biçimi; Türkçede ondalık virgül, binlik nokta."""
    s = format(x, spec)
    return s if LANG == "en" else s.translate(str.maketrans(",.", ".,"))


def episodes(group, prefix):
    """Bir grubun tüm tohumlarının bölüm kayıtları (aşama 6+ dosya adında kontrol noktası var)."""
    base, _, suf = group.partition("@")
    out = []
    for d in sorted((R / "runs" / base).glob("seed*")):
        names = [f"{prefix}_best_{suf or 'v2'}_episodes.csv", f"{prefix}_episodes.csv"]
        f = next((d / n for n in names if (d / n).exists()), None)
        if f is not None:
            e = pd.read_csv(f)
            e["seed_run"] = d.name
            out.append(e)
    return pd.concat(out, ignore_index=True) if out else None


def headline():
    """En son tamamlanmış tur: (aşama, grup, resmi bölümler, genişletilmiş bölümler)."""
    for stage, pre, sel, _ in reversed(ROUNDS):
        f = R / "results" / sel
        if f.exists() and pre in EXT:
            g = GROUP or json.load(open(f))["main"]
            a, b = episodes(g, pre), episodes(g, EXT[pre])
            if a is not None and b is not None:
                return stage, g, a, pd.concat([a, b], ignore_index=True)
    raise SystemExit("tamamlanmış tur yok")


def save(fig, name):
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{name}{SFX}.png", dpi=200, bbox_inches="tight")
    fig.savefig(OUT / f"{name}{SFX}.svg", bbox_inches="tight")
    plt.close(fig)


def fig_compare(ext, n_seeds):
    off = ext[ext.seed < ext.seed.min() + 100]  # resmi test: kümenin ilk 100 bölümü (tohum başına)
    algo = (GROUP or "td3/").split("/")[0].upper()
    ours_off = (f"{algo} · {T['repo']} · {T['official']}", off.groupby("seed_run").ret.mean().mean(), off.ret.std(), len(off))
    ours_ext = (f"{algo} · {T['repo']} · {T['extended']}", ext.groupby("seed_run").ret.mean().mean(), ext.ret.std(), len(ext))
    rows = [ours_off, ours_ext] + [(f"{n} · rl-zoo", m, s, k) for n, m, s, k in ZOO]
    fig, ax = plt.subplots(figsize=(9.6, 5.0))
    y = np.arange(len(rows))[::-1]
    for yi, (name, m, s, k) in zip(y, rows):
        col = ACCENT if T["repo"] in name else CONTEXT
        ax.barh(yi, m, height=0.62, color=col, edgecolor=SURF, linewidth=2, zorder=3)
        ax.text(m + 3, yi, fmt(m, ".1f"), va="center", ha="left", fontsize=11, color=INK,
                fontweight="bold" if col == ACCENT else "normal")
        ax.text(m + 26, yi, f"± {fmt(s, '.1f')}  ·  {fmt(k, ',')} {T['episodes']}", va="center", ha="left", fontsize=9,
                color=MUTED)
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows], fontsize=10.5, color=INK)
    ax.set_xlim(150, 345)
    ax.set_ylim(y[-1] - 0.9, y[0] + 0.6)
    ax.axvline(200, color=MUTED, lw=1, ls=(0, (4, 3)), zorder=2)
    ax.text(201, y[-1] - 0.55, T["solved"], fontsize=8.5, color=MUTED, va="top")
    ax.set_xlabel(T["cmp_x"])
    ax.grid(axis="y", visible=False)
    ax.set_title(T["cmp_title"], loc="left", fontsize=13, fontweight="bold")
    fig.text(0.0, -0.04, T["cmp_note"].format(n=n_seeds, k=fmt(len(ext) // n_seeds, ",")), fontsize=8.5, color=MUTED,
             ha="left", va="top")
    save(fig, "compare_published")


def fig_distribution(stage, ext):
    r = ext.ret.values
    fig, ax = plt.subplots(figsize=(9.6, 4.4))
    # 200'ün altı (birkaç nadir bölüm) tek bir "< 200" kutusunda toplanır; eksen boşa uzamasın
    bins = np.arange(190, 345, 5)
    counts, _, _ = ax.hist(np.clip(r, 190.5, 344), bins=bins, color=ACCENT, edgecolor=SURF, linewidth=1.2, zorder=3)
    top = counts.max() * 1.18
    ax.set_ylim(0, top)
    n_low = int((r < 200).sum())
    ax.annotate(f"< 200: {n_low}", (192.5, counts[0]), xytext=(0, 6), textcoords="offset points", ha="center",
                fontsize=8.5, color=MUTED)
    for v in (200, 300):
        ax.axvline(v, color=MUTED, lw=1, ls=(0, (4, 3)), zorder=2)
    # 200 etiketi çizginin solunda dikey: eksen yazılarıyla çakışmasın
    ax.text(198.5, top * 0.55, T["solved"], fontsize=9, color=MUTED, va="center", ha="right", rotation=90)
    ax.text(298.5, top * 0.98, "300", fontsize=9, color=MUTED, va="top", ha="right")
    crashes = int((ext.outcome == "crash").sum())
    box = T["dist_box"].format(n=fmt(len(r), ","), m=fmt(r.mean(), ".1f"), md=fmt(np.median(r), ".1f"),
                               p300=fmt(100 * (r >= 300).mean(), ".0f"), b=fmt(r.max(), ".1f"),
                               p200=fmt(100 * (r >= 200).mean(), ".2f"),
                               c=f"{crashes} {T['crash1'] if crashes == 1 else T['crashN']}")
    ax.text(0.14, 0.95, box, transform=ax.transAxes, va="top", fontsize=10, color=INK,
            bbox=dict(boxstyle="round,pad=0.4", fc=SURF, ec=GRID))
    ax.set_xlabel(T["dist_x"])
    ax.set_ylabel(T["dist_y"])
    ax.grid(axis="x", visible=False)
    ax.set_title(T["dist_title"].format(name=NAME[LANG].get(GROUP, T["headline_agent"]), stage=STAGE(stage),
                                        n=fmt(len(r), ",")), loc="left", fontsize=13, fontweight="bold")
    save(fig, "score_distribution")


def fig_progress():
    pts = []
    for stage, pre, sel, _ in ROUNDS:
        f = R / "results" / sel
        if not f.exists():
            continue
        g = json.load(open(f))["main"]
        a = episodes(g, pre)
        if a is None:
            continue
        pts.append((stage, a.groupby("seed_run").ret.mean().mean(), int((a.outcome == "crash").sum()), len(a)))
    fig, ax = plt.subplots(figsize=(9.6, 4.0))
    x = np.arange(len(pts))
    ys = [p[1] for p in pts]
    ax.plot(x, ys, color=ACCENT, lw=2, zorder=3)
    ax.scatter(x, ys, s=70, color=ACCENT, edgecolor=SURF, linewidth=2, zorder=4)
    for xi, (stage, m, c, n) in zip(x, pts):
        ax.annotate(fmt(m, ".1f"), (xi, m), xytext=(0, 9), textcoords="offset points", ha="center", fontsize=10.5,
                    fontweight="bold", color=INK)
    ax.set_xticks(x)
    # çakılma sayısı eksen etiketinde: çizgiyle çakışmasın
    ax.set_xticklabels([f"{STAGE(p[0])}\n" + T["prog_crash"].format(c=p[2], n=p[3]) for p in pts], color=INK,
                       fontsize=9.5)
    ax.set_ylim(min(ys) - 6, max(ys) + 6)
    ax.axhline(280, color=MUTED, lw=1, ls=(0, (1, 2)))
    ax.text(len(pts) - 1 + 0.25, 279.6, T["target"], fontsize=8.5, color=MUTED, va="top", ha="right")
    ax.set_ylabel(T["prog_y"])
    ax.grid(axis="x", visible=False)
    ax.set_title(T["prog_title"], loc="left", fontsize=13, fontweight="bold")
    fig.text(0.0, -0.06, T["prog_note"], fontsize=8.5, color=MUTED, ha="left", va="top")
    save(fig, "progress_by_stage")


def main():
    stage, g, official, ext = headline()
    n_seeds = ext.seed_run.nunique()
    fig_compare(ext, n_seeds)
    fig_distribution(stage, ext)
    fig_progress()
    summary = dict(stage=stage, group=g, n_seeds=n_seeds, official_episodes=len(official),
                   official_mean=float(official.groupby("seed_run").ret.mean().mean()),
                   official_std=float(official.ret.std()), official_best=float(official.ret.max()),
                   official_worst=float(official.ret.min()),
                   official_crashes=int((official.outcome == "crash").sum()),
                   official_below200=int((official.ret < 200).sum()),
                   ext_episodes=len(ext), ext_mean=float(ext.groupby("seed_run").ret.mean().mean()),
                   ext_std=float(ext.ret.std()), ext_crashes=int((ext.outcome == "crash").sum()),
                   ext_below200=int((ext.ret < 200).sum()), ext_ge300=float((ext.ret >= 300).mean()),
                   ext_best=float(ext.ret.max()), ext_worst=float(ext.ret.min()),
                   best_episode_seed=int(ext.loc[ext.ret.idxmax(), "seed"]),
                   best_episode_run=int(str(ext.loc[ext.ret.idxmax(), "seed_run"]).replace("seed", "")))
    # aşama bazında çakılmalar (ana sonucun resmi ve genişletilmiş testi)
    stages = []
    for st_name, pre, sel, _ in ROUNDS:
        f = R / "results" / sel
        if not f.exists():
            continue
        grp = json.load(open(f))["main"]
        a = episodes(grp, pre)
        if a is None:
            continue
        b = episodes(grp, EXT[pre]) if pre in EXT else None
        ab = pd.concat([a, b], ignore_index=True) if b is not None else None
        stages.append(dict(stage=st_name, group=grp, official_n=len(a), official_crashes=int((a.outcome == "crash").sum()),
                           ext_n=None if ab is None else len(ab),
                           ext_crashes=None if ab is None else int((ab.outcome == "crash").sum())))
    summary["stages"] = stages
    OUT.mkdir(parents=True, exist_ok=True)
    json.dump(summary, open(OUT / f"headline{SFX}.json", "w"), indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
