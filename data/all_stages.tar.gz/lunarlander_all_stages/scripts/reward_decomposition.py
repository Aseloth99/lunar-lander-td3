"""Bölüm getirisini parçalara ayırır (DOĞRULAMA tohumları, seçilmiş kontrol noktası, deterministik politika).

LunarLander ödülü: R = S_{T-1} - S_0 - yakıt + 100  (iniş bölümleri için; S = şekillendirme potansiyeli)
  S = -100*mesafe - 100*hız - 100*|açı| + 10*(sol bacak) + 10*(sağ bacak)
Başlangıç potansiyeli S_0 rastgele ilk itmeye bağlıdır -> bölümün 'tavanı' bölümden bölüme değişir.
Bu betik, 280 hedefinin fizik/ödül yapısından ne kadar uzak olduğunu ölçmek içindir; model seçmez.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import json
import numpy as np
import common
from evaluate import load_for_eval


def shp(s):
    return (-100 * np.sqrt(s[0] ** 2 + s[1] ** 2) - 100 * np.sqrt(s[2] ** 2 + s[3] ** 2) - 100 * abs(s[4])
            + 10 * s[6] + 10 * s[7])


def fuel(a):
    m = (np.clip(a[0], 0.0, 1.0) + 1.0) * 0.5 if a[0] > 0.0 else 0.0
    s = float(np.clip(abs(a[1]), 0.5, 1.0)) if abs(a[1]) > 0.5 else 0.0
    return m * 0.30, s * 0.03


def decompose(run_dir):
    cfg = json.load(open(run_dir / "config.json", encoding="utf-8"))
    pol = load_for_eval(run_dir, cfg["algo"], "best")
    act = common.policy_act_fn(pol)
    env = common.make_env()
    rows = []
    for sd in common.VAL_SEEDS:
        obs, _ = env.reset(seed=int(sd))
        S0 = shp(obs)
        total, fm, fs, steps = 0.0, 0.0, 0.0, 0
        prev_obs = obs
        done = False
        while not done:
            a = act(obs)
            prev_obs = obs
            obs, r, term, trunc, _ = env.step(a)
            total += float(r)
            steps += 1
            done = term or trunc
            if not done:
                m, s = fuel(a)
                fm += m
                fs += s
        landed = term and r >= 99.999
        rows.append(dict(ret=total, S0=S0, Sfin=shp(obs) if not landed else shp(prev_obs), fuel_main=fm, fuel_side=fs,
                         steps=steps, landed=landed))
    return rows


if __name__ == "__main__":
    for algo, tag, seeds in [("sac", "zoo", [0, 1]), ("ppo", "zoo", [0, 1, 2, 3, 4]), ("td3", "zoo", [1, 2])]:
        allr = []
        for sd in seeds:
            allr += decompose(common.RUNS / algo / tag / f"seed{sd}")
        R = np.array([r["ret"] for r in allr]); S0 = np.array([r["S0"] for r in allr])
        Sf = np.array([r["Sfin"] for r in allr]); F = np.array([r["fuel_main"] + r["fuel_side"] for r in allr])
        Fm = np.array([r["fuel_main"] for r in allr]); Fs = np.array([r["fuel_side"] for r in allr])
        L = np.array([r["landed"] for r in allr])
        zero_fuel = R + F
        print(f"\n== {algo.upper()} ({len(allr)} bölüm, inen: {100 * L.mean():.0f}%) ==")
        print(f"ortalama getiri          : {R.mean():7.1f}")
        print(f"başlangıç potansiyeli S0 : {S0.mean():7.1f}  (std {S0.std():.1f}; getiriyle korelasyon {np.corrcoef(R, -S0)[0, 1]:+.2f})")
        print(f"bitiş potansiyeli        : {Sf.mean():7.1f}  (bacaklar yerde ve pistte ideal ≈ +20)")
        print(f"yakıt cezası (ana+yan)   : {F.mean():7.1f}  (ana {Fm.mean():.1f}, yan {Fs.mean():.1f})")
        print(f"'sıfır yakıtla' getiri   : {zero_fuel.mean():7.1f}  (= getiri + yakıt; yakıtsız teorik üst sınıra yakın)")
        print(f"ort. bölüm uzunluğu      : {np.mean([r['steps'] for r in allr]):7.0f} adım")
        print(f"getiri >=280 olan bölüm  : {100 * (R >= 280).mean():.0f}%   >=290: {100 * (R >= 290).mean():.0f}%")
