"""Çakılmaların nedeni: hangi bölümlerde, ne zaman, araç hangi durumdayken?
Kullanılan veri: doğrulama (5000-5099) + ESKİ test (10000-10099; artık geliştirme verisi, yeni test 20000+).
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import json
from collections import defaultdict
import numpy as np
import pandas as pd
import common
from evaluate import load_for_eval

GROUPS = ["sac/fuel2x", "ppo/tuned", "td3/tuned", "sac/zoo", "ppo/zoo"]


def replay(policy, seed):
    env = common.make_env()
    act = common.policy_act_fn(policy)
    obs, _ = env.reset(seed=int(seed))
    hist = [obs]
    done, t = False, 0
    while not done:
        obs, r, term, trunc, _ = env.step(act(obs))
        hist.append(obs)
        t += 1
        done = term or trunc
    o = hist[-2]  # çakılmadan hemen önceki durum
    first_contact = next((i for i, h in enumerate(hist) if h[6] > 0 or h[7] > 0), None)
    return dict(t=t, x=o[0], y=o[1], vx=o[2], vy=o[3], angle=o[4], legs=int(o[6] + o[7]),
                out=bool(abs(hist[-1][0]) >= 1.0), x0_push=float(hist[1][2]), first_contact=first_contact)


rows = []
crash_seeds = defaultdict(set)
for g in GROUPS:
    algo, tag = g.split("/")
    for d in sorted((common.RUNS / algo / tag).glob("seed*")):
        pol = load_for_eval(d, algo, "best")
        for f in ["val_best_episodes.csv", "test_episodes.csv"]:
            e = pd.read_csv(d / f)
            for s in e[e.outcome == "crash"].seed:
                info = replay(pol, s)
                info.update(group=g, run=d.name, ep_seed=int(s))
                rows.append(info)
                crash_seeds[int(s)].add(f"{g}/{d.name}")
df = pd.DataFrame(rows)
pd.set_option("display.width", 220)
print(f"toplam çakılma (td3 tohum4 hariç): {len(df[~((df.group == 'td3/tuned') & (df.run == 'seed4'))])}")
d2 = df[~((df.group == "td3/tuned") & (df.run == "seed4"))]
print("\nÇakılma türü: ekran dışı =", int(d2.out.sum()), "| gövde yere değdi =", int((~d2.out).sum()))
print("bacak teması (çakılma anında, 0/1/2):", d2.legs.value_counts().to_dict())
print("\nçakılma anı durumu (medyan):")
print(d2[["t", "x", "y", "vx", "vy", "angle"]].describe().loc[["50%", "min", "max"]].round(2).to_string())
print("\nAynı bölümde birden çok ajan çakıldı mı? (bölüm tohumu: çakılan koşu sayısı)")
multi = {s: len(v) for s, v in crash_seeds.items() if len(v) > 1}
print(dict(sorted(multi.items(), key=lambda kv: -kv[1])[:15]))
print(f"tekil bölüm sayısı: {len(crash_seeds)}; birden çok ajanın çakıldığı: {len(multi)}")
print("\nörnekler:")
print(d2.sort_values("ep_seed")[["group", "run", "ep_seed", "t", "x", "vx", "vy", "angle", "legs", "out", "first_contact"]].head(40).round(2).to_string(index=False))
df.to_csv(common.ROOT / "results" / "cakilma_analizi.csv", index=False)
