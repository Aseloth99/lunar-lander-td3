#!/usr/bin/env bash
# Aşama 8 SON ADIM (bir kez): v6brake/v6soft için 800k/1600k kontrol noktası seçimi -> bağımsız doğrulama (7200-9199,
# 2000/tohum) -> v6 kuralıyla seçim (results/secim_kurali_v6.md) -> FROZEN6 -> en yeni test (60000-61999, 2000/tohum) ->
# rapor + video + sayfa + çakılma tanısı. Paralellik 6 (kullanıcı: en çok ~6 çekirdek).
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
NEW="td3/v6brake td3/v6soft"
CANDS="td3/v4big@800k td3/v4big@1600k td3/v6brake@800k td3/v6brake@1600k td3/v6soft@800k td3/v6soft@1600k"
DESKTOP=<kopyalanacak_klasör>
P=6
[ "$(ls runs/td3/v6brake/seed*/DONE runs/td3/v6soft/seed*/DONE 2>/dev/null | wc -l)" = 10 ] || { echo "10 koşunun hepsi bitmemiş"; exit 1; }
[ -f FROZEN6 ] && echo "UYARI: FROZEN6 zaten var (seçim önceden yapılmış); yalnızca eksik adımlar tamamlanacak"
# 1) kontrol noktası seçimi (yalnızca 5100-5599): 800k (400k-800k) ve 1600k (800k-1.6M). v4big'inkiler Aşama 6'dan hazır.
for g in $NEW; do for d in runs/$g/seed*; do
  [ -f "$d/best_policy_800k.pt" ] || echo "$d 800k 400000 800000"
  [ -f "$d/best_policy_1600k.pt" ] || echo "$d 1600k 800000 1600000"
done; done | xargs -r -P $P -L 1 bash -c 'python3 reselect.py --run-dir $0 --suffix $1 --min-step $2 --max-step $3 >> logs/reselect_v6.log 2>&1'
# 2) bağımsız doğrulama 7200-9199 (tüm adaylar, 2000 bölüm/tohum)
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | \
  xargs -P $P -L 1 bash -c '[ -f $0/val7_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split val7 --ckpt $1 > /dev/null'
# 3) seçim ve dondurma (test tohumlarına bundan ÖNCE hiç bakılmaz)
[ -f FROZEN6 ] || python3 select_main_v6.py
[ -f FROZEN6 ] || { echo "Donduruldu (v6): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v6.json; } > FROZEN6
# 4) en yeni test: resmi (60000-60099) + ek (60100-61999); evaluate.py ikinci kez ölçmeyi reddeder
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | xargs -P $P -L 1 bash -c '
  [ -f $0/test6_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test6 --ckpt $1 > /dev/null
  [ -f $0/test6x_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test6x --ckpt $1 > /dev/null'
python3 - $CANDS <<'EOF'
import json, sys, glob, os
bad = []
for c in sys.argv[1:]:
    g, suf = c.split("@")
    for d in sorted(glob.glob(f"runs/{g}/seed*")):
        for sp, n in [("test6", 100), ("test6x", 1900)]:
            f = f"{d}/{sp}_best_{suf}_summary.json"
            if not os.path.exists(f) or json.load(open(f))["n"] != n:
                bad.append(f)
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
# 5) raporlar, video, çakılma tanısı, sonuç sayfası, masaüstü kopyası
python3 report.py --split test6 --groups $CANDS --out results/final_test6 --no-curves
python3 report.py --split test6all --groups $CANDS --out results/final_test6_1000 --no-curves > /dev/null
python3 report.py --split val7 --groups $CANDS --out results/final_val7 > /dev/null
MAIN=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v6.json'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v6.json'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/${MAIN%@*}/seed$VSEED" --ckpt "best_${MAIN#*@}" --split test6 --episodes 4 --out results/en_iyi_ajan_v6
python3 scripts/touchdown_v6.py > results/yere_degme_v6.txt 2>&1 || echo "tanı betiği hata verdi (sonuçları etkilemez)"
python3 make_dashboard.py
if [ -d "$DESKTOP" ]; then rsync -rt results/ "$DESKTOP/results/"; fi
echo "TEST6 TAMAMLANDI"
