"""Aşama 9 kontrolü: önceden kaydın zamanı, seçimin/testin sırası, küme ayrıklığı, yeni çeşitlerin ayarı, iki seçimin
(SAC şampiyonu + güvenlik önce) ham doğrulama verisinden yeniden yapılması, test tablolarının ham bölümlerden yeniden
hesaplanması, iki sonucun yeniden oynatılması ve önceden tanımlı soruların cevapları. Dosya yazmaz."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import datetime as dt  # noqa: E402
import json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

R = common.ROOT
fails = []
SAC = ["sac/v9big@800k", "sac/v9big@1600k", "sac/v9lowent@800k", "sac/v9lowent@1600k"]
CANDS = SAC + ["td3/v4big@1600k", "td3/v6brake@1600k", "sac/v4@1600k"]
NEW = ["sac/v9big", "sac/v9lowent"]
SPEC = {"steps": 1600000, "lr": 0.0003, "lr_linear": False, "buffer": 1000000, "batch": 256, "gamma": 0.995, "tau": 0.01,
        "net": [400, 300], "train_freq": 2, "gradient_steps": 1, "ent_coef": "auto"}  # secim_kurali_v7.md


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


def files(c, split):
    g, suf = c.split("@")
    return sorted((R / "runs" / g).glob(f"seed*/{split}_best_{suf}_summary.json"))


mt = lambda ps: [p.stat().st_mtime for p in ps]  # noqa: E731
rule = (R / "results" / "secim_kurali_v7.md").stat().st_mtime
starts = [json.load(open(d / "config.json"))["started"] for g in NEW for d in sorted((R / "runs" / g).glob("seed*"))]
start_ts = min(dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S").timestamp() for s in starts)
check("önceden kayıt (secim_kurali_v7.md) eğitimden önce yazılmış", rule < start_ts,
      f"kural {dt.datetime.fromtimestamp(rule):%F %T}, ilk eğitim {min(starts)}")
v8 = [t for c in CANDS for t in mt(files(c, "val8"))]
t7 = [t for c in CANDS for t in mt(files(c, "test7")) + mt(files(c, "test7x"))]
check("35 aday-koşunun hepsinde val8 ve test (100 + 1900) var", len(v8) == 35 and len(t7) == 70, f"{len(v8)}, {len(t7)}")
sel_f = R / "results" / "ana_sonuc_secimi_v7.json"
check("bağımsız doğrulama -> seçim -> FROZEN7 -> test sırası",
      max(v8) <= sel_f.stat().st_mtime <= (R / "FROZEN7").stat().st_mtime < min(t7))
old = (common.VAL_SEEDS + common.VAL2_SEEDS + common.VAL3_SEEDS + common.VAL4_SEEDS + common.VAL5_SEEDS + common.VAL6_SEEDS +
       common.VAL7_SEEDS + common.TEST_SEEDS + common.TEST2_SEEDS + common.TEST2X_SEEDS + common.TEST3_SEEDS +
       common.TEST3X_SEEDS + common.TEST4_SEEDS + common.TEST4X_SEEDS + common.TEST5_SEEDS + common.TEST5X_SEEDS +
       common.TEST6_SEEDS + common.TEST6X_SEEDS)
new = set(common.VAL8_SEEDS + common.TEST7_SEEDS + common.TEST7X_SEEDS)
check("70000-71999 ve 80000-81999 önceki hiçbir kümeyle çakışmıyor", not (new & set(old)))

for g in NEW:
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = json.load(open(d / "config.json"))["cfg"]
        bad = {k: a.get(k) for k, v in SPEC.items() if a.get(k) != v}
        te = a.get("target_entropy")
        check(f"{g} {d.name}: ayar kurala uygun (entropi hedefi {te if te is not None else 'otomatik (−2)'})",
              not bad and te == (-4.0 if g == "sac/v9lowent" else None) and "train_touchdown_k" not in a, str(bad))
        for sx, lo, hi in [("800k", 400000, 800000), ("1600k", 800000, 1600000)]:
            st = json.load(open(d / f"selection_{sx}.json"))["chosen"]["step"]
            check(f"{g} {d.name}: {sx} seçimi {lo // 1000}k-{hi // 1000}k aralığında ({st})", lo <= st <= hi)

# iki seçimi ham val8 verisinden yeniden yap (kural v7)
rows = []
for c in CANDS:
    g, suf = c.split("@")
    per = []
    for d in sorted((R / "runs" / g).glob("seed*")):
        e = pd.read_csv(d / f"val8_best_{suf}_episodes.csv")
        assert list(e.seed) == common.VAL8_SEEDS
        per.append(dict(crash=int((e.outcome == "crash").sum()), below=int((e.ret < 200).sum()), mean=e.ret.mean()))
    ok = all(p["mean"] >= 280 for p in per)
    rows.append((c, ok, sum(p["crash"] for p in per), sum(p["below"] for p in per), np.mean([p["mean"] for p in per])))
sel = json.load(open(sel_f))
sac = sorted([r for r in rows if r[0] in SAC], key=lambda r: (0 if r[1] else 1, -r[4]))
check("kural 1 (SAC şampiyonu) ham val8'den yeniden: aynı", sac[0][0] == sel["sac_champion"],
      f"yeniden: {sac[0][0]}, kayıt: {sel['sac_champion']}")
rows.sort(key=lambda r: (0 if r[1] else 1, r[2], r[3], -r[4]))
check("kural 2 (güvenlik önce) ham val8'den yeniden: aynı", rows[0][0] == sel["main"], f"yeniden: {rows[0][0]}, kayıt: {sel['main']}")
check("sıralamanın tamamı aynı", [r[0] for r in rows] == sel["ranking"])
for r in rows:
    print(f"       {r[0]:20s} uygun={'EVET' if r[1] else 'hayır':5s} çakılma {r[2]}  200 altı {r[3]}  ort {r[4]:.2f}")

print("\nTEST (ham bölümlerden): resmi 80000-80099 | genişletilmiş 80000-81999")
res = {}
for c in CANDS:
    g, suf = c.split("@")
    m100, mall, c100, call, b100, ball, cfree = [], [], 0, 0, 0, 0, 0
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / f"test7_best_{suf}_episodes.csv")
        b = pd.read_csv(d / f"test7x_best_{suf}_episodes.csv")
        assert list(a.seed) == common.TEST7_SEEDS and list(b.seed) == common.TEST7X_SEEDS
        ab = pd.concat([a, b])
        m100.append(a.ret.mean()); mall.append(ab.ret.mean())
        c100 += int((a.outcome == "crash").sum()); call += int((ab.outcome == "crash").sum())
        b100 += int((a.ret < 200).sum()); ball += int((ab.ret < 200).sum())
        cfree += int((ab.outcome == "crash").sum() == 0)
    ci = lambda x: stats.t.ppf(0.975, len(x) - 1) * np.std(x, ddof=1) / np.sqrt(len(x))  # noqa: E731
    res[c] = dict(m100=np.mean(m100), c100=c100, mall=np.mean(mall), call=call, ball=ball, seeds=mall)
    print(f"  {c:20s} {np.mean(m100):6.1f} ± {ci(m100):.1f} | çakılma {c100}/500 | 200 altı {b100}/500 || "
          f"{np.mean(mall):6.1f} ± {ci(mall):.1f} | çakılma {call}/10000 | 200 altı {ball}/10000 | çakılmasız tohum {cfree}/5")

for who in ("main", "sac_champion"):
    c = sel[who]
    g, suf = c.split("@")
    maxdiff, nrep = 0.0, 0
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / f"test7_best_{suf}_episodes.csv")
        rr = common.evaluate_episodes(common.policy_act_fn(load_for_eval(d, g.split("/")[0], f"best_{suf}")), common.TEST7_SEEDS)
        maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rr]) - a.ret.values))))
        nrep += len(rr)
    check(f"{who} ({c}) yeniden oynatıldı: aynı puanlar", maxdiff < 1e-6, f"{nrep} bölüm, en büyük fark {maxdiff:.1e}")

ch, td3, old_sac = res[sel["sac_champion"]], res["td3/v4big@1600k"], res["sac/v4@1600k"]
lo, big = res["sac/v9lowent@1600k"], res["sac/v9big@1600k"]
print(f"\nÖNCEDEN TANIMLI SORULAR (genişletilmiş test, 10 000 bölüm; SAC şampiyonu {sel['sac_champion']}):")
print(f"  'SAC, TD3'ü puanda geçti mi?' {ch['mall']:.2f} vs td3/v4big@1600k {td3['mall']:.2f} -> "
      f"{'EVET' if ch['mall'] > td3['mall'] else 'HAYIR'} (fark {ch['mall'] - td3['mall']:+.2f})")
print(f"  'Büyük ağ SAC'ı iyileştirdi mi?' {ch['mall']:.2f} vs sac/v4@1600k {old_sac['mall']:.2f} -> "
      f"{'EVET' if ch['mall'] > old_sac['mall'] else 'HAYIR'} (fark {ch['mall'] - old_sac['mall']:+.2f})")
print(f"  'Düşük entropi işe yaradı mı?' v9lowent@1600k {lo['mall']:.2f} vs v9big@1600k {big['mall']:.2f} -> "
      f"{'EVET' if lo['mall'] > big['mall'] else 'HAYIR'} (fark {lo['mall'] - big['mall']:+.2f})")
m = res[sel["main"]]
print(f"  ana sonuç (kural 2) {sel['main']}: ort {m['mall']:.2f}, çakılma {m['call']}/10000, 200 altı {m['ball']}/10000, "
      f"tohum ort. {[round(x, 1) for x in m['seeds']]}")
print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
