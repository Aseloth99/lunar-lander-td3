#!/usr/bin/env bash
# Yeniden başlatma sonrası Aşama 6'ya devam: biten koşular atlanır, yarım kalanlar resume/ kayıtlarından sürer.
# Bekçi (wait_stage6_bg.sh) oturumdan bağımsız arka planda çalışır; kuyruk bitince son adımı (finalize_test4.sh) yapar.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
echo "== yarım koşuların devam dosyaları =="
for g in td3/v4big td3/v4small sac/v4; do for d in runs/$g/seed*; do
  if [ ! -f "$d/DONE" ]; then
    m=$(python3 -c "import zipfile,json;print(json.loads(zipfile.ZipFile('$d/resume/model.zip').read('data')).get('num_timesteps'))" 2>/dev/null)
    echo "$d: model.zip adım=$m buffer=$([ -f $d/resume/buffer.pkl ] && du -h $d/resume/buffer.pkl | cut -f1 || echo YOK)"
  fi
done; done
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
echo "$(date '+%F %T') YENİDEN BAŞLATMA SONRASI DEVAM" >> logs/queue.log
bash scripts/start_queue.sh jobs/stage6.txt 6
bash scripts/start_status.sh
cat > logs/wait_stage6_bg.sh << 'EOF'
#!/bin/bash
cd <proje_klasörü>
sleep 30
while pgrep -f "queue_runner.py" > /dev/null; do sleep 120; done
if grep -q "kuyruk tamamlandı" logs/queue.log && [ "$(ls runs/td3/v4big/seed*/DONE runs/td3/v4small/seed*/DONE runs/sac/v4/seed*/DONE 2>/dev/null | wc -l)" = 15 ]; then
  bash scripts/finalize_test4.sh > logs/finalize_test4.log 2>&1 && echo "TEST4 BEKÇİ: TAMAM" >> logs/finalize_test4.log
else
  echo "KUYRUK EKSİK BİTTİ: $(ls runs/*/v4*/seed*/DONE 2>/dev/null | wc -l)/15" > logs/finalize_test4.log
fi
EOF
setsid nohup bash logs/wait_stage6_bg.sh > /dev/null 2>&1 < /dev/null &
sleep 25
echo "== çalışanlar =="; pgrep -af "train.py|wait_stage6_bg" | cut -c1-120
grep -h "devam" logs/td3_v4big_seed3.log logs/sac_v4_seed4.log 2>/dev/null | tail -2
