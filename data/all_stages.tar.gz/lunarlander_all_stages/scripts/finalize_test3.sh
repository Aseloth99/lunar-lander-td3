#!/usr/bin/env bash
# Aşama 5 SON ADIM (bir kez): kontrol noktası seçimi -> bağımsız doğrulama (6000-6399) -> v3 kuralıyla seçim ->
# FROZEN3 -> en yeni test (30000-30999) -> rapor + video + sonuç sayfası.
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
CANDS="td3/v2b td3/v3long td3/v3big td3/v3fuel"
NEW="td3/v3long td3/v3big td3/v3fuel"
for g in $NEW; do for d in runs/$g/seed*; do
  if [ -f "$d/DONE" ] && [ ! -f "$d/best_policy_v2.pt" ]; then echo "$d"; fi; done; done | \
  xargs -r -P 4 -I{} bash -c 'python3 reselect.py --run-dir {} >> logs/reselect_v3.log 2>&1'
ls -d $(for g in $CANDS; do echo runs/$g/seed*; done) | xargs -P 4 -I{} bash -c \
  '[ -f {}/val4_best_v2_summary.json ] || python3 evaluate.py --run-dir {} --split val4 --ckpt best_v2 > /dev/null'
python3 select_main_v3.py
[ -f FROZEN3 ] || { echo "Donduruldu (v3): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v3.json; } > FROZEN3
ls -d $(for g in $CANDS; do echo runs/$g/seed*; done) | xargs -P 4 -I{} bash -c '
  [ -f {}/test3_summary.json ] || python3 evaluate.py --run-dir {} --split test3 --ckpt best_v2 > /dev/null
  [ -f {}/test3x_summary.json ] || python3 evaluate.py --run-dir {} --split test3x --ckpt best_v2 > /dev/null'
python3 - $CANDS <<'EOF'
import json, sys, glob
bad = [f"{d}/{sp}" for g in sys.argv[1:] for d in sorted(glob.glob(f"runs/{g}/seed*")) for sp, n in [("test3", 100), ("test3x", 900)]
       if not glob.glob(f"{d}/{sp}_summary.json") or json.load(open(f"{d}/{sp}_summary.json"))["ckpt"] != "best_v2"
       or json.load(open(f"{d}/{sp}_summary.json"))["n"] != n]
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
python3 report.py --split test3 --groups $CANDS --out results/final_test3 --no-curves
python3 report.py --split test3all --groups $CANDS --out results/final_test3_1000 --no-curves > /dev/null
python3 report.py --split val4 --groups $CANDS --out results/final_val4 > /dev/null
MAIN=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v3.json'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v3.json'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/$MAIN/seed$VSEED" --ckpt best_v2 --split test3 --episodes 4 --out results/en_iyi_ajan_v3
python3 make_dashboard.py
echo "TEST3 TAMAMLANDI"
