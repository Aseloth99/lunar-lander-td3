"""Aşama 6 kontrolü: TD3 büyük ağ · 800 bin sonuçlarını ham veriden yeniden hesaplar, yeniden oynatır, sırayı ve seçim
aralığını denetler; ayrıca yakıt/iniş karşılaştırması (doğrulama 5000-5099). Dosya yazmaz."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import hashlib, json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402
import reward_decomposition as rd  # noqa: E402

R = common.ROOT
fails = []


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


sel = json.load(open(R / "results" / "ana_sonuc_secimi_v4.json"))
check("ana sonuç = td3/v4big@800k", sel["main"] == "td3/v4big@800k")
cands = ["td3/v3long@v2", "td3/v4big@800k", "td3/v4big@1600k", "td3/v4small@800k", "td3/v4small@1600k",
         "sac/v4@800k", "sac/v4@1600k", "ppo/tuned@v2"]
t4 = [p.stat().st_mtime for c in cands for p in (R / "runs" / c.split("@")[0]).glob(f"seed*/test4_best_{c.split('@')[1]}_summary.json")]
v5 = [p.stat().st_mtime for c in cands for p in (R / "runs" / c.split("@")[0]).glob(f"seed*/val5_best_{c.split('@')[1]}_summary.json")]
check("40 aday-koşunun hepsinde test var", len(t4) == 40, str(len(t4)))
check("bağımsız doğrulama ve seçim testten önce", max(v5) < min(t4) and (R / "results" / "ana_sonuc_secimi_v4.json").stat().st_mtime < min(t4))
check("FROZEN4 testten önce", (R / "FROZEN4").stat().st_mtime < min(t4))
check("ek kural (başarı %100) dosyası seçimden önce yazılmış",
      (R / "results" / "secim_kurali_v4_ek.md").stat().st_mtime < min(v5))
allsets = (common.VAL_SEEDS + common.VAL2_SEEDS + common.VAL3_SEEDS + common.VAL4_SEEDS + common.VAL5_SEEDS + common.TEST_SEEDS +
           common.TEST2_SEEDS + common.TEST2X_SEEDS + common.TEST3_SEEDS + common.TEST3X_SEEDS)
check("40000-40999 hiçbir önceki kümeyle çakışmıyor", not (set(common.TEST4_SEEDS + common.TEST4X_SEEDS) & set(allsets)))

means, c100, c1000, below = [], 0, 0, 0
maxdiff, crashes_replay = 0.0, 0
for d in sorted((R / "runs" / "td3" / "v4big").glob("seed*")):
    a = pd.read_csv(d / "test4_best_800k_episodes.csv")
    b = pd.read_csv(d / "test4x_best_800k_episodes.csv")
    check(f"{d.name}: tohum listesi doğru", list(a.seed) == list(range(40000, 40100)) and list(b.seed) == list(range(40100, 41000)))
    means.append(a.ret.mean())
    c100 += int((a.outcome == "crash").sum())
    c1000 += int((a.outcome == "crash").sum() + (b.outcome == "crash").sum())
    below += int((a.ret < 200).sum() + (b.ret < 200).sum())
    cfg = json.load(open(d / "config.json"))["cfg"]
    check(f"{d.name}: orijinal ödül, ağ [400,300], 1.6M adımlık koşu",
          float(cfg.get("train_fuel_k", 0)) == 0 and cfg["net"] == [400, 300] and cfg["steps"] == 1600000)
    s = json.load(open(d / "selection_800k.json"))
    ck, step = s["chosen"]["ckpt"], s["chosen"]["step"]
    check(f"{d.name}: seçilen an 400k-800k aralığında ({step})", 400000 <= step <= 800000)
    if (d / "ckpt" / ck).exists():
        check(f"{d.name}: best_policy_800k.pt = {ck}",
              hashlib.md5(open(d / "best_policy_800k.pt", "rb").read()).hexdigest() == hashlib.md5(open(d / "ckpt" / ck, "rb").read()).hexdigest())
    rows = common.evaluate_episodes(common.policy_act_fn(load_for_eval(d, "td3", "best_800k")), common.TEST4_SEEDS)
    maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rows]) - a.ret.values))))
    crashes_replay += sum(r["outcome"] == "crash" for r in rows)
m, ci = np.mean(means), stats.t.ppf(0.975, 4) * np.std(means, ddof=1) / np.sqrt(5)
check("resmi test: 288.5 ± 1.1", f"{m:.1f}" == "288.5" and f"{ci:.1f}" == "1.1", f"{m:.2f} ± {ci:.2f}")
check("resmi test 0/500 çakılma; 5000 bölümde 0 çakılma", c100 == 0 and c1000 == 0, f"{c100}, {c1000}")
check("5000 bölümün HİÇBİRİ 200'ün altında değil (başarı %100)", below == 0, str(below))
check("yeniden oynatma aynı puanlar, 0 çakılma", maxdiff < 1e-6 and crashes_replay == 0, f"{maxdiff:.1e}, {crashes_replay}")

print("\nNEDEN (doğrulama 5000-5099, seçilmiş modeller):")
for g, ck in [("td3/v3long", "best_v2"), ("td3/v4big", "best_800k"), ("td3/v4big", "best_1600k"), ("sac/v4", "best_1600k")]:
    rd.load_for_eval = lambda run_dir, algo, _c, ck=ck: load_for_eval(run_dir, algo, ck)
    rows = [r for k in range(5) for r in rd.decompose(R / "runs" / g / f"seed{k}")]
    print(f"  {g:11s} {ck:10s} puan {np.mean([r['ret'] for r in rows]):.1f} | yakıt {np.mean([r['fuel_main'] + r['fuel_side'] for r in rows]):.1f} | "
          f"iniş sapması {np.mean([20 - r['Sfin'] for r in rows]):.1f} | adım {np.mean([r['steps'] for r in rows]):.0f} | "
          f"en kötü {min(r['ret'] for r in rows):.0f}")
print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
