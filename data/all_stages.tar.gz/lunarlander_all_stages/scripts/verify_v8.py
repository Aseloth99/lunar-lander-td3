"""Aşama 10 kontrolü: önceden kaydın zamanı, seçimin/testin sırası, küme ayrıklığı, yeni çeşitlerin ayarı, iki seçimin
(frenli SAC seçimi + güvenlik önce) ham doğrulama verisinden yeniden yapılması, test tablolarının ham bölümlerden yeniden
hesaplanması, iki sonucun yeniden oynatılması ve önceden tanımlı soruların cevapları. Dosya yazmaz."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import datetime as dt  # noqa: E402
import json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

R = common.ROOT
fails = []
NEW4 = ["sac/v10brake@800k", "sac/v10brake@1600k", "sac/v10soft@800k", "sac/v10soft@1600k"]
CANDS = NEW4 + ["td3/v4big@1600k", "td3/v6brake@1600k", "td3/v6soft@800k", "sac/v9lowent@800k", "sac/v9lowent@1600k",
                "sac/v9big@800k", "sac/v9big@1600k"]
NEW = ["sac/v10brake", "sac/v10soft"]
SPEC = {"steps": 1600000, "lr": 0.0003, "lr_linear": False, "buffer": 1000000, "batch": 256, "gamma": 0.995, "tau": 0.01,
        "net": [400, 300], "train_freq": 2, "gradient_steps": 1, "ent_coef": "auto", "target_entropy": -4.0}
PEN = {"sac/v10brake": (100.0, 0.25), "sac/v10soft": (50.0, 0.30)}  # secim_kurali_v8.md


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


def files(c, split):
    g, suf = c.split("@")
    return sorted((R / "runs" / g).glob(f"seed*/{split}_best_{suf}_summary.json"))


mt = lambda ps: [p.stat().st_mtime for p in ps]  # noqa: E731
rule = (R / "results" / "secim_kurali_v8.md").stat().st_mtime
# ilk başlama: her koşunun ilk monitör parçasındaki t_start (config.json'daki "started" devam ettirmede yenilenir)
t0 = min(json.loads(open(d / "monitor" / "part0" / "0.monitor.csv").readline().lstrip("#"))["t_start"]
         for g in NEW for d in sorted((R / "runs" / g).glob("seed*")))
check("önceden kayıt (secim_kurali_v8.md) eğitimden önce yazılmış", rule < t0,
      f"kural {dt.datetime.fromtimestamp(rule):%F %T}, ilk eğitim {dt.datetime.fromtimestamp(t0):%F %T}")
v9 = [t for c in CANDS for t in mt(files(c, "val9"))]
t8 = [t for c in CANDS for t in mt(files(c, "test8")) + mt(files(c, "test8x"))]
check("55 aday-koşunun hepsinde val9 ve test (100 + 1900) var", len(v9) == 55 and len(t8) == 110, f"{len(v9)}, {len(t8)}")
sel_f = R / "results" / "ana_sonuc_secimi_v8.json"
check("bağımsız doğrulama -> seçim -> FROZEN8 -> test sırası",
      max(v9) <= sel_f.stat().st_mtime <= (R / "FROZEN8").stat().st_mtime < min(t8))
NEWSETS = ("VAL9_SEEDS", "TEST8_SEEDS", "TEST8X_SEEDS")
old = set(s for n in dir(common) if n.endswith("_SEEDS") and n not in NEWSETS for s in getattr(common, n))
new = set(s for n in NEWSETS for s in getattr(common, n))
check("90000-91999 ve 100000-101999 önceki hiçbir kümeyle çakışmıyor", not (new & old) and len(new) == 4000,
      f"önceki {len(old)} tohum")

for g in NEW:
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = json.load(open(d / "config.json"))["cfg"]
        bad = {k: a.get(k) for k, v in SPEC.items() if a.get(k) != v}
        k, v0 = PEN[g]
        check(f"{g} {d.name}: ayar kurala uygun (ceza {k:g} × (|vy| − {v0:g}))",
              not bad and a.get("train_touchdown_k") == k and a.get("train_touchdown_v0") == v0, str(bad))
        for sx, lo, hi in [("800k", 400000, 800000), ("1600k", 800000, 1600000)]:
            st = json.load(open(d / f"selection_{sx}.json"))["chosen"]["step"]
            check(f"{g} {d.name}: {sx} seçimi {lo // 1000}k-{hi // 1000}k aralığında ({st})", lo <= st <= hi)

# iki seçimi ham val9 verisinden yeniden yap (kural v8)
rows = []
for c in CANDS:
    g, suf = c.split("@")
    per = []
    for d in sorted((R / "runs" / g).glob("seed*")):
        e = pd.read_csv(d / f"val9_best_{suf}_episodes.csv")
        assert list(e.seed) == common.VAL9_SEEDS
        per.append(dict(crash=int((e.outcome == "crash").sum()), below=int((e.ret < 200).sum()), mean=e.ret.mean()))
    ok = all(p["mean"] >= 280 for p in per)
    rows.append((c, ok, sum(p["crash"] for p in per), sum(p["below"] for p in per), np.mean([p["mean"] for p in per])))
sel = json.load(open(sel_f))
key = lambda r: (0 if r[1] else 1, r[2], r[3], -r[4])  # noqa: E731
r1 = sorted([r for r in rows if r[0] in NEW4], key=key)
check("kural 1 (frenli SAC seçimi) ham val9'dan yeniden: aynı", r1[0][0] == sel["stage10_pick"],
      f"yeniden: {r1[0][0]}, kayıt: {sel['stage10_pick']}")
check("kural 1 sıralamasının tamamı aynı", [r[0] for r in r1] == sel["stage10_ranking"])
rows.sort(key=key)
check("kural 2 (güvenlik önce) ham val9'dan yeniden: aynı", rows[0][0] == sel["main"], f"yeniden: {rows[0][0]}, kayıt: {sel['main']}")
check("kural 2 sıralamasının tamamı aynı", [r[0] for r in rows] == sel["ranking"])
for r in rows:
    print(f"       {r[0]:20s} uygun={'EVET' if r[1] else 'hayır':5s} çakılma {r[2]}  200 altı {r[3]}  ort {r[4]:.2f}")

print("\nTEST (ham bölümlerden): resmi 100000-100099 | genişletilmiş 100000-101999")
ci = lambda x: stats.t.ppf(0.975, len(x) - 1) * np.std(x, ddof=1) / np.sqrt(len(x))  # noqa: E731
res = {}
for c in CANDS:
    g, suf = c.split("@")
    m100, mall, c100, call, b100, ball, cfree, worst = [], [], 0, 0, 0, 0, 0, 1e9
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / f"test8_best_{suf}_episodes.csv")
        b = pd.read_csv(d / f"test8x_best_{suf}_episodes.csv")
        assert list(a.seed) == common.TEST8_SEEDS and list(b.seed) == common.TEST8X_SEEDS
        ab = pd.concat([a, b])
        m100.append(a.ret.mean()); mall.append(ab.ret.mean())
        c100 += int((a.outcome == "crash").sum()); call += int((ab.outcome == "crash").sum())
        b100 += int((a.ret < 200).sum()); ball += int((ab.ret < 200).sum())
        cfree += int((ab.outcome == "crash").sum() == 0)
        worst = min(worst, ab.ret.min())
    res[c] = dict(m100=np.mean(m100), c100=c100, mall=np.mean(mall), call=call, ball=ball, seeds=mall, worst=worst)
    print(f"  {c:20s} {np.mean(m100):6.1f} ± {ci(m100):.1f} | çakılma {c100}/500 | 200 altı {b100}/500 || "
          f"{np.mean(mall):6.1f} ± {ci(mall):.1f} | çakılma {call}/10000 | 200 altı {ball}/10000 | "
          f"çakılmasız tohum {cfree}/5 | en kötü {worst:.1f}")

for who in ("main", "stage10_pick"):
    c = sel[who]
    g, suf = c.split("@")
    maxdiff, nrep = 0.0, 0
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / f"test8_best_{suf}_episodes.csv")
        rr = common.evaluate_episodes(common.policy_act_fn(load_for_eval(d, g.split("/")[0], f"best_{suf}")), common.TEST8_SEEDS)
        maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rr]) - a.ret.values))))
        nrep += len(rr)
    check(f"{who} ({c}) yeniden oynatıldı: aynı puanlar", maxdiff < 1e-6, f"{nrep} bölüm, en büyük fark {maxdiff:.1e}")

p, top = res[sel["stage10_pick"]], res["td3/v4big@1600k"]
br, so, lo = res["sac/v10brake@1600k"], res["sac/v10soft@1600k"], res["sac/v9lowent@1600k"]
print(f"\nÖNCEDEN TANIMLI SORULAR (genişletilmiş test, 10 000 bölüm; kural 1 seçimi {sel['stage10_pick']}):")
s1, s2 = p["mall"] >= top["mall"], p["call"] == 0
print(f"  'Hem yüksek puan hem sıfır çakılma?' {'EVET' if s1 and s2 else 'HAYIR'} — puan şartı "
      f"{'sağlandı' if s1 else 'sağlanmadı'} ({p['mall']:.2f} vs td3/v4big@1600k {top['mall']:.2f}, fark "
      f"{p['mall'] - top['mall']:+.2f}); çakılma şartı {'sağlandı' if s2 else 'sağlanmadı'} ({p['call']}/10000)")
for sx in ("1600k", "800k"):
    base = res[f"sac/v9lowent@{sx}"]
    for v in ("v10brake", "v10soft"):
        x = res[f"sac/{v}@{sx}"]
        print(f"  'Fren ne kazandırdı?' {v}@{sx}: çakılma {x['call']} (cezasız {base['call']}), ortalama "
              f"{x['mall']:.2f} vs {base['mall']:.2f} (fark {x['mall'] - base['mall']:+.2f})")
strong = (br["call"], -br["mall"]) < (so["call"], -so["mall"])
print(f"  'Güçlü mü hafif mi?' @1600k: güçlü {br['call']} çakılma / {br['mall']:.2f}, hafif {so['call']} / "
      f"{so['mall']:.2f} -> {'GÜÇLÜ' if strong else 'HAFİF'}")
sb = res["td3/v6brake@1600k"]
print(f"  'Frenli SAC, en güvenli TD3 kadar güvenli mi?' {p['call']} vs td3/v6brake@1600k {sb['call']} -> "
      f"{'EVET' if p['call'] <= sb['call'] else 'HAYIR'}")
m = res[sel["main"]]
print(f"  ana sonuç (kural 2) {sel['main']}: ort {m['mall']:.2f}, çakılma {m['call']}/10000, 200 altı {m['ball']}/10000, "
      f"en kötü {m['worst']:.1f}, tohum ort. {[round(x, 1) for x in m['seeds']]}")
best = max(res, key=lambda c: res[c]["mall"])
print(f"  en yüksek ortalama: {best} {res[best]['mall']:.2f} (çakılma {res[best]['call']}/10000)")

print("\nEK: ÖNCEKİ BAĞIMSIZ TESTLERLE KARŞILAŞTIRMA (aday başına bölüm, ortalama, çakılma)")
for c in CANDS[4:]:
    g, suf = c.split("@")
    out = []
    for name, sp in (("Aşama 8 testi", ("test6", "test6x")), ("Aşama 9 testi", ("test7", "test7x")),
                     ("Aşama 10 testi", ("test8", "test8x"))):
        ds = sorted((R / "runs" / g).glob("seed*"))
        fs = [d / f"{s}_best_{suf}_episodes.csv" for d in ds for s in sp]
        if all(f.exists() for f in fs):
            e = pd.concat([pd.read_csv(f) for f in fs])
            out.append(f"{name}: {len(e)} / {e.ret.mean():.2f} / {int((e.outcome == 'crash').sum())}")
    print(f"  {c:20s} " + " | ".join(out))

print("\nEK: TÜM BAĞIMSIZ DOĞRULAMA + TEST BÖLÜMLERİNDE ÇAKILMA (seçim için kullanılan 5100-5599 hariç)")
for c in ("td3/v6soft@800k", "td3/v4big@1600k"):
    g, suf = c.split("@")
    n = k = 0
    used = []
    for f in sorted((R / "runs" / g).glob(f"seed*/*_best_{suf}_episodes.csv")):
        sp = f.name.split("_best_")[0]
        if not (sp.startswith("val") and sp[3:].isdigit() and int(sp[3:]) >= 2 or sp.startswith("test")):
            continue
        e = pd.read_csv(f)
        n += len(e); k += int((e.outcome == "crash").sum())
        used.append(sp)
    print(f"  {c:20s} {k} çakılma / {n} bölüm  (kümeler: {', '.join(sorted(set(used)))})")
print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
