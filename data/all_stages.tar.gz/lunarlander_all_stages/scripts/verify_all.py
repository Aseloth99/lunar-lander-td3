"""Son kontrol: sonuçların doğruluğunu ham verilerden ve yeniden çalıştırarak bağımsızca doğrular. Dosya YAZMAZ.
  python3 scripts/verify_all.py
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import hashlib, json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

R = common.ROOT
fails = []


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


print("1) Değerlendirme ortamı")
env = common.make_env()
chain, e = [], env
while hasattr(e, "env"):
    chain.append(type(e).__name__)
    e = e.env
chain.append(type(e).__name__)
check("ortam zinciri değiştirilmemiş (yakıt sarmalayıcısı yok)", "ExtraFuelPenalty" not in chain, " > ".join(chain))
check("LunarLander-v3, sürekli, 1000 adım sınırı",
      env.spec.id == "LunarLander-v3" and env.unwrapped.continuous and env.spec.max_episode_steps == 1000)
check("rüzgâr/türbülans kapalı (varsayılan ortam)", not env.unwrapped.enable_wind)

print("2) Tohum kümeleri birbirinden ayrık")
sets = dict(egitim=set(range(0, 5)), optuna=set(range(100, 112)), val=set(common.VAL_SEEDS), val2=set(common.VAL2_SEEDS),
            val3=set(common.VAL3_SEEDS), test=set(common.TEST_SEEDS), test2=set(common.TEST2_SEEDS),
            test2x=set(common.TEST2X_SEEDS))
names = list(sets)
overlap = [(a, b) for i, a in enumerate(names) for b in names[i + 1:] if sets[a] & sets[b]]
check("hiçbir küme çakışmıyor", not overlap, str(overlap) if overlap else "")
# PPO 16 paralel ortamla eğitimde tohum+0..15 kullanır -> en fazla 19
check("eğitim ortamı tohumları (en çok 4+15=19) doğrulama/test ile çakışmıyor", 19 < min(common.VAL_SEEDS))

print("3) Seçim sırası (test, seçimden SONRA)")
f2 = R / "FROZEN2"
sel = R / "results" / "ana_sonuc_secimi_v2.json"
check("FROZEN2 ve seçim dosyası var", f2.exists() and sel.exists())
groups = ["td3/v2b", "td3/v2a", "ppo/tuned", "sac/fuel2x", "td3/tuned"]
t_sel = sel.stat().st_mtime
t2 = [p.stat().st_mtime for g in groups for p in (R / "runs" / g).glob("seed*/test2_summary.json")]
r2 = [p.stat().st_mtime for g in groups for p in (R / "runs" / g).glob("seed*/selection_v2.json")]
check("25 koşunun hepsinde yeni test var", len(t2) == 25, f"{len(t2)}")
check("tüm kontrol noktası seçimleri testten önce", max(r2) < min(t2))
check("grup seçimi testten önce", t_sel < min(t2))
check("ana sonuç = td3/v2b", json.load(open(sel))["main"] == "td3/v2b")
ok_val = all(json.load(open(p))["val_seeds"] == [5100, 5599] for g in groups for p in (R / "runs" / g).glob("seed*/selection_v2.json"))
check("kontrol noktası seçimi yalnızca 5100-5599 ile", ok_val)

print("4) Ham veriden yeniden hesap (yeni test)")
for g in groups:
    rows = []
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / "test2_episodes.csv")
        b = pd.read_csv(d / "test2x_episodes.csv")
        seeds_ok = list(a.seed) == list(range(20000, 20100)) and list(b.seed) == list(range(20100, 21000))
        rows.append(dict(seed=d.name, ok=seeds_ok, mean=a.ret.mean(), crash=int((a.outcome == "crash").sum()),
                         succ=(a.ret >= 200).mean(), crash1000=int((a.outcome == "crash").sum() + (b.outcome == "crash").sum())))
    df = pd.DataFrame(rows)
    m, s = df["mean"].mean(), df["mean"].std(ddof=1)
    from scipy import stats
    ci = stats.t.ppf(0.975, 4) * s / np.sqrt(5)
    check(f"{g}: tohum listeleri doğru (20000-20099, 20100-20999)", df.ok.all())
    print(f"        {g:11s} ort {m:.1f} ± {ci:.1f} | çakılma {df.crash.sum()}/500 | başarı {100 * df.succ.mean():.1f}% | "
          f"1000'lik test çakılma {df.crash1000.sum()}/5000 | tohum ort. {[round(x, 1) for x in df['mean']]}")
    if g == "td3/v2b":
        check("README: TD3 v2b 283.1 ± 3.7", f"{m:.1f}" == "283.1" and f"{ci:.1f}" == "3.7", f"{m:.2f} ± {ci:.2f}")
        check("README: TD3 v2b 0/500 çakılma, %100 başarı", df.crash.sum() == 0 and df.succ.mean() == 1.0)
        check("README: TD3 v2b 2/5000 çakılma", df.crash1000.sum() == 2, str(df.crash1000.sum()))
        n_target = int(((df["mean"] >= 280) & (df.succ >= 0.99) & (df.crash == 0)).sum())
        check("README: tam hedef 4/5 tohum", n_target == 4, str(n_target))

print("5) Yeniden çalıştırma: TD3 v2b'nin 5 tohumu, 100 yeni test bölümü (dosyaya yazılmaz)")
maxdiff, crashes = 0.0, 0
for d in sorted((R / "runs" / "td3" / "v2b").glob("seed*")):
    pol = load_for_eval(d, "td3", "best_v2")
    rows = common.evaluate_episodes(common.policy_act_fn(pol), common.TEST2_SEEDS)
    old = pd.read_csv(d / "test2_episodes.csv")
    maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rows]) - old.ret.values))))
    crashes += sum(r["outcome"] == "crash" for r in rows)
    sel_ck = json.load(open(d / "selection_v2.json"))["chosen"]["ckpt"]
    if (d / "ckpt" / sel_ck).exists():
        same = hashlib.md5(open(d / "best_policy_v2.pt", "rb").read()).hexdigest() == \
            hashlib.md5(open(d / "ckpt" / sel_ck, "rb").read()).hexdigest()
        check(f"{d.name}: best_policy_v2.pt = seçilen kontrol noktası ({sel_ck})", same)
    else:
        print(f"  --  {d.name}: ara kayıtlar temizlendiği için model-dosya eşleşmesi atlandı (temizlikten önce geçmişti)")
    cfg = json.load(open(d / "config.json"))["cfg"]
    check(f"{d.name}: orijinal ödülle eğitildi (yakıt cezası yok)", float(cfg.get("train_fuel_k", 0)) == 0.0)
check("yeniden çalıştırınca aynı puanlar (deterministik)", maxdiff < 1e-6, f"maks fark {maxdiff:.2e}")
check("yeniden çalıştırınca 0 çakılma", crashes == 0, str(crashes))

print("6) Çakılma sınıflandırması ortamın iç durumuyla tutarlı mı?")
d = R / "runs" / "td3" / "v2b" / "seed4"
pol = load_for_eval(d, "td3", "best_v2")
act = common.policy_act_fn(pol)
x = pd.concat([pd.read_csv(d / "test2_episodes.csv"), pd.read_csv(d / "test2x_episodes.csv")])
sample = list(x[x.outcome == "crash"].seed) + list(x[x.outcome != "crash"].seed[:20])
bad = 0
for sd in sample:
    e = common.make_env()
    obs, _ = e.reset(seed=int(sd))
    done = False
    while not done:
        obs, r, term, trunc, _ = e.step(act(obs))
        done = term or trunc
    internal_crash = bool(term and (e.unwrapped.game_over or abs(obs[0]) >= 1.0) and e.unwrapped.lander.awake)
    recorded = x[x.seed == sd].outcome.iloc[0] == "crash"
    bad += internal_crash != recorded
check(f"{len(sample)} bölümde kayıt = ortamın iç 'game_over' durumu", bad == 0, f"uyuşmayan {bad}")

print("7) Video ve masaüstü kopyası")
v = json.load(open(R / "results" / "en_iyi_ajan_v2.json"))
t = pd.read_csv(R / v["run_dir"] / "test2_episodes.csv").head(4)
check("video puanları test kaydıyla aynı", [round(s["score"], 1) for s in v["episodes"]] == [round(s, 1) for s in t.ret],
      str([round(s["score"], 1) for s in v["episodes"]]))
dest = os.environ.get("LUNAR_SYNC_DIR", "")  # kopya klasörü yoksa atlanır
if os.path.isdir(dest):
    for rel in ["README.md", "results/final_test2/sonuc_tablosu.md", "results/en_iyi_ajan_v2.gif",
                "results/final_test3/sonuc_tablosu.md", "SONUCLAR.html"]:
        a = hashlib.md5(open(R / rel, "rb").read()).hexdigest()
        b = hashlib.md5(open(os.path.join(dest, rel), "rb").read()).hexdigest() if os.path.exists(os.path.join(dest, rel)) else None
        check(f"masaüstü kopyası güncel: {rel}", a == b)
else:
    print("  --  kopya klasörü yok, masaüstü kopyası kontrolü atlandı")

print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
