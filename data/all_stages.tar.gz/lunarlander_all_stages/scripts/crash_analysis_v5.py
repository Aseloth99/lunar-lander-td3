"""Aşama 6-7 ajanlarında kalan NADİR çakılmaların nedeni. Kullanılan veri: test4 (40000-40999) ve test5 (50000-50999)
kayıtları; ikisi de zaten kullanılmış test kümeleri (burada yalnızca TANI için yeniden oynatılır, seçim yapılmaz).
Her çakılma / 200 altı bölüm yeniden oynatılır; bitişteki durum, ilk bacak teması, son adımlardaki motor kullanımı.
Çıktı: results/cakilma_analizi_v5.csv + ekrana özet."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

GROUPS = ["td3/v4big@800k", "td3/v4big@1600k", "td3/v5big@800k", "td3/v5big@1600k"]
SPLITS = {"test4": ["test4", "test4x"], "test5": ["test5", "test5x"]}


def replay(act, seed, env):
    obs, _ = env.reset(seed=int(seed))
    u = env.unwrapped
    helipad = (u.helipad_x1, u.helipad_x2)
    H, A = [obs], []
    done = False
    while not done:
        a = act(obs)
        obs, r, term, trunc, _ = env.step(a)
        H.append(obs)
        A.append(np.asarray(a, dtype=float))
        done = term or trunc
    H, A = np.array(H), np.array(A)
    contact = np.where((H[:, 6] > 0) | (H[:, 7] > 0))[0]
    fc = int(contact[0]) if len(contact) else None
    o = H[-2]
    after = A[fc:] if fc is not None else A[:0]
    side_on = np.abs(after[:, 1]) > 0.5 if len(after) else np.array([])
    main_on = after[:, 0] > 0 if len(after) else np.array([])
    W = u.lander.position.x  # dünya koordinatı (pist bayrakları arası düz)
    return dict(steps=len(A), first_contact=fc, steps_after_contact=None if fc is None else len(A) - fc,
                x=o[0], y=o[1], vx=o[2], vy=o[3], angle=o[4], ang_vel=o[5], legs_at_end=int(o[6] + o[7]),
                max_abs_angle_after_contact=float(np.max(np.abs(H[fc:, 4]))) if fc is not None else None,
                side_frac_after_contact=float(side_on.mean()) if len(side_on) else None,
                main_frac_after_contact=float(main_on.mean()) if len(main_on) else None,
                out_of_screen=bool(abs(H[-1][0]) >= 1.0),
                on_helipad=bool(helipad[0] <= W <= helipad[1]))


def main():
    env = common.make_env()
    rows = []
    for g in GROUPS:
        base, suf = g.split("@")
        algo, tag = base.split("/")
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            act = None
            for sp, parts in SPLITS.items():
                fs = [d / f"{p}_best_{suf}_episodes.csv" for p in parts]
                if not all(f.exists() for f in fs):
                    continue
                e = pd.concat([pd.read_csv(f) for f in fs])
                bad = e[(e.outcome == "crash") | (e.ret < 200)]
                for r in bad.itertuples():
                    act = act or common.policy_act_fn(load_for_eval(d, algo, f"best_{suf}"))
                    info = replay(act, r.seed, env)
                    rows.append(dict(group=g, run=d.name, split=sp, ep_seed=int(r.seed), ret=round(r.ret, 1),
                                     outcome=r.outcome, **info))
    df = pd.DataFrame(rows)
    out = common.ROOT / "results" / "cakilma_analizi_v5.csv"
    df.round(3).to_csv(out, index=False)
    cr = df[df.outcome == "crash"]
    print(f"{len(df)} kötü bölüm ({len(cr)} çakılma, {len(df) - len(cr)} çakılmasız 200 altı) -> {out.name}\n")
    pd.set_option("display.width", 250)
    cols = ["group", "run", "split", "ep_seed", "ret", "outcome", "steps", "first_contact", "steps_after_contact",
            "legs_at_end", "angle", "max_abs_angle_after_contact", "vx", "vy", "side_frac_after_contact",
            "main_frac_after_contact", "out_of_screen", "on_helipad"]
    print(df[cols].round(2).to_string(index=False))
    print("\nÇAKILMALAR:")
    print("  ekrandan çıkma:", int(cr.out_of_screen.sum()), "/", len(cr))
    print("  bacak teması olmuş (önce yere değmiş):", int(cr.first_contact.notna().sum()), "/", len(cr))
    print("  bitişte bacak yerde (0/1/2):", cr.legs_at_end.value_counts().sort_index().to_dict())
    print("  pistin üstünde:", int(cr.on_helipad.sum()), "/", len(cr))
    print("  aynı bölüm (tohum) birden çok ajanda çakıldı mı:",
          cr.groupby("ep_seed").size()[lambda s: s > 1].to_dict() or "hayır")

    # Karşılaştırma: yere ilk değme anındaki durum, çakılan bölümler vs. aynı ajanların normal inişleri
    # (normal: 50000-50049, tohum başına 50 bölüm; çakılanlar zaten kayıtlarda olanlar)
    print("\nYERE İLK DEĞME ANI (temastan hemen önceki adım): çakılan vs normal iniş")
    comp = []
    for g in GROUPS:
        base, suf = g.split("@")
        algo, tag = base.split("/")
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            act = common.policy_act_fn(load_for_eval(d, algo, f"best_{suf}"))
            crashed = set(cr[(cr.group == g) & (cr.run == d.name)].ep_seed)
            for s in sorted(crashed) + [s for s in range(50000, 50050) if s not in crashed]:
                obs, _ = env.reset(seed=int(s))
                prev, done, t = obs, False, 0
                while not done:
                    obs, r, term, trunc, _ = env.step(act(obs))
                    t += 1
                    if obs[6] > 0 or obs[7] > 0:
                        break
                    prev, done = obs, term or trunc
                comp.append(dict(group=g, kind="çakılan" if s in crashed else "normal", vx=abs(prev[2]), vy=prev[3],
                                 angle=abs(prev[4]), ang_vel=abs(prev[5]), t_contact=t))
    c = pd.DataFrame(comp)
    for k, x in c.groupby("kind"):
        q = x[["vx", "vy", "angle", "ang_vel", "t_contact"]].quantile([0.05, 0.5, 0.95]).round(3)
        print(f"  {k} ({len(x)} bölüm): ortanca |vx| {q.vx[0.5]}, vy {q.vy[0.5]}, |açı| {q.angle[0.5]}, |açısal hız| "
              f"{q.ang_vel[0.5]}, temas adımı {q.t_contact[0.5]:.0f}")
        print(f"      %5-%95: |vx| {q.vx[0.05]}–{q.vx[0.95]}, vy {q.vy[0.05]}–{q.vy[0.95]}")
    n = c[c.kind == "normal"]
    for r in c[c.kind == "çakılan"].itertuples():
        print(f"  çakılan: |vx| {r.vx:.3f} (normallerin %{100 * (n.vx < r.vx).mean():.0f}'inden hızlı), vy {r.vy:.3f} "
              f"(normallerin %{100 * (n.vy > r.vy).mean():.0f}'inden hızlı düşüyor)")


if __name__ == "__main__":
    main()
