#!/usr/bin/env bash
# Kuyruğu arka planda başlatır (terminal kapansa da sürer). Kullanım:
#   bash scripts/start_queue.sh jobs/baseline.txt 4
# Durdurmak için: bash scripts/stop_all.sh
cd "$(dirname "${BASH_SOURCE[0]}")/.."
JOBS="${1:?iş dosyası gerekli}"
WORKERS="${2:-4}"
mkdir -p logs
setsid nohup python3 queue_runner.py --jobs "$JOBS" --workers "$WORKERS" > "logs/queue_stdout.log" 2>&1 < /dev/null &
echo "kuyruk başladı (pid $!), iş dosyası=$JOBS, işçi=$WORKERS"
