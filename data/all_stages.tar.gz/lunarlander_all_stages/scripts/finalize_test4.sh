#!/usr/bin/env bash
# Aşama 6 SON ADIM (bir kez): 800k/1600k kontrol noktası seçimi -> bağımsız doğrulama (6400-6799) -> v4 kuralıyla
# seçim -> FROZEN4 -> en yeni test (40000-40999) -> rapor + video + sonuç sayfası.
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
NEW="td3/v4big td3/v4small sac/v4"
CANDS="td3/v3long@v2 td3/v4big@800k td3/v4big@1600k td3/v4small@800k td3/v4small@1600k sac/v4@800k sac/v4@1600k ppo/tuned@v2"
# 1) kontrol noktası seçimi: 800k (400k-800k) ve 1600k (800k-1.6M)
for g in $NEW; do for d in runs/$g/seed*; do
  if [ -f "$d/DONE" ]; then
    if [ ! -f "$d/best_policy_800k.pt" ]; then echo "$d 800k 400000 800000"; fi
    if [ ! -f "$d/best_policy_1600k.pt" ]; then echo "$d 1600k 800000 1600000"; fi
  fi
done; done | xargs -r -P 4 -L 1 bash -c 'python3 reselect.py --run-dir $0 --suffix $1 --min-step $2 --max-step $3 >> logs/reselect_v4.log 2>&1'
# 2) bağımsız doğrulama (tüm adaylar)
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | \
  xargs -P 4 -L 1 bash -c '[ -f $0/val5_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split val5 --ckpt $1 > /dev/null'
# 3) seçim ve dondurma
python3 select_main_v4.py
[ -f FROZEN4 ] || { echo "Donduruldu (v4): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v4.json; } > FROZEN4
# 4) en yeni test: resmi + ek
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | xargs -P 4 -L 1 bash -c '
  [ -f $0/test4_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test4 --ckpt $1 > /dev/null
  [ -f $0/test4x_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test4x --ckpt $1 > /dev/null'
python3 - $CANDS <<'EOF'
import json, sys, glob, os
bad = []
for c in sys.argv[1:]:
    g, suf = c.split("@")
    for d in sorted(glob.glob(f"runs/{g}/seed*")):
        for sp, n in [("test4", 100), ("test4x", 900)]:
            f = f"{d}/{sp}_best_{suf}_summary.json"
            if not os.path.exists(f) or json.load(open(f))["n"] != n:
                bad.append(f)
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
# 5) raporlar, video, sonuç sayfası
python3 report.py --split test4 --groups $CANDS --out results/final_test4 --no-curves
python3 report.py --split test4all --groups $CANDS --out results/final_test4_1000 --no-curves > /dev/null
python3 report.py --split val5 --groups $CANDS --out results/final_val5 > /dev/null
MAIN=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v4.json'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v4.json'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/${MAIN%@*}/seed$VSEED" --ckpt "best_${MAIN#*@}" --split test4 --episodes 4 --out results/en_iyi_ajan_v4
python3 make_dashboard.py
echo "TEST4 TAMAMLANDI"
