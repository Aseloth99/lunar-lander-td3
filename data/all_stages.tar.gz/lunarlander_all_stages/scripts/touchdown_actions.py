"""Hipotez testi: yere değdikten SONRA ajan motorları ateşliyor mu? (çakılan vs. inen bölümler, TD3 vs. diğerleri)
Veri: doğrulama 5000-5099 (geliştirme verisi)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import numpy as np
import common
from evaluate import load_for_eval


def stats_after_contact(policy, seeds):
    env = common.make_env()
    act = common.policy_act_fn(policy)
    out = {"crash": [], "landed": []}
    for s in seeds:
        obs, _ = env.reset(seed=int(s))
        done, contact, after = False, False, []
        while not done:
            a = act(obs)
            if obs[6] > 0 and obs[7] > 0:
                contact = True
            if contact:
                after.append(a.copy())
            obs, r, term, trunc, _ = env.step(a)
            done = term or trunc
        kind = "crash" if term and r <= -99.9 else ("landed" if term and r >= 99.9 else None)
        if kind and after:
            A = np.array(after)
            out[kind].append((len(A), np.mean(A[:, 0] > 0), np.mean(np.abs(A[:, 1]) > 0.5)))
    return {k: (len(v), *np.mean(v, axis=0).round(2)) if v else (0,) for k, v in out.items()}


for g, sd in [("sac/fuel2x", 2), ("sac/fuel2x", 3), ("ppo/tuned", 1), ("ppo/tuned", 2), ("td3/tuned", 0), ("td3/tuned", 1)]:
    algo, tag = g.split("/")
    pol = load_for_eval(common.RUNS / algo / tag / f"seed{sd}", algo, "best")
    r = stats_after_contact(pol, common.VAL_SEEDS)
    print(f"{g} seed{sd}:  (bölüm sayısı, temastan sonra adım, ana motor açık oranı, yan motor açık oranı)")
    print(f"    çakılan: {r['crash']}    inen: {r['landed']}")
