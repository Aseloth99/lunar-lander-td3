#!/usr/bin/env bash
# Aşama 8'i başlatır: 10 eğitim (td3/v6brake + td3/v6soft, tohum 0-4), 6 işçi (her süreç tek çekirdek -> en çok ~6
# çekirdek; kullanıcı isteği: bilgisayar yorulmasın) + DURUM yazıcısı + bekçi.
# Bekçi oturumdan bağımsız arka planda çalışır; kuyruk bitince son adımı (finalize_test6.sh) kendisi yapar.
# Yeniden başlatma sonrası da aynı komut kullanılır: biten koşular atlanır, yarım kalanlar resume/ kayıtlarından sürer.
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
python3 -m py_compile common.py status.py report.py train.py evaluate.py && echo "derleme tamam" || exit 1
[ -f results/secim_kurali_v6.md ] || { echo "önceden kayıt (secim_kurali_v6.md) yok"; exit 1; }
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
[ -f logs/queue.log ] && [ ! -f logs/queue_asama7.log ] && mv logs/queue.log logs/queue_asama7.log
echo "$(date '+%F %T') AŞAMA 8 BAŞLAT/DEVAM" >> logs/queue.log
bash scripts/start_queue.sh jobs/stage8.txt 6
pkill -f "status.py --loop"; sleep 1
bash scripts/start_status.sh
cat > logs/wait_stage8_bg.sh << 'EOF'
#!/bin/bash
cd <proje_klasörü>
sleep 30
while pgrep -f "queue_runner.py" > /dev/null; do sleep 120; done
if [ "$(ls runs/td3/v6brake/seed*/DONE runs/td3/v6soft/seed*/DONE 2>/dev/null | wc -l)" = 10 ]; then
  bash scripts/finalize_test6.sh > logs/finalize_test6.log 2>&1 && echo "TEST6 BEKÇİ: TAMAM" >> logs/finalize_test6.log \
    || echo "TEST6 BEKÇİ: HATA (ayrıntı yukarıda)" >> logs/finalize_test6.log
else
  echo "KUYRUK EKSİK BİTTİ: $(ls runs/td3/v6brake/seed*/DONE runs/td3/v6soft/seed*/DONE 2>/dev/null | wc -l)/10" > logs/finalize_test6.log
fi
EOF
pkill -f "wait_stage8_bg.sh" 2>/dev/null
setsid nohup bash logs/wait_stage8_bg.sh > /dev/null 2>&1 < /dev/null &
sleep 20
echo "== çalışanlar =="; pgrep -af "train.py|wait_stage8_bg|status.py" | cut -c1-120
