#!/usr/bin/env bash
# Aşama 3'ü arka planda başlatır (6 işçi: 4 uzun SAC + 2 işçi PPO/TD3 için).
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
# Pilot (tohum 0) nihai yakıt-cezalı SAC grubuna taşınır: aynı ayar, aynı kod.
if [ -d runs/sac/fuelpilot/seed0 ] && [ ! -d runs/sac/fuel2x/seed0 ]; then
  mkdir -p runs/sac/fuel2x && mv runs/sac/fuelpilot/seed0 runs/sac/fuel2x/seed0 && rmdir runs/sac/fuelpilot
  python3 - <<'EOF'
import json
p = "runs/sac/fuel2x/seed0/config.json"
c = json.load(open(p, encoding="utf-8"))
c["renamed_from"] = c.get("tag"); c["tag"] = "fuel2x"
json.dump(c, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("pilot -> runs/sac/fuel2x/seed0 (train_fuel_k =", c["cfg"].get("train_fuel_k"), ")")
EOF
fi
# Aşama 1 kuyruk logunu ayır (bekçi "kuyruk tamamlandı" satırını yeni koşudan arasın)
[ -f logs/queue.log ] && mv logs/queue.log logs/queue_asama1.log
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
bash scripts/start_queue.sh jobs/stage3_final.txt 6
sleep 15
echo "--- süreçler ---"; pgrep -af "queue_runner|train.py" | cut -c1-150
# durum yazıcısını yeni kodla yeniden başlat
pkill -f "status.py --loop"; sleep 1
bash scripts/start_status.sh
