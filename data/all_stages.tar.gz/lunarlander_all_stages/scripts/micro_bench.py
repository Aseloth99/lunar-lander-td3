"""SAC'nin ana maliyeti olan MLP ileri/geri geçişini iş parçacığı sayısına göre ölçer."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import time
import torch
import torch.nn as nn

for threads in [1, 2, 4]:
    torch.set_num_threads(threads)
    net = nn.Sequential(nn.Linear(10, 400), nn.ReLU(), nn.Linear(400, 300), nn.ReLU(), nn.Linear(300, 1))
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    x = torch.randn(256, 10)
    y = torch.randn(256, 1)
    for _ in range(20):  # ısınma
        opt.zero_grad(); ((net(x) - y) ** 2).mean().backward(); opt.step()
    n = 200
    t0 = time.perf_counter()
    for _ in range(n):
        opt.zero_grad(); ((net(x) - y) ** 2).mean().backward(); opt.step()
    dt = (time.perf_counter() - t0) / n * 1000
    print(f"iş parçacığı={threads}: {dt:.2f} ms / (ileri+geri+adam), batch 256")
