#!/usr/bin/env bash
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
python3 -m py_compile status.py report.py train.py && echo "derleme tamam"
[ -f logs/queue.log ] && mv logs/queue.log logs/queue_asama5.log
if pgrep -f "queue_runner.py" > /dev/null; then echo "kuyruk zaten çalışıyor"; exit 1; fi
bash scripts/start_queue.sh jobs/stage6.txt 6
pkill -f "status.py --loop"; sleep 1
bash scripts/start_status.sh
sleep 20
pgrep -af "train.py" | cut -c1-110
