#!/usr/bin/env bash
# Aşama 7 SON ADIM (bir kez): v5big için 800k/1600k kontrol noktası seçimi -> bağımsız doğrulama (6800-7199) ->
# v5 kuralıyla seçim (results/secim_kurali_v5.md) -> FROZEN5 -> en yeni test (50000-50999) -> rapor + video + sayfa.
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
NEW="td3/v5big"
CANDS="td3/v4big@800k td3/v4big@1600k td3/v5big@800k td3/v5big@1600k"
DESKTOP=<kopyalanacak_klasör>
[ "$(ls runs/td3/v5big/seed*/DONE 2>/dev/null | wc -l)" = 5 ] || { echo "v5big 5 koşunun hepsi bitmemiş"; exit 1; }
[ -f FROZEN5 ] && echo "UYARI: FROZEN5 zaten var (seçim önceden yapılmış); yalnızca eksik adımlar tamamlanacak"
# 1) kontrol noktası seçimi (yalnızca 5100-5599): 800k (400k-800k) ve 1600k (800k-1.6M). v4big'inkiler Aşama 6'dan hazır.
for g in $NEW; do for d in runs/$g/seed*; do
  [ -f "$d/best_policy_800k.pt" ] || echo "$d 800k 400000 800000"
  [ -f "$d/best_policy_1600k.pt" ] || echo "$d 1600k 800000 1600000"
done; done | xargs -r -P 4 -L 1 bash -c 'python3 reselect.py --run-dir $0 --suffix $1 --min-step $2 --max-step $3 >> logs/reselect_v5.log 2>&1'
# 2) bağımsız doğrulama 6800-7199 (tüm adaylar)
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | \
  xargs -P 4 -L 1 bash -c '[ -f $0/val6_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split val6 --ckpt $1 > /dev/null'
# 3) seçim ve dondurma (test tohumlarına bundan ÖNCE hiç bakılmaz)
[ -f FROZEN5 ] || python3 select_main_v5.py
[ -f FROZEN5 ] || { echo "Donduruldu (v5): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v5.json; } > FROZEN5
# 4) en yeni test: resmi (50000-50099) + ek (50100-50999); evaluate.py ikinci kez ölçmeyi reddeder
for c in $CANDS; do for d in runs/${c%@*}/seed*; do echo "$d best_${c#*@}"; done; done | xargs -P 4 -L 1 bash -c '
  [ -f $0/test5_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test5 --ckpt $1 > /dev/null
  [ -f $0/test5x_$1_summary.json ] || python3 evaluate.py --run-dir $0 --split test5x --ckpt $1 > /dev/null'
python3 - $CANDS <<'EOF'
import json, sys, glob, os
bad = []
for c in sys.argv[1:]:
    g, suf = c.split("@")
    for d in sorted(glob.glob(f"runs/{g}/seed*")):
        for sp, n in [("test5", 100), ("test5x", 900)]:
            f = f"{d}/{sp}_best_{suf}_summary.json"
            if not os.path.exists(f) or json.load(open(f))["n"] != n:
                bad.append(f)
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
# 5) raporlar, video, sonuç sayfası, masaüstü kopyası
python3 report.py --split test5 --groups $CANDS --out results/final_test5 --no-curves
python3 report.py --split test5all --groups $CANDS --out results/final_test5_1000 --no-curves > /dev/null
python3 report.py --split val6 --groups $CANDS --out results/final_val6 > /dev/null
MAIN=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v5.json'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v5.json'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/${MAIN%@*}/seed$VSEED" --ckpt "best_${MAIN#*@}" --split test5 --episodes 4 --out results/en_iyi_ajan_v5
python3 make_dashboard.py
if [ -d "$DESKTOP" ]; then rsync -rt results/ "$DESKTOP/results/"; fi
echo "TEST5 TAMAMLANDI"
