#!/usr/bin/env bash
# Aşama 4 SON ADIM (bir kez): v2 ana sonuç seçimi (bağımsız doğrulama) -> FROZEN2 -> yeni test (20000-20999) -> rapor + video
set -eo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
CANDS="sac/fuel2x ppo/tuned td3/tuned td3/v2a td3/v2b"
python3 select_main_v2.py
if [ ! -f FROZEN2 ]; then
  { echo "Donduruldu (v2): $(date '+%F %T')"; cat results/ana_sonuc_secimi_v2.json; } > FROZEN2
fi
ls -d $(for g in $CANDS; do echo runs/$g/seed*; done) | xargs -P 4 -I{} bash -c '
  d={}; [ -f "$d/DONE" ] || exit 0
  [ -f "$d/test2_summary.json" ] || python3 evaluate.py --run-dir "$d" --split test2 --ckpt best_v2 > /dev/null
  [ -f "$d/test2x_summary.json" ] || python3 evaluate.py --run-dir "$d" --split test2x --ckpt best_v2 > /dev/null
  echo "test edildi: $d"'
# Güvenlik: her koşunun test özeti doğru kontrol noktası (best_v2) ve tam bölüm sayısıyla yazılmış olmalı
python3 - $CANDS <<'EOF'
import json, sys, glob
bad = []
for g in sys.argv[1:]:
    for d in sorted(glob.glob(f"runs/{g}/seed*")):
        for split, n in [("test2", 100), ("test2x", 900)]:
            try:
                s = json.load(open(f"{d}/{split}_summary.json"))
                if s["ckpt"] != "best_v2" or s["n"] != n:
                    bad.append(f"{d}/{split}")
            except FileNotFoundError:
                bad.append(f"{d}/{split} (yok)")
sys.exit(f"HATALI/EKSİK TEST ÖZETİ: {bad}" if bad else 0)
EOF
python3 report.py --split test2 --groups $CANDS --out results/final_test2 --no-curves
python3 report.py --split test2all --groups $CANDS --out results/final_test2_1000 --no-curves
python3 report.py --split val3 --groups $CANDS --out results/final_val3 --no-curves > /dev/null
MAIN=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v2.json'))['main'])")
VSEED=$(python3 -c "import json; print(json.load(open('results/ana_sonuc_secimi_v2.json'))['main_video_seed'])")
python3 make_video.py --run-dir "runs/$MAIN/seed$VSEED" --ckpt best_v2 --split test2 --episodes 4 --out results/en_iyi_ajan_v2
echo "TEST2 TAMAMLANDI"
