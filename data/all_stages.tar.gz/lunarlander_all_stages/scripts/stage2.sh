#!/usr/bin/env bash
# Aşama 2: Optuna (her algoritmaya EŞİT bütçe: 12 deneme) + SAC yakıt-cezası pilotu (arka planda 1 süreç).
# Sıra: PPO -> TD3 -> SAC (her biri 4 işçi). Kullanım (arka planda): setsid nohup bash scripts/stage2.sh > logs/stage2.log 2>&1 &
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
echo "$(date '+%F %T') aşama 2 başladı"

# Pilot: zoo SAC ayarı + EĞİTİMDE yakıt cezası 2 katı (k=1.0); doğrulama/test orijinal ödülle. Tek tohum (0).
nice -n 10 python3 train.py --algo sac --seed 0 --tag fuelpilot --set train_fuel_k=1.0 --resume --overwrite \
    > logs/sac_fuelpilot_seed0.log 2>&1 &
PILOT=$!

python3 tune.py --algo ppo --trials 12 --trial-steps 500000 --workers 4 && echo "$(date '+%F %T') PPO Optuna bitti"
python3 tune.py --algo td3 --trials 12 --trial-steps 100000 --workers 4 && echo "$(date '+%F %T') TD3 Optuna bitti"
python3 tune.py --algo sac --trials 12 --trial-steps 100000 --workers 4 && echo "$(date '+%F %T') SAC Optuna bitti"

wait $PILOT
echo "$(date '+%F %T') AŞAMA 2 TAMAMLANDI"
