"""Aşama 7 kontrolü: önceden kaydın zamanı, seçimin/testin sırası, küme ayrıklığı, tabloların ham veriden yeniden
hesaplanması, ana sonucun yeniden oynatılması ve "290 sorusu"nun cevabı. Dosya yazmaz."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import _deps  # noqa: F401,E402

import json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402
import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

R = common.ROOT
fails = []
CANDS = ["td3/v4big@800k", "td3/v4big@1600k", "td3/v5big@800k", "td3/v5big@1600k"]


def check(name, ok, detail=""):
    print(("  OK  " if ok else " HATA ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


def files(c, split):
    g, suf = c.split("@")
    return sorted((R / "runs" / g).glob(f"seed*/{split}_best_{suf}_summary.json"))


mt = lambda ps: [p.stat().st_mtime for p in ps]  # noqa: E731
rule = (R / "results" / "secim_kurali_v5.md").stat().st_mtime
starts = [json.load(open(d / "config.json"))["started"] for d in sorted((R / "runs/td3/v5big").glob("seed*"))]
first_ckpt = min(pd.read_csv(d / "val_curve.csv").wall_s.min() for d in (R / "runs/td3/v5big").glob("seed*"))
import datetime as dt  # noqa: E402
start_ts = min(dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S").timestamp() for s in starts)
check("önceden kayıt (secim_kurali_v5.md) eğitimden önce yazılmış", rule < start_ts,
      f"kural {dt.datetime.fromtimestamp(rule):%F %T}, ilk eğitim {min(starts)}")
v6 = [t for c in CANDS for t in mt(files(c, "val6"))]
t5 = [t for c in CANDS for t in mt(files(c, "test5")) + mt(files(c, "test5x"))]
check("20 aday-koşunun hepsinde val6 ve test (100 + 900) var", len(v6) == 20 and len(t5) == 40, f"{len(v6)}, {len(t5)}")
sel_f = R / "results" / "ana_sonuc_secimi_v5.json"
check("bağımsız doğrulama -> seçim -> FROZEN5 -> test sırası",
      max(v6) <= sel_f.stat().st_mtime <= (R / "FROZEN5").stat().st_mtime < min(t5))
old = (common.VAL_SEEDS + common.VAL2_SEEDS + common.VAL3_SEEDS + common.VAL4_SEEDS + common.VAL5_SEEDS + common.TEST_SEEDS +
       common.TEST2_SEEDS + common.TEST2X_SEEDS + common.TEST3_SEEDS + common.TEST3X_SEEDS + common.TEST4_SEEDS + common.TEST4X_SEEDS)
new = set(common.VAL6_SEEDS + common.TEST5_SEEDS + common.TEST5X_SEEDS)
check("6800-7199 ve 50000-50999 önceki hiçbir kümeyle çakışmıyor", not (new & set(old)))

# v5big koşuları: ayar v4big ile tek farkla aynı, seçim aralıkları doğru
for d in sorted((R / "runs/td3/v5big").glob("seed*")):
    a = json.load(open(d / "config.json"))["cfg"]
    b = json.load(open(R / "runs/td3/v4big" / d.name / "config.json"))["cfg"]
    diff = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
    check(f"v5big {d.name}: v4big'den tek fark lr_linear", diff == ["lr_linear"] and a["lr_linear"] is True, str(diff))
    for sx, lo, hi in [("800k", 400000, 800000), ("1600k", 800000, 1600000)]:
        st = json.load(open(d / f"selection_{sx}.json"))["chosen"]["step"]
        check(f"v5big {d.name}: {sx} seçimi {lo // 1000}k-{hi // 1000}k aralığında ({st})", lo <= st <= hi)

# seçimi ham val6 verisinden yeniden yap (kural v5)
rows = []
for c in CANDS:
    g, suf = c.split("@")
    per = []
    for d in sorted((R / "runs" / g).glob("seed*")):
        e = pd.read_csv(d / f"val6_best_{suf}_episodes.csv")
        assert list(e.seed) == common.VAL6_SEEDS
        per.append(dict(crash=int((e.outcome == "crash").sum()), below=int((e.ret < 200).sum()), mean=e.ret.mean()))
    ok = all(p["crash"] == 0 and p["below"] == 0 for p in per)
    rows.append((c, ok, sum(p["crash"] for p in per), sum(p["below"] for p in per), np.mean([p["mean"] for p in per])))
rows.sort(key=lambda r: (0, 0, 0, -r[4]) if r[1] else (1, r[2], r[3], -r[4]))
sel = json.load(open(sel_f))
check("seçim ham val6 verisinden yeniden yapıldığında aynı", rows[0][0] == sel["main"] == json.load(open(R / "results/ana_sonuc_secimi_v5.json"))["main"],
      f"yeniden: {rows[0][0]}, kayıt: {sel['main']}")

# test tabloları ham bölümlerden
print("\nTEST (ham bölümlerden): resmi 50000-50099 | genişletilmiş 50000-50999")
res = {}
for c in CANDS:
    g, suf = c.split("@")
    m100, m1000, c100, c1000, b100, b1000 = [], [], 0, 0, 0, 0
    for d in sorted((R / "runs" / g).glob("seed*")):
        a = pd.read_csv(d / f"test5_best_{suf}_episodes.csv")
        b = pd.read_csv(d / f"test5x_best_{suf}_episodes.csv")
        assert list(a.seed) == common.TEST5_SEEDS and list(b.seed) == common.TEST5X_SEEDS
        ab = pd.concat([a, b])
        m100.append(a.ret.mean()); m1000.append(ab.ret.mean())
        c100 += int((a.outcome == "crash").sum()); c1000 += int((ab.outcome == "crash").sum())
        b100 += int((a.ret < 200).sum()); b1000 += int((ab.ret < 200).sum())
    ci = lambda x: stats.t.ppf(0.975, len(x) - 1) * np.std(x, ddof=1) / np.sqrt(len(x))  # noqa: E731
    res[c] = (np.mean(m100), c100, b100, np.mean(m1000), c1000, b1000)
    print(f"  {c:16s} {np.mean(m100):6.1f} ± {ci(m100):.1f} | çakılma {c100}/500 | 200 altı {b100}/500 || "
          f"{np.mean(m1000):6.1f} ± {ci(m1000):.1f} | çakılma {c1000}/5000 | 200 altı {b1000}/5000")

main = sel["main"]
g, suf = main.split("@")
maxdiff, nrep = 0.0, 0
for d in sorted((R / "runs" / g).glob("seed*")):
    a = pd.read_csv(d / f"test5_best_{suf}_episodes.csv")
    rr = common.evaluate_episodes(common.policy_act_fn(load_for_eval(d, "td3", f"best_{suf}")), common.TEST5_SEEDS)
    maxdiff = max(maxdiff, float(np.max(np.abs(np.array([r["ret"] for r in rr]) - a.ret.values))))
    nrep += len(rr)
check(f"ana sonuç ({main}) yeniden oynatıldı: aynı puanlar", maxdiff < 1e-6, f"{nrep} bölüm, en büyük fark {maxdiff:.1e}")

m100, c100, b100, m1000, c1000, b1000 = res[main]
yes100 = c100 == 0 and b100 == 0 and m100 >= 290.0
yes1000 = c1000 == 0 and b1000 == 0 and m1000 >= 290.0
print(f"\n290 SORUSU (önceden tanımlı, ana sonuç {main}):")
print(f"  resmi test (500 bölüm): çakılma {c100}, 200 altı {b100}, ortalama {m100:.2f} -> {'EVET' if yes100 else 'HAYIR'}")
print(f"  genişletilmiş (5000 bölüm): çakılma {c1000}, 200 altı {b1000}, ortalama {m1000:.2f} -> {'EVET' if yes1000 else 'HAYIR'}")
print("\nSONUÇ:", "HEPSİ GEÇTİ" if not fails else f"{len(fails)} HATA: {fails}")
