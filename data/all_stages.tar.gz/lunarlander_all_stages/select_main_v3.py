"""Ana sonuç v3: results/secim_kurali_v3.md (önceden kayıt). YALNIZCA bağımsız doğrulama 6000-6399 (val4).
Çıktı: results/ana_sonuc_secimi_v3.json"""
import _deps  # noqa: F401

import json

import common

CANDIDATES = ["td3/v2b", "td3/v3long", "td3/v3big", "td3/v3fuel"]


def main():
    rows = []
    for g in CANDIDATES:
        algo, tag = g.split("/")
        runs = []
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            f = d / "val4_best_v2_summary.json"
            if (d / "DONE").exists() and f.exists():
                s = json.load(open(f, encoding="utf-8"))
                runs.append(dict(seed=s["seed"], crashes=int(round(s["crash"] * s["n"])), success=s["success"],
                                 mean=s["mean"]))
        if len(runs) < 5:
            print(f"[aday değil] {g}: {len(runs)} tohum")
            continue
        eligible = all(r["crashes"] == 0 and r["success"] >= 0.99 for r in runs)
        rows.append(dict(group=g, eligible=eligible, crashes=sum(r["crashes"] for r in runs),
                         mean=sum(r["mean"] for r in runs) / 5, runs=runs,
                         best_seed=max(runs, key=lambda r: (r["crashes"] == 0, r["mean"]))["seed"]))
    # uygunlar önce, kendi içlerinde ortalamaya göre; uygun olmayanlar sonra, az çakılma ve yüksek ortalamaya göre
    rows.sort(key=lambda r: (0, -r["mean"], 0) if r["eligible"] else (1, r["crashes"], -r["mean"]))
    for r in rows:
        print(f"{r['group']:11s} uygun={'EVET' if r['eligible'] else 'hayır'} | çakılma {r['crashes']}/2000 | "
              f"ort {r['mean']:.1f} | tohum ort. {[round(x['mean'], 1) for x in r['runs']]}")
    out = dict(rule="results/secim_kurali_v3.md (önceden kayıt)", data="bağımsız doğrulama 6000-6399 (400 bölüm/tohum)",
               decided=common.now_iso(), ranking=[r["group"] for r in rows], main=rows[0]["group"],
               main_video_seed=rows[0]["best_seed"], table=rows)
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi_v3.json", out)
    print("ANA SONUÇ (v3):", rows[0]["group"], "| video tohumu:", rows[0]["best_seed"])


if __name__ == "__main__":
    main()
