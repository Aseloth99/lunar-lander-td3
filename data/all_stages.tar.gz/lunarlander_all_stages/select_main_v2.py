"""Ana sonuç v2: results/secim_kurali_v2.md (önceden kayıt). YALNIZCA bağımsız doğrulama 5600-5999 (val3) kullanılır.
  python3 select_main_v2.py
Çıktı: results/ana_sonuc_secimi_v2.json
"""
import _deps  # noqa: F401

import json

import common

CANDIDATES = ["sac/fuel2x", "ppo/tuned", "td3/tuned", "td3/v2a", "td3/v2b"]


def main():
    rows = []
    for g in CANDIDATES:
        algo, tag = g.split("/")
        runs = []
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            f = d / "val3_best_v2_summary.json"
            if (d / "DONE").exists() and f.exists():
                s = json.load(open(f, encoding="utf-8"))
                runs.append(dict(seed=s["seed"], n=s["n"], crashes=int(round(s["crash"] * s["n"])),
                                 success=s["success"], mean=s["mean"]))
        if len(runs) < 5:
            print(f"[aday değil] {g}: {len(runs)} tohum")
            continue
        clean = sum(r["crashes"] == 0 and r["success"] >= 0.99 for r in runs)
        tot_crash = sum(r["crashes"] for r in runs)
        succ = sum(r["success"] * r["n"] for r in runs) / sum(r["n"] for r in runs)
        mean = sum(r["mean"] for r in runs) / len(runs)
        best_seed = min(runs, key=lambda r: (r["crashes"], -r["success"], -r["mean"]))["seed"]
        rows.append(dict(group=g, clean_seeds=clean, crashes=tot_crash, success=succ, mean=mean, runs=runs,
                         best_seed=best_seed))
    rows.sort(key=lambda r: (-r["clean_seeds"], r["crashes"], -r["success"], -r["mean"]))
    for r in rows:
        print(f"{r['group']:11s} çakılmasız tohum {r['clean_seeds']}/5 | toplam çakılma {r['crashes']}/2000 | "
              f"başarı {100 * r['success']:.2f}% | ort {r['mean']:.1f} | tohum başına çakılma "
              f"{[x['crashes'] for x in r['runs']]}")
    out = dict(rule="results/secim_kurali_v2.md (önceden kayıt)", data="bağımsız doğrulama 5600-5999 (400 bölüm/tohum)",
               decided=common.now_iso(), ranking=[r["group"] for r in rows], main=rows[0]["group"],
               main_video_seed=rows[0]["best_seed"], table=rows)
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi_v2.json", out)
    print("ANA SONUÇ (v2):", rows[0]["group"], "| video tohumu:", rows[0]["best_seed"])


if __name__ == "__main__":
    main()
