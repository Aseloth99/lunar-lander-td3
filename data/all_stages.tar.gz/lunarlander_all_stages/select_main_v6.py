"""Ana sonuç v6: results/secim_kurali_v6.md (eğitimden önce kayıt). YALNIZCA bağımsız doğrulama 7200-9199 (val7, 2000/tohum).
Kural: uygunluk = her tohumda ortalama >= 280; uygunlar arasında önce toplam çakılma en az, sonra 200 altı en az,
sonra tohum ortalamalarının ortalaması en yüksek. Çıktı: results/ana_sonuc_secimi_v6.json"""
import _deps  # noqa: F401

import json

import common

CANDIDATES = ["td3/v4big@800k", "td3/v4big@1600k", "td3/v6brake@800k", "td3/v6brake@1600k",
              "td3/v6soft@800k", "td3/v6soft@1600k"]


def main():
    rows = []
    for c in CANDIDATES:
        g, suf = c.split("@")
        runs = []
        for d in sorted((common.RUNS / g).glob("seed*")):
            f = d / f"val7_best_{suf}_summary.json"
            if (d / "DONE").exists() and f.exists():
                s = json.load(open(f, encoding="utf-8"))
                runs.append(dict(seed=s["seed"], crashes=int(round(s["crash"] * s["n"])), success=s["success"],
                                 below200=int(round((1 - s["success"]) * s["n"])), mean=s["mean"], n=s["n"]))
        if len(runs) < 5:
            print(f"[aday değil] {c}: {len(runs)} tohum")
            continue
        eligible = all(r["mean"] >= 280.0 for r in runs)
        rows.append(dict(group=c, eligible=eligible, crashes=sum(r["crashes"] for r in runs),
                         below200=sum(r["below200"] for r in runs), n=sum(r["n"] for r in runs),
                         mean=sum(r["mean"] for r in runs) / len(runs), runs=runs,
                         best_seed=max(runs, key=lambda r: (r["crashes"] == 0, r["mean"]))["seed"]))
    rows.sort(key=lambda r: (0 if r["eligible"] else 1, r["crashes"], r["below200"], -r["mean"]))
    for r in rows:
        print(f"{r['group']:18s} uygun={'EVET' if r['eligible'] else 'hayır'} | çakılma {r['crashes']}/{r['n']} | "
              f"200 altı {r['below200']}/{r['n']} | ort {r['mean']:.2f} | tohum ort. {[round(x['mean'], 1) for x in r['runs']]}")
    out = dict(rule="results/secim_kurali_v6.md (her tohumda ort. >= 280; sonra en az çakılma, en az 200 altı, en yüksek "
                    "ortalama; eğitimden önce kayıt)",
               data="bağımsız doğrulama 7200-9199 (2000 bölüm/tohum)",
               decided=common.now_iso(), ranking=[r["group"] for r in rows], main=rows[0]["group"],
               main_video_seed=rows[0]["best_seed"], table=rows)
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi_v6.json", out)
    print("ANA SONUÇ (v6):", rows[0]["group"], "| video tohumu:", rows[0]["best_seed"])


if __name__ == "__main__":
    main()
