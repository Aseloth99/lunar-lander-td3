"""runs/**/progress.json dosyalarından DURUM.md üretir.

  python3 status.py                       # bir kez yaz
  python3 status.py --loop 60             # her 60 sn'de yenile (arka planda: scripts/start_status.sh)
  python3 status.py --sync <kopyalanacak_klasör>   # ek olarak oraya da kopyala
"""
import _deps  # noqa: F401

import argparse
import json
import os
import shutil
import time
from pathlib import Path

import common


def pid_alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, TypeError, ValueError):
        return False


def fmt_dur(s):
    if s is None:
        return "-"
    s = int(s)
    h, m = divmod(s // 60, 60)
    return f"{h} sa {m:02d} dk" if h else f"{m} dk"


HIST = {}  # koşu yolu -> [(zaman, adım)]  (döngü modunda son ~15 dk'lık hızı hesaplamak için)


def recent_sps(path, ts, step, window=900):
    h = HIST.setdefault(path, [])
    if not h or h[-1][0] != ts:
        h.append((ts, step))
    while len(h) > 2 and h[0][0] < ts - window:
        h.pop(0)
    if len(h) >= 2 and h[-1][0] > h[0][0] and h[-1][1] > h[0][1]:
        return (h[-1][1] - h[0][1]) / (h[-1][0] - h[0][0])
    return None


def collect():
    rows = []
    for pj in sorted(common.RUNS.rglob("progress.json")):
        try:
            d = json.load(open(pj, encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        d["path"] = str(pj.parent.relative_to(common.ROOT))
        if d.get("state") == "running" and not pid_alive(d.get("pid")):
            d["state"] = "DURDU (süreç yok)"
        if d.get("state") == "running":
            rs = recent_sps(d["path"], d.get("updated_ts", 0), d["step"])
            if rs:  # ETA'yı tüm-koşu ortalamasıyla değil, son 15 dk hızıyla hesapla
                d["sps"] = round(rs, 1)
                d["eta_s"] = round((d["total"] - d["step"]) / rs)
        rows.append(d)
    return rows


def render(rows):
    now = common.now_iso()
    tune = [r for r in rows if "/tune/" in r["path"]]
    rows = [r for r in rows if "/tune/" not in r["path"] or r["state"] == "running"]
    run = [r for r in rows if r["state"] == "running"]
    done = [r for r in rows if r["state"] == "done"]
    bad = [r for r in rows if r["state"] not in ("running", "done")]
    out = [f"# DURUM (otomatik üretilir)\n", f"Son güncelleme: **{now}**\n",
           f"Çalışan: **{len(run)}** · Biten: **{len(done)}** · Sorunlu/durmuş: **{len(bad)}**\n"]
    hdr = "| Koşu | Durum | Adım | % | adım/sn | Kalan | Son doğrulama | En iyi doğrulama | Güncelleme |\n|---|---|---:|---:|---:|---:|---:|---:|---|"
    out.append(hdr)
    for r in rows:
        pct = min(100, 100 * r["step"] / r["total"]) if r.get("total") else 0
        lv = "-" if r.get("last_val_mean") is None else f"{r['last_val_mean']:.1f}"
        bv = "-" if r.get("best_val_mean") is None else f"{r['best_val_mean']:.1f}"
        out.append(f"| `{r['path']}` | {r['state']} | {r['step']:,} / {r['total']:,} | {pct:.0f} | {r.get('sps', 0)} | "
                   f"{fmt_dur(r.get('eta_s')) if r['state'] == 'running' else '-'} | {lv} | {bv} | {r.get('updated', '-')} |")
    for r in bad:
        if r.get("error"):
            out.append(f"\n> ⚠ `{r['path']}`: {r['error']}")
    if tune:
        from collections import Counter
        c = Counter(r["state"] for r in tune)
        out.append(f"\nOptuna denemeleri (tablo dışı): {len(tune)} — " + ", ".join(f"{k}: {v}" for k, v in sorted(c.items())))
    out.append("\n_Doğrulama = 20 doğrulama bölümünde deterministik politika ortalama puanı (eşik: 200)._")
    return "\n".join(out) + "\n"


ORDER = ["td3/v2b", "td3/v3long", "td3/v3big", "td3/v3fuel", "td3/v4big", "td3/v6brake", "sac/v9big", "sac/v9lowent", "sac/v10brake", "sac/v10soft",
         "td3/v6soft", "td3/v5big",
         "td3/v4small", "sac/v4"]  # canlı grafikte sıra (renk sırası doğrulandı)


def live_groups(rows):
    """Şu an eğitilen gruplar + son 12 saatte güncellenen gruplar + referans (mevcut şampiyon)."""
    now = time.time()
    gs = []
    for r in rows:
        if "/tune/" in r["path"]:
            continue
        if r["state"] == "running" or now - r.get("updated_ts", 0) < 12 * 3600:
            g = "/".join(Path(r["path"]).parts[1:3])
            if g not in gs:
                gs.append(g)
    champ = common.latest_main()[0].split("@")[0]  # karşılaştırma için mevcut şampiyon
    if gs and (common.RUNS / champ).exists() and champ not in gs:
        gs.insert(0, champ)
    return sorted(gs, key=lambda g: ORDER.index(g) if g in ORDER else 99)


def plot_live(groups, png):
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from report import st, ref_lines, TR_K, INK
    fig, ax = plt.subplots(figsize=(11, 5.6))
    lo = 150.0  # alt sınır: her grubun GÜNCEL değeri görünür kalsın (eğitimin başında puanlar çok düşüktür)
    for g in groups:
        name, _, col, _, _ = st(g)
        curves = []
        for f in sorted((common.RUNS / g).glob("seed*/val_curve.csv")):
            c = pd.read_csv(f).drop_duplicates("step", keep="last")
            ax.plot(c.step, c.val_mean, color=col, lw=0.7, alpha=0.3)
            curves.append(c)
        if not curves:
            continue
        grid = np.unique(np.concatenate([c.step.values for c in curves]))
        Y = np.array([np.where(grid <= c.step.max(), np.interp(grid, c.step, c.val_mean), np.nan) for c in curves])
        mu = np.nanmean(Y, axis=0)
        lo = min(lo, float(np.nanmin(mu[-3:])) - 25)
        ax.plot(grid, mu, color=col, lw=2.4, label=f"{name} ({len(curves)} tohum, son ort. {mu[-1]:.0f})")
    ref_lines(ax, right=True)
    ax.axhline(290, color=INK, lw=1.2, ls=(0, (6, 3)))
    ax.text(1.01, 290, "yeni hedef (290)", transform=ax.get_yaxis_transform(), va="center", fontsize=8.5, color=INK)
    ax.set_ylim(max(lo, -350), 320)
    ax.xaxis.set_major_formatter(TR_K)
    ax.set_xlabel("Eğitim adımı (bin)")
    ax.set_ylabel("Doğrulama puanı (20 bölüm, deterministik)")
    ax.set_title(f"Canlı öğrenme eğrileri — {common.now_iso()}", loc="left", color=INK)
    ax.legend(loc="lower right", fontsize=9)
    fig.tight_layout()
    fig.savefig(png, dpi=110)
    plt.close(fig)


STAGE_INFO = {  # kuyruk iş dosyası -> (başlık, açıklama)
    "jobs/stage5_td3.txt": ("290 denemesi (Aşama 5)",
                            "Amaç: çakılmasız kalarak ortalamayı 283'ten 290'a yaklaştırmak. Mevcut en iyi ajan TD3 v2b'nin 3 çeşidi, "
                            "her biri 5 tohumla = 15 koşu: <b>uzun eğitim</b> (400 bin yerine 800 bin adım), <b>büyük ağ</b> "
                            "([400,300]) ve <b>eğitimde yakıt cezası†</b>. Bitince en iyisi önceden yazılmış kurala göre seçilir ve "
                            "hiç görülmemiş yeni test bölümleriyle (30000+) ölçülür; sonuçlar 3-SONUCLARI-GOSTER sayfasına eklenir."),
    "jobs/stage6.txt": ("Sınırları zorlama (Aşama 6)",
                        "Amaç: daha uzun eğitimle ne kadar iyi olunabileceğini görmek. 3 çeşit, her biri 5 tohumla = 15 koşu, "
                        "hepsi <b>1,6 milyon adım</b> (şampiyonun 2 katı): <b>TD3 büyük ağ</b> ([400,300]), <b>TD3 küçük ağ</b> "
                        "([256,256], şampiyonla aynı ağ) ve <b>SAC</b> ([256,256]). Her koşu ayrıca 800 bin adımdaki hâliyle de "
                        "değerlendirilir. Seçimde önce çakılmasızlığa, sonra ortalamaya bakılır; mevcut şampiyon (TD3 v3 uzun) da "
                        "yarışır. Bitince hiç görülmemiş yeni test bölümleriyle (40000+) ölçülür; sonuçlar 3-SONUCLARI-GOSTER'e eklenir."),
}


def current_queue():
    """Son başlatılan kuyruk: başlangıç zamanı, iş dosyası, işçi sayısı, işler ve her işin durumu."""
    import shlex
    from datetime import datetime
    log = common.ROOT / "logs" / "queue.log"
    if not log.exists():
        return None
    lines = log.read_text(encoding="utf-8").splitlines()
    start = [l for l in lines if "kuyruk başladı" in l]
    if not start:
        return None
    l0 = start[-1]
    t0 = datetime.strptime(l0[:19], "%Y-%m-%d %H:%M:%S").timestamp()
    jobs_file = l0.split("dosya=")[1].strip()
    workers = int(l0.split("iş, ")[1].split(" işçi")[0])
    finished = any("kuyruk tamamlandı" in l for l in lines[lines.index(l0):])
    jobs = []
    for line in (common.ROOT / jobs_file).read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        a = shlex.split(line)
        kv = dict(zip(a, a[1:]))
        g, seed = f"{kv['--algo']}/{kv.get('--tag', 'zoo')}", int(kv["--seed"])
        d = common.RUNS / g / f"seed{seed}"
        prog = {}
        if (d / "progress.json").exists():
            try:
                prog = json.load(open(d / "progress.json", encoding="utf-8"))
            except Exception:  # noqa: BLE001
                prog = {}
        fresh = prog.get("updated_ts", 0) >= t0
        if (d / "DONE").exists() and (d / "DONE").stat().st_mtime >= t0:
            state = "bitti"
        elif fresh and prog.get("state") == "running" and pid_alive(prog.get("pid")):
            state = "eğitiliyor"
        elif fresh and prog.get("state") not in (None, "running", "done"):
            state = "SORUN"
        else:
            state = "sırada"
        jobs.append(dict(group=g, seed=seed, state=state, prog=prog if fresh else {}))
    return dict(t0=t0, jobs_file=jobs_file, workers=workers, jobs=jobs, finished=finished)


def render_html(rows, has_png):
    from report import st
    q = current_queue()
    now = time.time()
    if q is None:
        return "<!doctype html><meta charset=utf-8><p>Henüz eğitim kaydı yok.</p>"
    title, desc = STAGE_INFO.get(q["jobs_file"], (q["jobs_file"], ""))
    c = {s: sum(j["state"] == s for j in q["jobs"]) for s in ("bitti", "eğitiliyor", "sırada", "SORUN")}
    # kaba bitiş tahmini: süren işlerin kalanı + sıradakiler × ortalama iş süresi, işçilere bölünmüş
    durs = [j["prog"]["elapsed_s"] for j in q["jobs"] if j["state"] == "bitti" and j["prog"].get("elapsed_s")]
    durs += [j["prog"]["elapsed_s"] / (j["prog"]["step"] / j["prog"]["total"]) for j in q["jobs"]
             if j["state"] == "eğitiliyor" and j["prog"].get("step", 0) > 0.1 * j["prog"].get("total", 1)]
    rem_run = [j["prog"].get("eta_s") or 0 for j in q["jobs"] if j["state"] == "eğitiliyor"]
    eta_txt = "hesaplanıyor (ilk koşular %10'u geçince)"
    if durs:
        total_rem = (sum(rem_run) + c["sırada"] * (sum(durs) / len(durs))) / max(q["workers"], 1)
        eta_txt = f"yaklaşık {fmt_dur(total_rem)} sonra ({time.strftime('%d.%m %H:%M', time.localtime(now + total_rem))}) — kaba tahmin"
    if q["finished"]:
        head = "<b>Bu eğitim bitti.</b> Seçim ve test ardından otomatik yapılır; sonuçlar: <b>3-SONUCLARI-GOSTER</b>."
    else:
        head = f"Tahmini bitiş: <b>{eta_txt}</b>"

    def tr(j):
        p = j["prog"]
        pct = min(100, 100 * p["step"] / p["total"]) if p.get("total") else (100 if j["state"] == "bitti" else 0)
        lv = "-" if p.get("last_val_mean") is None else f"{p['last_val_mean']:.0f}"
        eta = fmt_dur(p.get("eta_s")) if j["state"] == "eğitiliyor" else "-"
        return (f"<tr><td>{st(j['group'])[0]} · tohum {j['seed']}</td><td class='s-{j['state'][:3]}'>{j['state']}</td>"
                f"<td><div class=bar><span style='width:{pct:.0f}%'></span></div> {pct:.0f}%</td><td>{eta}</td><td>{lv}</td></tr>")
    img = f"<img src='results/canli_egriler.png?t={int(now)}' alt='öğrenme eğrileri'>" if has_png else ""
    return f"""<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta http-equiv="refresh" content="60">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Süren eğitim</title>
<style>body{{font-family:system-ui,Segoe UI,sans-serif;background:#fcfcfb;color:#1f2328;margin:24px auto;max-width:1100px;padding:0 16px;line-height:1.5}}
h1{{font-size:22px;margin:0 0 4px}} .muted{{color:#59636e;font-size:14px}} img{{max-width:100%;border:1px solid #d8dee4;border-radius:8px;margin:16px 0}}
.info{{background:#f1f5f9;border:1px solid #d8dee4;border-radius:10px;padding:12px 16px;margin:12px 0;font-size:15px}}
table{{border-collapse:collapse;width:100%;font-size:14px}} td,th{{padding:6px 8px;border-bottom:1px solid #d8dee4;text-align:left}}
.bar{{display:inline-block;width:120px;height:8px;background:#eaeef2;border-radius:4px;vertical-align:middle}}
.bar span{{display:block;height:8px;background:#0072B2;border-radius:4px}} .s-bit{{color:#1a7f37}} .s-eği{{color:#0072B2;font-weight:600}}
.s-sır{{color:#59636e}} .s-SOR{{color:#cf222e;font-weight:600}}</style></head><body>
<h1>Şu an süren eğitim: {title}</h1>
<div class="muted">Başladı: {time.strftime('%d.%m.%Y %H:%M', time.localtime(q['t0']))} · son güncelleme {common.now_iso()} · sayfa her dakika kendini yeniler</div>
<div class="info"><b>Bu sayfa ne gösteriyor?</b> Arka planda şu anda çalışan eğitimi. {desc}<br>
Koşular: <b>{c['bitti']} bitti</b> · <b>{c['eğitiliyor']} eğitiliyor</b> · <b>{c['sırada']} sırada</b>{f" · <b>{c['SORUN']} SORUNLU</b>" if c['SORUN'] else ""}
(toplam {len(q['jobs'])}, aynı anda {q['workers']}). {head}</div>
<h2 style="font-size:17px;margin:20px 0 0">Öğrenme eğrileri</h2>
<div class="muted">Her renkli kalın çizgi bir çeşidin 5 tohumunun ortalaması; yukarı çıkması iyi. Karşılaştırma için mevcut
şampiyonun eğrisi de çizilir (lejantta adı yazar). Kesik çizgiler: 290 yeni hedef, 280 eski hedef, 200 "çözüldü" eşiği.</div>{img}
<table><tr><th>Koşu</th><th>Durum</th><th>İlerleme</th><th>Kalan</th><th>Son doğrulama puanı</th></tr>
{''.join(tr(j) for j in q['jobs'])}</table>
<p class="muted">Doğrulama puanı: eğitim sırasında 20 doğrulama bölümünde, rastgelelik olmadan oynanan ortalama puan
(kesin sonuç değil). † eğitimde yakıt cezası 2×; değerlendirme orijinal ödülle.</p></body></html>"""


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--loop", type=int, default=0)
    p.add_argument("--sync", default=None, help="DURUM.md / DURUM.html'in kopyalanacağı ek klasör")
    a = p.parse_args()
    while True:
        rows = collect()
        text = render(rows)
        (common.ROOT / "DURUM.md").write_text(text, encoding="utf-8")
        png = common.ROOT / "results" / "canli_egriler.png"
        try:
            gs = live_groups(rows)
            if gs:
                plot_live(gs, png)
        except Exception as exc:  # noqa: BLE001  (grafik hatası durum yazımını durdurmasın)
            print("canlı grafik hatası:", exc)
        (common.ROOT / "DURUM.html").write_text(render_html(rows, png.exists()), encoding="utf-8")
        if a.sync and Path(a.sync).is_dir():
            try:
                shutil.copyfile(common.ROOT / "DURUM.md", Path(a.sync) / "DURUM.md")
                shutil.copyfile(common.ROOT / "DURUM.html", Path(a.sync) / "DURUM.html")
                if png.exists():
                    (Path(a.sync) / "results").mkdir(exist_ok=True)
                    shutil.copyfile(png, Path(a.sync) / "results" / "canli_egriler.png")
            except OSError:
                pass
        if not a.loop:
            break
        time.sleep(a.loop)


if __name__ == "__main__":
    main()
