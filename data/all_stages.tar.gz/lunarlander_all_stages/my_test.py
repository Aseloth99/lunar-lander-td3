"""Kendi testini yap: ajan(lar)ı HİÇ GÖRÜLMEMİŞ rastgele bölümlerde oynatır; Türkçe özet + grafik üretir.

  python3 my_test.py                                   # ana sonuç (en son tamamlanan tur), 5 tohumun her biri 50 bölüm
  python3 my_test.py --episodes 100
  python3 my_test.py --groups td3/v2b ppo/tuned sac/fuel2x --episodes 30   # karşılaştırma
  python3 my_test.py --groups td3/v4big@800k sac/v4@800k sac/v4@1600k     # aynı koşunun 800 bin / 1,6 milyon anları
Sonuçlar: Desktop\\lunarlander\\kullanici_testleri\\ (CSV + PNG), grafik otomatik açılır.
Windows'ta: 2-AJANI-TEST-ET.bat dosyasına çift tıkla.
"""
import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import _deps  # noqa: F401,E402

import argparse  # noqa: E402
import json  # noqa: E402
import subprocess  # noqa: E402
import time  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import common  # noqa: E402
from evaluate import load_for_eval  # noqa: E402

DESKTOP = Path(os.environ.get("LUNAR_SYNC_DIR", "/yok"))  # isteğe bağlı: çıktıların kopyalanacağı klasör


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--groups", nargs="*", default=None, help="algo/etiket[@800k|@1600k] (varsayılan: ana sonuç)")
    p.add_argument("--ckpt", default=None, help="tüm gruplar için kontrol noktası: best | best_v2 | best_800k | "
                                                "best_1600k | final (varsayılan: gruptan)")
    p.add_argument("--episodes", type=int, default=50, help="tohum başına bölüm sayısı")
    p.add_argument("--test-seed", type=int, default=None, help="aynı bölümleri tekrar üretmek için")
    p.add_argument("--no-open", action="store_true", help="grafiği otomatik açma")
    a = p.parse_args()

    main_group, _, main_ckpt = common.latest_main()
    groups = a.groups or [main_group]
    ts = a.test_seed if a.test_seed is not None else int(time.time()) % 100000
    # hiç görülmemiş bölümler: eğitim/doğrulama/test kümelerinin (en çok ~21000) çok dışında
    seeds = list(np.random.default_rng(ts).integers(1_000_000, 2_000_000, size=a.episodes))
    print(f"Test: {groups} | tohum başına {a.episodes} bölüm | test kimliği {ts} (aynısını tekrar: --test-seed {ts})\n")

    env = common.make_env()
    rows = []
    for g in groups:
        base, _, suf = g.partition("@")
        algo, tag = base.split("/")
        for d in sorted((common.RUNS / algo / tag).glob("seed*")):
            if not (d / "DONE").exists():
                continue
            ckpt = a.ckpt or (main_ckpt if not a.groups else common.ckpt_for_group(d, suf))
            common.require_ckpt(d, ckpt)
            act = common.policy_act_fn(load_for_eval(d, algo, ckpt))
            # grafikte/özette hangi an olduğu görünsün (ör. sac/v4@800k)
            name = base + (f"@{ckpt[5:]}" if ckpt[5:] in ("800k", "1600k") else "")
            res = common.evaluate_episodes(act, seeds, env=env)
            for r in res:
                rows.append(dict(grup=name, tohum=d.name, **r))
            s = common.summarize(res)
            print(f"  {name:16s} {d.name}: ort {s['mean']:6.1f} | başarı %{100 * s['success']:5.1f} | "
                  f"çakılma {sum(r['outcome'] == 'crash' for r in res)}/{len(res)} | en kötü {s['min']:6.1f} | en iyi {s['max']:6.1f}")
    df = pd.DataFrame(rows)
    print("\nÖZET")
    for g, x in df.groupby("grup", sort=False):
        print(f"  {g:16s}: {len(x)} bölüm | ortalama {x.ret.mean():.1f} | başarı (≥200) %{100 * (x.ret >= 200).mean():.1f} | "
              f"çakılma {int((x.outcome == 'crash').sum())} | ≥300 %{100 * (x.ret >= 300).mean():.1f} | en kötü {x.ret.min():.1f}")

    out = DESKTOP / "kullanici_testleri" if DESKTOP.exists() else common.ROOT / "kullanici_testleri"
    out.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    df.to_csv(out / f"test_{stamp}.csv", index=False)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from report import st, INK, MUTED  # aynı renkler/paleti kullan
    fig, ax = plt.subplots(figsize=(10, 5.2))
    bins = np.arange(np.floor(min(df.ret.min(), 150) / 10) * 10, 340, 5)
    for g, x in df.groupby("grup", sort=False):
        name, _, col, _, _ = st(g)
        ax.hist(np.clip(x.ret, bins[0], bins[-1]), bins=bins, alpha=0.55 if len(groups) > 1 else 0.85, color=col,
                label=f"{name}: ort {x.ret.mean():.1f}, çakılma {int((x.outcome == 'crash').sum())}/{len(x)}",
                edgecolor="white", linewidth=0.6)
    for v, t in [(200, "çözüldü (200)"), (280, "hedef (280)"), (300, "300")]:
        ax.axvline(v, color=MUTED, lw=1, ls=(0, (3, 3)))
        ax.text(v, ax.get_ylim()[1] * 0.97, f" {t}", color=MUTED, fontsize=9, va="top")
    ax.set_xlabel("Bölüm puanı")
    ax.set_ylabel("Bölüm sayısı")
    ax.legend(loc="upper left", fontsize=9.5)
    ax.set_title(f"Kendi testin — {len(df)} hiç görülmemiş bölüm (test kimliği {ts})", loc="left", color=INK)
    fig.tight_layout()
    png = out / f"test_{stamp}.png"
    fig.savefig(png, dpi=150)
    print(f"\nKaydedildi: {png}")
    try:  # grafik sayfasına da ekle
        import make_dashboard
        make_dashboard.main()
    except Exception as exc:  # noqa: BLE001
        print("grafik sayfası güncellenemedi:", exc)
    if a.no_open:
        return
    try:  # grafiği Windows'ta aç
        win = subprocess.run(["wslpath", "-w", str(png)], capture_output=True, text=True).stdout.strip()
        subprocess.run(["explorer.exe", win], timeout=10)
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    main()
