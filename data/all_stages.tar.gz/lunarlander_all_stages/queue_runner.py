"""Basit iş kuyruğu: en fazla N eğitim sürecini paralel çalıştırır, biteni atlar, yarıda kalana devam eder.

İş dosyası: her satır bir `train.py` argüman dizisidir (# ile yorum):
  --algo sac --seed 0 --tag zoo
  --algo ppo --seed 0 --tag zoo

  python3 queue_runner.py --jobs jobs/baseline.txt --workers 4
İkinci kuyruk (başka bir kuyruk sürerken, makinedeki toplam yük sınırlı):
  python3 queue_runner.py --jobs jobs/stage10.txt --workers 6 --max-total 6 --after jobs/stage9.txt \
      --hold-cmd "bash scripts/stage10_hold.sh"
Arka planda, oturum kapansa da sürsün diye: bash scripts/start_queue.sh jobs/baseline.txt 4
"""
import _deps  # noqa: F401

import argparse
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

import common

ROOT = common.ROOT


def job_run_dir(argv):
    a = dict(zip(argv[::1], argv[1::1]))  # kaba ama yeterli: --algo X --seed N --tag T
    algo, seed, tag = a["--algo"], int(a["--seed"]), a.get("--tag", "zoo")
    return common.run_dir_for(algo, tag, seed), algo, tag, seed


def read_jobs(path):
    jobs = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            jobs.append(shlex.split(line))
    return jobs


HEAVY = {"train.py", "evaluate.py", "reselect.py"}


def procs():
    """(pid, argv) — /proc'tan; okunamayanlar atlanır."""
    for d in Path("/proc").iterdir():
        if d.name.isdigit():
            try:
                argv = (d / "cmdline").read_bytes().decode("utf-8", "ignore").split("\0")
            except OSError:
                continue
            yield int(d.name), argv


def heavy_count():
    """Makinedeki bütün eğitim/değerlendirme süreçleri (bu kuyruğunkiler dahil)."""
    return sum(1 for _, argv in procs() if len(argv) > 1 and "python" in Path(argv[0]).name
               and Path(argv[1]).name in HEAVY)


def held(pattern):
    me = os.getpid()
    return any(pid != me and any(pattern in x for x in argv) for pid, argv in procs())


def all_started(path):
    return all((job_run_dir(argv)[0] / "config.json").exists() for argv in read_jobs(path))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--jobs", required=True)
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--max-total", type=int, default=0,
                   help="0: sınır yok. >0: makinedeki bütün train/evaluate/reselect süreçleri bu sayının altındayken yeni "
                        "iş başlar (başka bir kuyruk sürerken ikinci kuyruk için)")
    p.add_argument("--after", default=None, help="bu iş dosyasının işlerinin HEPSİ başlamadan yeni iş başlatma")
    p.add_argument("--hold-while", default=None, help="komut satırında bu metin geçen bir süreç varken yeni iş başlatma")
    p.add_argument("--hold-cmd", default=None, help="bu komut 0 ile çıktığı sürece yeni iş başlatma (kapı betiği)")
    a = p.parse_args()

    jobs = read_jobs(a.jobs)

    log_dir = ROOT / "logs"
    log_dir.mkdir(exist_ok=True)
    qlog = open(log_dir / "queue.log", "a", encoding="utf-8", buffering=1)

    def say(msg):
        qlog.write(f"{common.now_iso()} {msg}\n")

    pending = []
    for argv in jobs:
        rd, algo, tag, seed = job_run_dir(argv)
        if (rd / "DONE").exists():
            say(f"atla (bitmiş): {algo}/{tag}/seed{seed}")
        else:
            pending.append((argv, rd, algo, tag, seed))
    say(f"kuyruk başladı: {len(pending)} iş, {a.workers} işçi, dosya={a.jobs}")

    def may_start():
        if a.after and not all_started(a.after):
            return False
        if a.hold_while and held(a.hold_while):
            return False
        if a.hold_cmd and subprocess.run(shlex.split(a.hold_cmd), cwd=str(ROOT)).returncode == 0:
            return False
        return a.max_total <= 0 or heavy_count() < a.max_total

    running = []  # (Popen, label)
    while pending or running:
        while pending and len(running) < a.workers and may_start():
            argv, rd, algo, tag, seed = pending.pop(0)
            # nice: bilgisayar uzun koşular sırasında kullanılabilir kalsın
            cmd = ["nice", "-n", "10", sys.executable, str(ROOT / "train.py")] + argv + ["--resume", "--overwrite"]
            logf = open(log_dir / f"{algo}_{tag}_seed{seed}.log", "a", encoding="utf-8")
            proc = subprocess.Popen(cmd, stdout=logf, stderr=subprocess.STDOUT, cwd=str(ROOT))
            running.append((proc, f"{algo}/{tag}/seed{seed}"))
            say(f"başladı: {algo}/{tag}/seed{seed} (pid {proc.pid})")
        time.sleep(5)
        still = []
        for proc, label in running:
            rc = proc.poll()
            if rc is None:
                still.append((proc, label))
            else:
                say(f"bitti: {label} (çıkış kodu {rc})")
        running = still
    say("kuyruk tamamlandı")


if __name__ == "__main__":
    main()
