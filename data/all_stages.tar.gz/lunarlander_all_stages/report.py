"""Sonuç tablosu + grafikler (PNG ve SVG, Türkçe etiketler, renk körlüğüne dayanıklı Okabe-Ito paleti).

  python3 report.py --split val  --groups sac/zoo td3/zoo ppo/zoo --out results/asama1_zoo   # doğrulama tohumları
  python3 report.py --split test --groups sac/fuel2x sac/zoo ppo/tuned td3/tuned ppo/zoo --out results/final_test
  (eski biçim "sac=zoo" de kabul edilir)

Çıktılar (--out altında): sonuc_tablosu.md, tohum_tablosu.md, ozet.json,
  ogrenme_egrileri.{png,svg}, puan_dagilimi.{png,svg}, algoritma_karsilastirma.{png,svg}

Ölçütler:
  - tohum başına: ortalama puan, başarı (puan >= 200), çakılma (son adım ödülü -100), en kötü bölüm
  - tohumlar üzerinden: ortalama +- %95 GA (t dağılımı, n-1 serbestlik derecesi), IQM (tüm bölümler birleşik,
    alt ve üst %25 atılmış ortalama), birleşik başarı/çakılma oranı, en kötü bölüm
  - hedef: HER tohumda ortalama >= 280, başarı >= %99, çakılma = 0 (en az 5 tohum)
"""
import _deps  # noqa: F401

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402
from scipy import stats  # noqa: E402

import common  # noqa: E402

# Grup = algoritma/etiket. Renkler Okabe-Ito alt kümesi; bu SIRAYLA dataviz doğrulayıcısından geçti
# (komşu çiftlerde CVD ΔE >= 11.4, normal görüş ΔE >= 18.4). Açık mavi, turuncu ve pembe zemine düşük kontrastlı ->
# her grup ayrıca farklı işaret şekli + doğrudan etiket + tablo ile ayırt edilir.
STYLE = {  # grup: (kısa ad, çok satırlı eksen etiketi, renk, işaret, eğitim ödülü)
    "sac/fuel2x": ("SAC + yakıt cezası†", "SAC\n+ yakıt cezası†", "#0072B2", "o", "yakıt cezası 2×"),
    "sac/zoo": ("SAC (zoo)", "SAC\n(zoo)", "#56B4E9", "D", "orijinal"),
    "ppo/tuned": ("PPO (Optuna)", "PPO\n(Optuna)", "#009E73", "^", "orijinal"),
    "td3/tuned": ("TD3 (Optuna)", "TD3\n(Optuna)", "#E69F00", "s", "orijinal"),
    "ppo/zoo": ("PPO (zoo)", "PPO\n(zoo)", "#CC79A7", "v", "orijinal"),
    "td3/zoo": ("TD3 (zoo)", "TD3\n(zoo)", "#E69F00", "s", "orijinal"),
    # Aşama 4 grupları. v2 grafik sırası [v2b, v2a, ppo/tuned, sac/fuel2x, td3/tuned] doğrulayıcıdan geçti
    # (komşu çiftlerde CVD ΔE >= 18.0); mevcut grupların renkleri değişmedi (renk varlığı izler).
    "td3/v2b": ("TD3 v2b (ana sonuç)", "TD3 v2b\n(ana sonuç)", "#D55E00", "P", "orijinal"),
    "td3/v2a": ("TD3 v2a", "TD3\nv2a", "#882255", "X", "orijinal"),
    # Aşama 5 (290 denemesi). Sıra [v2b, v3long, v3big, v3fuel] doğrulayıcıdan geçti.
    "td3/v3long": ("TD3 v3 uzun (800k)", "TD3 v3\nuzun", "#00A3A3", "h", "orijinal"),
    "td3/v3big": ("TD3 v3 büyük ağ", "TD3 v3\nbüyük ağ", "#6F5BC4", "*", "orijinal"),
    "td3/v3fuel": ("TD3 v3 + yakıt cezası†", "TD3 v3\n+ yakıt†", "#C2408F", "p", "yakıt cezası 2×"),
    # Aşama 6 (sınırları zorlama). Grafik sırası [v3long, v4big, v4small, sac/v4, ppo/tuned] doğrulayıcıdan geçti.
    "td3/v4big": ("TD3 büyük ağ", "TD3\nbüyük ağ", "#6F5BC4", "*", "orijinal"),
    "td3/v4small": ("TD3 küçük ağ", "TD3\nküçük ağ", "#D55E00", "P", "orijinal"),
    "sac/v4": ("SAC uzun", "SAC\nuzun", "#0072B2", "o", "orijinal"),
    # Aşama 7 (290 + sıfır çakılma). Grafikte yalnızca iki renk var: v4big (mor) ve v5big (kırmızımsı turuncu).
    "td3/v5big": ("TD3 büyük ağ + azalan öğr. hızı", "TD3 büyük ağ\nazalan hız", "#D55E00", "D", "orijinal"),
    # Aşama 8 (erken fren). Grafik sırası [v4big (mor), v6brake (kırmızımsı turuncu), v6soft (camgöbeği)]: mor-turuncu
    # (Aşama 6) ve turuncu-camgöbeği (Aşama 5) komşulukları doğrulayıcıdan geçmişti.
    "td3/v6brake": ("TD3 erken fren (güçlü ceza)†", "TD3 erken fren\ngüçlü†", "#D55E00", "s", "sert iniş cezası"),
    "td3/v6soft": ("TD3 erken fren (hafif ceza)†", "TD3 erken fren\nhafif†", "#00A3A3", "^", "sert iniş cezası"),
    # Aşama 9 (SAC büyük ağ). Grafik sırası [td3/v4big, td3/v6brake, sac/v4, sac/v9big, sac/v9lowent] doğrulayıcıdan
    # geçti (#6F5BC4, #D55E00, #0072B2, #009E73, #882255: komşu CVD ΔE >= 18, hepsi >= 3:1 kontrast).
    "sac/v9big": ("SAC büyük ağ", "SAC\nbüyük ağ", "#009E73", "h", "orijinal"),
    "sac/v9lowent": ("SAC büyük ağ, düşük entropi", "SAC büyük ağ\ndüşük entropi", "#882255", "p", "orijinal"),
    # Aşama 10 (agresif + frenli SAC). Grafik sırası [td3/v4big, td3/v6brake, td3/v6soft, sac/v9lowent, sac/v9big,
    # sac/v10brake, sac/v10soft] doğrulayıcıdan geçti (komşu çiftlerde normal görüş ΔE >= 18,7; en düşük CVD ΔE 6,5
    # mavi-macenta, protan -> ayrıca farklı işaret + doğrudan etiket + tablo; hepsi >= 3:1 kontrast).
    "sac/v10brake": ("SAC frenli (güçlü ceza)†", "SAC frenli\ngüçlü†", "#0072B2", "D", "sert iniş cezası"),
    "sac/v10soft": ("SAC frenli (hafif ceza)†", "SAC frenli\nhafif†", "#C2408F", "P", "sert iniş cezası"),
}
REWARD_NOTE = {"yakıt cezası 2×": "eğitimde yakıt cezası 2×",
               "sert iniş cezası": "eğitimde sert iniş cezası (yere hızlı değmeye ek ceza)"}
LEN_LABEL = {"800k": "800 bin", "1600k": "1,6 milyon"}
ALGO_COL = {"sac": "#0072B2", "td3": "#E69F00", "ppo": "#009E73"}
ALGO_MARK = {"sac": "o", "td3": "s", "ppo": "^"}
INK, MUTED, GRID, SURF = "#1f2328", "#59636e", "#d8dee4", "#fcfcfb"


def st(g):
    """(ad, eksen etiketi, renk, işaret, eğitim ödülü). 'algo/etiket@uzunluk' biçiminde renk aynı kalır, ada uzunluk
    eklenir; 800 bin okuması 'v' işaretiyle, 1,6 milyon okuması grubun kendi işaretiyle çizilir."""
    if "@" in g:
        base, suf = g.split("@", 1)
        name, axis, col, mark, rew = st(base)
        if suf in LEN_LABEL:
            mark = {"800k": "v", "1600k": mark}[suf]
            return (f"{name} · {LEN_LABEL[suf]}", f"{axis}\n{LEN_LABEL[suf]}", col, mark, rew)
        return name, axis, col, mark, rew
    if g in STYLE:
        return STYLE[g]
    algo, tag = g.split("/")
    return (f"{algo.upper()} ({tag})", f"{algo.upper()}\n({tag})", ALGO_COL.get(algo, MUTED), ALGO_MARK.get(algo, "o"),
            "orijinal")


def reward_note(groups):
    """Grafik dipnotu: eğitim ödülü değiştirilmiş (†) gruplar varsa ne değiştiği; yoksa boş."""
    rews = sorted({st(g)[4] for g in groups} - {"orijinal"})
    return ("† " + "; ".join(REWARD_NOTE[r] for r in rews) + "; değerlendirme orijinal ödülle") if rews else ""


def mark_size(mark, s, edge):
    """'*' kolları ince olduğu için aynı alanda neredeyse görünmez (beyaz kenar kolları yiyor): büyüt, kenarı incelt."""
    return (s * 2.6, 0.5) if mark == "*" else (s, edge)


plt.rcParams.update({
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
    "axes.edgecolor": GRID, "axes.labelcolor": INK, "text.color": INK, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "font.size": 11, "axes.titlesize": 12,
    "axes.titleweight": "bold", "legend.frameon": False, "svg.fonttype": "path",
})

TR_K = FuncFormatter(lambda x, _: f"{int(round(x / 1000))}")  # eksen "bin adım" cinsinden


# ------------------------------------------------------------------ veri
SPLIT_FILES = {"val": ["val_best_episodes.csv"], "val2": ["val2_episodes.csv"], "val3": ["val3_best_v2_episodes.csv"],
               "test": ["test_episodes.csv"], "test2": ["test2_episodes.csv"], "test2x": ["test2x_episodes.csv"],
               "test2all": ["test2_episodes.csv", "test2x_episodes.csv"], "val4": ["val4_best_v2_episodes.csv"],
               "test3": ["test3_episodes.csv"], "test3x": ["test3x_episodes.csv"],
               "test3all": ["test3_episodes.csv", "test3x_episodes.csv"],
               # Aşama 6: dosya adı kontrol noktasını içerir; '@ek' grup adından gelir (bkz. split_files)
               "val5": None, "test4": None, "test4x": None, "test4all": None,
               "val6": None, "test5": None, "test5x": None, "test5all": None,  # Aşama 7: aynı adlandırma
               "val7": None, "test6": None, "test6x": None, "test6all": None,  # Aşama 8
               "val8": None, "test7": None, "test7x": None, "test7all": None,  # Aşama 9
               "val9": None, "test8": None, "test8x": None, "test8all": None}  # Aşama 10


def split_files(split, suf):
    """Aşama 6 kümelerinde dosya adı: <küme>_best_<ek>_episodes.csv (ek: 800k, 1600k; şampiyon için v2)."""
    if SPLIT_FILES[split] is not None:
        return SPLIT_FILES[split]
    ck = f"best_{suf or 'v2'}"
    parts = {"val5": ["val5"], "test4": ["test4"], "test4x": ["test4x"], "test4all": ["test4", "test4x"],
             "val6": ["val6"], "test5": ["test5"], "test5x": ["test5x"], "test5all": ["test5", "test5x"],
             "val7": ["val7"], "test6": ["test6"], "test6x": ["test6x"], "test6all": ["test6", "test6x"],
             "val8": ["val8"], "test7": ["test7"], "test7x": ["test7x"], "test7all": ["test7", "test7x"],
             "val9": ["val9"], "test8": ["test8"], "test8x": ["test8x"], "test8all": ["test8", "test8x"]}[split]
    return [f"{p}_{ck}_episodes.csv" for p in parts]


def load_group(group, split):
    base, _, suf = group.partition("@")
    algo, tag = base.split("/")
    base = common.RUNS / algo / tag
    out = []
    for d in sorted(base.glob("seed*"), key=lambda p: int(p.name[4:])):
        if not (d / "DONE").exists():
            continue
        files = [d / f for f in split_files(split, suf)]
        if split == "val" and not files[0].exists():  # seçilmiş kontrol noktasını doğrulama tohumlarında değerlendir
            subprocess.run([sys.executable, str(common.ROOT / "evaluate.py"), "--run-dir", str(d), "--split", "val",
                            "--ckpt", "best"], check=True, capture_output=True)
        if not all(f.exists() for f in files):
            continue
        eps = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
        curve = pd.read_csv(d / "val_curve.csv").drop_duplicates("step", keep="last")
        out.append(dict(seed=int(d.name[4:]), eps=eps, curve=curve, dir=d))
    return out


def seed_metrics(eps):
    r = eps["ret"].values
    return dict(mean=float(r.mean()), success=float((r >= common.SOLVED).mean()),
                crash=float((eps["outcome"] == "crash").mean()), worst=float(r.min()), n=int(len(r)))


def ci95(x):
    x = np.asarray(x, float)
    n = len(x)
    if n < 2:
        return float(x.mean()), float("nan")
    return float(x.mean()), float(stats.t.ppf(0.975, n - 1) * x.std(ddof=1) / np.sqrt(n))


def summarize_group(seeds):
    sm = [seed_metrics(s["eps"]) for s in seeds]
    means = [m["mean"] for m in sm]
    m, h = ci95(means)
    pooled = np.concatenate([s["eps"]["ret"].values for s in seeds])
    crash_all = float(np.mean(np.concatenate([(s["eps"]["outcome"] == "crash").values for s in seeds])))
    ok = [x["mean"] >= 280 and x["success"] >= 0.99 and x["crash"] == 0 for x in sm]
    n_crash = int(sum((s["eps"]["outcome"] == "crash").sum() for s in seeds))
    return dict(n_seeds=len(seeds), seeds=[s["seed"] for s in seeds], mean=m, ci=h, seed_means=means,
                n_episodes=int(len(pooled)), n_crash=n_crash, zero_crash_seeds=int(sum(x["crash"] == 0 for x in sm)),
                iqm=float(stats.trim_mean(pooled, 0.25)), success=float((pooled >= common.SOLVED).mean()),
                crash=crash_all, worst=float(pooled.min()), per_seed=sm, seeds_meeting_target=int(sum(ok)),
                target_met=bool(len(ok) >= 5 and all(ok)))


# ------------------------------------------------------------------ tablolar
def write_tables(summ, out, split_name):
    L = [f"### Sonuçlar — {split_name}\n",
         "| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |",
         "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for g, s in summ.items():
        ci = "–" if np.isnan(s["ci"]) else f"± {s['ci']:.1f}"
        L.append(f"| {st(g)[0]} | {st(g)[4]} | {s['n_seeds']} | {s['mean']:.1f} {ci} | {s['iqm']:.1f} | "
                 f"{100 * s['success']:.1f}% | {100 * s['crash']:.1f}% ({s['n_crash']}/{s['n_episodes']}) | "
                 f"{s['zero_crash_seeds']}/{s['n_seeds']} | {s['worst']:.1f} | {s['seeds_meeting_target']}/{s['n_seeds']} |")
    L.append("\n_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç "
             "çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._")
    L.append("_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). "
             "IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._")
    rews = {st(g)[4] for g in summ} - {"orijinal"}
    if "yakıt cezası 2×" in rews:
        L.append("_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla "
                 "eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._")
    if "sert iniş cezası" in rews:
        L.append("_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her "
                 "satırda ORİJİNAL ödülle yapıldı._")
    L.append("")
    (out / "sonuc_tablosu.md").write_text("\n".join(L), encoding="utf-8")

    P = ["| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |", "|---|---:|---:|---:|---:|---:|:---:|"]
    for g, s in summ.items():
        for sd, m in zip(s["seeds"], s["per_seed"]):
            ok = m["mean"] >= 280 and m["success"] >= 0.99 and m["crash"] == 0
            P.append(f"| {st(g)[0]} | {sd} | {m['mean']:.1f} | {100 * m['success']:.0f}% | {100 * m['crash']:.0f}% | "
                     f"{m['worst']:.1f} | {'✔' if ok else '✘'} |")
    (out / "tohum_tablosu.md").write_text("\n".join(P) + "\n", encoding="utf-8")
    return "\n".join(L)


# ------------------------------------------------------------------ grafikler
def save(fig, out, name):
    fig.savefig(out / f"{name}.png", dpi=200, bbox_inches="tight")
    fig.savefig(out / f"{name}.svg", bbox_inches="tight")
    plt.close(fig)


def ref_lines(ax, x_text=0.01, right=False):
    """200 ve 280 çizgileri. right=True: etiketler eksenin sağ dışında (veri işaretleriyle çakışmasın)."""
    ax.axhline(200, color=MUTED, lw=1, ls=(0, (4, 3)), zorder=1)
    ax.axhline(280, color=MUTED, lw=1, ls=(0, (1, 2)), zorder=1)
    kw = dict(x=1.01, ha="left", va="center") if right else dict(x=x_text, ha="left", va="bottom")
    for y, t in [(200, "çözüldü\neşiği (200)" if right else "çözüldü eşiği (200)"), (280, "hedef (280)")]:
        ax.text(kw["x"], y, t, transform=ax.get_yaxis_transform(), va=kw["va"], ha=kw["ha"], fontsize=8.5,
                color=MUTED, clip_on=False)


def fig_curves(data, out, subtitle):
    # '@800k' ve '@1600k' aynı koşudan gelir: öğrenme eğrisi her çeşit için bir kez çizilir
    uniq = {}
    for g, v in data.items():
        uniq.setdefault(g.split("@")[0], v)
    data = uniq
    groups = list(data)
    n = len(groups)
    ncol = min(n, 3)
    nrow = int(np.ceil(n / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(max(4.9 * ncol, 7.0), 4.3 * nrow), sharey=True, squeeze=False)
    flat = axes.ravel()
    for ax, g in zip(flat, groups):
        name, _, col, _, _ = st(g)
        seeds = data[g]
        grid = np.unique(np.concatenate([s["curve"]["step"].values for s in seeds]))
        Y = np.array([np.interp(grid, s["curve"]["step"], s["curve"]["val_mean"]) for s in seeds])
        for y in Y:
            ax.plot(grid, y, color=col, lw=0.8, alpha=0.35, zorder=2)
        mu = Y.mean(0)
        if len(seeds) >= 3:
            h = stats.t.ppf(0.975, len(seeds) - 1) * Y.std(0, ddof=1) / np.sqrt(len(seeds))
            lo, hi, band = mu - h, mu + h, "%95 güven bandı"
        else:
            lo, hi, band = Y.min(0), Y.max(0), "tohumlar arası aralık"
        ax.fill_between(grid, lo, hi, color=col, alpha=0.18, lw=0, zorder=1)
        ax.plot(grid, mu, color=col, lw=2.2, zorder=3)
        ref_lines(ax)
        ax.set_title(f"{name}  ({len(seeds)} tohum)", color=INK, loc="left")
        ax.set_xlabel("Eğitim adımı (bin)")
        ax.xaxis.set_major_formatter(TR_K)
        ax.set_xlim(0, grid.max())
        handles = [Line2D([], [], color=col, lw=2.2, label="tohum ortalaması"),
                   Patch(color=col, alpha=0.25, lw=0, label=band),
                   Line2D([], [], color=col, lw=0.8, alpha=0.5, label="tek tek tohumlar")]
        ax.legend(handles=handles, loc="lower right", fontsize=8.5)
    for ax in flat[n:]:
        ax.set_visible(False)
    for r in range(nrow):
        axes[r][0].set_ylabel("Doğrulama puanı\n(deterministik, 20 bölüm)")
    top = max(310, max(np.max(s["curve"]["val_mean"]) for g in groups for s in data[g]) + 10)
    flat[0].set_ylim(top=top)
    fig.suptitle(f"Öğrenme eğrileri — {subtitle}", x=0.01, ha="left", fontsize=13, fontweight="bold")
    fig.tight_layout()
    save(fig, out, "ogrenme_egrileri")


def fig_distribution(data, summ, out, subtitle, ylabel):
    groups = list(data)
    rng = np.random.default_rng(0)
    fig, ax = plt.subplots(figsize=(2.4 * len(groups) + 3.2, 5.4))
    for i, g in enumerate(groups):
        name, _, col, mark, _ = st(g)
        seeds = data[g]
        n = len(seeds)
        offs = (np.arange(n) - (n - 1) / 2) * 0.13
        for off, s in zip(offs, seeds):
            r = s["eps"]["ret"].values
            ax.scatter(i + off + rng.uniform(-0.035, 0.035, len(r)), r, s=7, color=col, alpha=0.28, lw=0, zorder=2)
            sz, ew = mark_size(mark, 75, 1.6)
            ax.scatter([i + off], [r.mean()], s=sz, marker=mark, color=col, edgecolor=SURF, linewidth=ew, zorder=5)
        s_ = summ[g]
        ax.hlines(s_["mean"], i - 0.42, i + 0.42, color=INK, lw=2.2, zorder=4)
        if not np.isnan(s_["ci"]):
            ax.fill_between([i - 0.42, i + 0.42], s_["mean"] - s_["ci"], s_["mean"] + s_["ci"], color=INK, alpha=0.10, lw=0, zorder=3)
        ci = "" if np.isnan(s_["ci"]) else f" ± {s_['ci']:.0f}"
        ax.text(i, 1.01, f"ort. {s_['mean']:.0f}{ci}", transform=ax.get_xaxis_transform(), ha="center", va="bottom",
                fontsize=10, color=INK, fontweight="bold")
    ref_lines(ax, right=True)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels([st(g)[1] for g in groups], fontsize=10.5, color=INK)
    ax.set_xlim(-0.65, len(groups) - 0.35)
    ax.set_ylabel(ylabel)
    ax.grid(axis="x", visible=False)
    handles = [Line2D([], [], marker="o", ls="", color=MUTED, markersize=9, label="tohum ortalaması (büyük işaret)"),
               Line2D([], [], marker="o", ls="", color=MUTED, markersize=4, alpha=0.5, label="tek tek bölümler (küçük nokta)"),
               Line2D([], [], color=INK, lw=2.2, label="tohumlar üzerinden ortalama (şerit: %95 GA)")]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=3, fontsize=9)
    if reward_note(groups):
        fig.text(0.01, -0.06, reward_note(groups), fontsize=8.5, color=MUTED)
    fig.suptitle(subtitle, x=0.01, ha="left", fontsize=12.5, fontweight="bold", y=1.03)
    fig.tight_layout()
    save(fig, out, "puan_dagilimi")


def fig_compare(data, summ, out, subtitle):
    groups = list(data)
    fig, axes = plt.subplots(1, 3, figsize=(max(12.6, 3 * (1.25 * len(groups) + 1.2)), 4.6))
    allm = [m for g in groups for m in summ[g]["per_seed"]]
    lo_score = min(180, min(m["mean"] for m in allm) - 15)
    # başarı/çakılma eksenleri veriye göre: küçük farklar (örn. %0 ile %2 çakılma) görünür olsun
    lo_succ = max(-4.0, np.floor(min(100 * m["success"] for m in allm) / 5) * 5 - 5)
    hi_crash = max(3.0, 1.3 * max(100 * m["crash"] for m in allm))
    specs = [("Ortalama puan", lambda m: m["mean"], (lo_score, 305), ".0f", None),
             ("Başarı oranı: puan ≥ 200 (%)", lambda m: 100 * m["success"], (lo_succ, 100 + 0.18 * (100 - lo_succ)), ".1f", 99),
             ("Çakılma oranı (%)", lambda m: 100 * m["crash"], (-0.08 * hi_crash, hi_crash), ".2f", 0)]
    for ax, (title, f_seed, ylim, fmt, tgt) in zip(axes, specs):
        for i, g in enumerate(groups):
            _, _, col, mark, _ = st(g)
            ys = [f_seed(m) for m in summ[g]["per_seed"]]
            n = len(ys)
            xs = i + (np.arange(n) - (n - 1) / 2) * 0.11
            sz, ew = mark_size(mark, 55, 1.4)
            ax.scatter(xs, ys, s=sz, marker=mark, color=col, edgecolor=SURF, linewidth=ew, zorder=4, alpha=0.95)
            mval = float(np.mean(ys))
            ax.hlines(mval, i - 0.36, i + 0.36, color=INK, lw=2.2, zorder=3)
            ax.annotate(f"{mval:{fmt}}", (i, mval), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=9.5,
                        color=INK, fontweight="bold", zorder=6,
                        bbox=dict(boxstyle="round,pad=0.15", fc=SURF, ec="none", alpha=0.85))
        if tgt is not None:
            ax.axhline(tgt, color=MUTED, lw=1, ls=(0, (1, 2)))
            ax.text(1.01, tgt, "hedef", transform=ax.get_yaxis_transform(), va="center", ha="left", fontsize=8.5,
                    color=MUTED, clip_on=False)
        else:
            ref_lines(ax, right=True)
        ax.set_ylim(*ylim)
        ax.set_xticks(range(len(groups)))
        ax.set_xticklabels([st(g)[1] for g in groups], color=INK, fontsize=9.5)
        ax.set_xlim(-0.6, len(groups) - 0.4)
        ax.set_title(title, loc="left", color=INK)
        ax.grid(axis="x", visible=False)
    handles = [Line2D([], [], marker="o", ls="", color=MUTED, markersize=8, label="tek tek tohumlar"),
               Line2D([], [], color=INK, lw=2.2, label="tohumlar üzerinden ortalama")]
    fig.legend(handles=handles, loc="lower center", ncol=2, fontsize=9.5, bbox_to_anchor=(0.5, -0.06))
    if reward_note(groups):
        fig.text(0.01, -0.06, reward_note(groups), fontsize=8.5, color=MUTED)
    fig.suptitle(f"Algoritma karşılaştırması — {subtitle}", x=0.01, ha="left", fontsize=13, fontweight="bold")
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save(fig, out, "algoritma_karsilastirma")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--split", choices=list(SPLIT_FILES), required=True)
    p.add_argument("--groups", "--tags", nargs="+", required=True, help="algo/etiket, örn. sac/zoo (veya sac=zoo)")
    p.add_argument("--out", required=True)
    p.add_argument("--no-curves", action="store_true")
    p.add_argument("--table-only", action="store_true", help="yalnızca tablolar (grafik yok)")
    a = p.parse_args()

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    data = {}
    for g in a.groups:
        g = g.replace("=", "/")
        seeds = load_group(g, a.split)
        if seeds:
            data[g] = seeds
        else:
            print(f"[uyarı] {g}: tamamlanmış koşu yok, atlandı")
    if not data:
        sys.exit("veri yok")

    subtitle, ylabel, split_name = {
        "val": ("doğrulama tohumları (5000–5099), seçilmiş kontrol noktası", "Doğrulama puanı (100 bölüm)",
                "DOĞRULAMA tohumları 5000–5099 (test değil)"),
        "val2": ("doğrulama 5100–5599 (500 bölüm), çakılmaya duyarlı seçilmiş kontrol noktası",
                 "Doğrulama puanı (500 bölüm)", "DOĞRULAMA 5100–5599 (seçimde kullanıldı; iyimser)"),
        "val3": ("bağımsız doğrulama 5600–5999 (400 bölüm), çakılmaya duyarlı seçim", "Doğrulama puanı (400 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA 5600–5999 (seçimde kullanılmadı; test değil)"),
        "test": ("ilk test tohumları (10000–10099), deterministik politika", "Test puanı (100 bölüm)",
                 "İLK TEST tohumları 10000–10099"),
        "test2": ("YENİ test tohumları (20000–20099), deterministik politika", "Test puanı (100 bölüm)",
                  "YENİ TEST tohumları 20000–20099 (resmi, 100 bölüm)"),
        "test2x": ("ek test tohumları (20100–20999)", "Test puanı (900 bölüm)", "EK TEST 20100–20999 (900 bölüm)"),
        "test2all": ("YENİ test 20000–20999 (tohum başına 1000 bölüm), deterministik politika",
                     "Test puanı (1000 bölüm)", "YENİ TEST 20000–20999 (resmi 100 + ek 900 bölüm)"),
        "val4": ("bağımsız doğrulama 6000–6399 (400 bölüm)", "Doğrulama puanı (400 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA v3: 6000–6399 (test değil)"),
        "test3": ("EN YENİ test tohumları (30000–30099), deterministik politika", "Test puanı (100 bölüm)",
                  "EN YENİ TEST 30000–30099 (resmi, 100 bölüm)"),
        "test3x": ("ek test 30100–30999", "Test puanı (900 bölüm)", "EK TEST 30100–30999 (900 bölüm)"),
        "test3all": ("EN YENİ test 30000–30999 (tohum başına 1000 bölüm)", "Test puanı (1000 bölüm)",
                     "EN YENİ TEST 30000–30999 (resmi 100 + ek 900 bölüm)"),
        "val5": ("bağımsız doğrulama 6400–6799 (400 bölüm)", "Doğrulama puanı (400 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA v4: 6400–6799 (test değil)"),
        "test4": ("EN YENİ test tohumları (40000–40099), deterministik politika", "Test puanı (100 bölüm)",
                  "EN YENİ TEST 40000–40099 (resmi, 100 bölüm)"),
        "test4x": ("ek test 40100–40999", "Test puanı (900 bölüm)", "EK TEST 40100–40999 (900 bölüm)"),
        "test4all": ("EN YENİ test 40000–40999 (tohum başına 1000 bölüm)", "Test puanı (1000 bölüm)",
                     "EN YENİ TEST 40000–40999 (resmi 100 + ek 900 bölüm)"),
        "val6": ("bağımsız doğrulama 6800–7199 (400 bölüm)", "Doğrulama puanı (400 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA v5: 6800–7199 (test değil)"),
        "test5": ("EN YENİ test tohumları (50000–50099), deterministik politika", "Test puanı (100 bölüm)",
                  "EN YENİ TEST 50000–50099 (resmi, 100 bölüm)"),
        "test5x": ("ek test 50100–50999", "Test puanı (900 bölüm)", "EK TEST 50100–50999 (900 bölüm)"),
        "val7": ("bağımsız doğrulama 7200–9199 (2000 bölüm)", "Doğrulama puanı (2000 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA v6: 7200–9199 (test değil)"),
        "test6": ("EN YENİ test tohumları (60000–60099), deterministik politika", "Test puanı (100 bölüm)",
                  "EN YENİ TEST 60000–60099 (resmi, 100 bölüm)"),
        "test6x": ("ek test 60100–61999", "Test puanı (1900 bölüm)", "EK TEST 60100–61999 (1900 bölüm)"),
        "val8": ("bağımsız doğrulama 70000–71999 (2000 bölüm)", "Doğrulama puanı (2000 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA v7: 70000–71999 (test değil)"),
        "test7": ("EN YENİ test tohumları (80000–80099), deterministik politika", "Test puanı (100 bölüm)",
                  "EN YENİ TEST 80000–80099 (resmi, 100 bölüm)"),
        "test7x": ("ek test 80100–81999", "Test puanı (1900 bölüm)", "EK TEST 80100–81999 (1900 bölüm)"),
        "val9": ("bağımsız doğrulama 90000–91999 (2000 bölüm)", "Doğrulama puanı (2000 bölüm)",
                 "BAĞIMSIZ DOĞRULAMA v8: 90000–91999 (test değil)"),
        "test8": ("EN YENİ test tohumları (100000–100099), deterministik politika", "Test puanı (100 bölüm)",
                  "EN YENİ TEST 100000–100099 (resmi, 100 bölüm)"),
        "test8x": ("ek test 100100–101999", "Test puanı (1900 bölüm)", "EK TEST 100100–101999 (1900 bölüm)"),
        "test8all": ("EN YENİ test 100000–101999 (tohum başına 2000 bölüm)", "Test puanı (2000 bölüm)",
                     "EN YENİ TEST 100000–101999 (resmi 100 + ek 1900 bölüm)"),
        "test7all": ("EN YENİ test 80000–81999 (tohum başına 2000 bölüm)", "Test puanı (2000 bölüm)",
                     "EN YENİ TEST 80000–81999 (resmi 100 + ek 1900 bölüm)"),
        "test6all": ("EN YENİ test 60000–61999 (tohum başına 2000 bölüm)", "Test puanı (2000 bölüm)",
                     "EN YENİ TEST 60000–61999 (resmi 100 + ek 1900 bölüm)"),
        "test5all": ("EN YENİ test 50000–50999 (tohum başına 1000 bölüm)", "Test puanı (1000 bölüm)",
                     "EN YENİ TEST 50000–50999 (resmi 100 + ek 900 bölüm)"),
    }[a.split]
    summ = {k: summarize_group(v) for k, v in data.items()}
    table = write_tables(summ, out, split_name)
    json.dump(summ, open(out / "ozet.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    if not a.table_only:
        if not a.no_curves:
            fig_curves(data, out, "doğrulama tohumları (5000–5019), eğitim sırasında")
        fig_distribution(data, summ, out, f"Puan dağılımı — {subtitle}", ylabel)
        fig_compare(data, summ, out, subtitle)
    print(table)
    print(f"\ngrafikler ve tablolar: {out}")


if __name__ == "__main__":
    main()
