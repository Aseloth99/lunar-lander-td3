"""Ana sonuç grubunu ÖNCEDEN KAYITLI kurala göre (results/secim_kurali.md) YALNIZCA doğrulama verisiyle seçer.

  python3 report.py --split val --groups sac/fuel2x sac/zoo ppo/tuned td3/tuned ppo/zoo td3/zoo --out results/final_val
  python3 select_main.py --summary results/final_val/ozet.json
Çıktı: results/ana_sonuc_secimi.json
"""
import _deps  # noqa: F401

import argparse
import json

import common

CANDIDATES = ["sac/fuel2x", "td3/tuned", "ppo/tuned", "ppo/zoo"]


def key(s):
    # 1) hedefi sağlayan tohum sayısı  2) birleşik başarı  3) düşük çakılma  4) ortalama puan
    return (s["seeds_meeting_target"], s["success"], -s["crash"], s["mean"])


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--summary", default="results/final_val/ozet.json")
    a = p.parse_args()
    summ = json.load(open(a.summary, encoding="utf-8"))
    rows = []
    for g in CANDIDATES:
        s = summ.get(g)
        if s is None or s["n_seeds"] < 5:
            print(f"[aday değil] {g}: {0 if s is None else s['n_seeds']} tamamlanmış tohum (5 gerekli)")
            continue
        rows.append((g, s))
    rows.sort(key=lambda r: key(r[1]), reverse=True)
    for g, s in rows:
        print(f"{g:12s} hedef-tohum {s['seeds_meeting_target']}/5  başarı {100 * s['success']:.1f}%  "
              f"çakılma {100 * s['crash']:.1f}%  ort {s['mean']:.1f}")
    best = rows[0][0]
    orig = [g for g, s in rows if g != "sac/fuel2x"]
    out = dict(rule="results/secim_kurali.md (önceden kayıt)", data="doğrulama tohumları 5000-5099", decided=common.now_iso(),
               ranking=[g for g, _ in rows], main=best, best_original_reward=orig[0] if orig else None)
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi.json", out)
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
