"""SONUCLAR.html: HER ŞEY tek sayfada (tarayıcıda açılır): güncel özet ve "290 sorusu", tüm aşamaların karşılaştırması,
her aşamanın tabloları/grafikleri/videosu, kendi testlerin ve README'nin tamamı.
  python3 make_dashboard.py      (my_test.py her testten sonra bunu kendisi çağırır)
Windows'ta: 3-SONUCLARI-GOSTER.bat
"""
import os
import _deps  # noqa: F401

import html
import json
import re
import shutil
from pathlib import Path

import common

R = common.ROOT
RES = R / "results"
DESKTOP = Path(os.environ.get("LUNAR_SYNC_DIR", "/yok"))  # isteğe bağlı: çıktıların kopyalanacağı klasör

# (aşama, test klasörü, 1000'lik test klasörü, doğrulama/eğri klasörü, seçim dosyası, video, test bölümleri, ne denendi)
ROUNDS = [
    ("Aşama 10", "final_test8", "final_test8_1000", "final_val9", "ana_sonuc_secimi_v8.json", "en_iyi_ajan_v8.gif",
     "100000–101999", "Agresif + frenli SAC: düşük entropili büyük ağ SAC, eğitimde sert inişe ek cezayla (güçlü ve hafif "
     "iki çeşit). TD3'ler ve Aşama 9'un SAC'ları aynı yeni testte bir kez daha ölçüldü."),
    ("Aşama 9", "final_test7", "final_test7_1000", "final_val8", "ana_sonuc_secimi_v7.json", "en_iyi_ajan_v7.gif",
     "80000–81999", "SAC'a TD3'ü iyileştiren ayarlar (büyük ağ, γ 0,995) ve düşük entropi denendi; TD3'ün iki ajanı da "
     "aynı yeni testte yeniden ölçüldü."),
    ("Aşama 8", "final_test6", "final_test6_1000", "final_val7", "ana_sonuc_secimi_v6.json", "en_iyi_ajan_v6.gif",
     "60000–61999", "Erken fren: eğitimde yere hızlı değmeye ek ceza (güçlü ve hafif iki çeşit). Seçimde önce en az "
     "çakılma, sonra en yüksek puan; doğrulama ve test öncekilerden 5 kat büyük (2000 bölüm/tohum)."),
    ("Aşama 7", "final_test5", "final_test5_1000", "final_val6", "ana_sonuc_secimi_v5.json", "en_iyi_ajan_v5.gif",
     "50000–50999", "Azalan öğrenme hızı denendi (TD3 büyük ağ, 1,6 milyon adım). Kural yine Aşama 6'nın 1,6 milyonluk "
     "ajanını seçti. \"Hiç çakılmadan 290 üstü?\" sorusunun cevabı: kıl payı hayır."),
    ("Aşama 6", "final_test4", "final_test4_1000", "final_val5", "ana_sonuc_secimi_v4.json", "en_iyi_ajan_v4.gif",
     "40000–40999", "Daha uzun eğitim: TD3 büyük ve küçük ağ, SAC; 1,6 milyon adım (800 bin anı da ayrıca)."),
    ("Aşama 5", "final_test3", "final_test3_1000", "final_val4", "ana_sonuc_secimi_v3.json", "en_iyi_ajan_v3.gif",
     "30000–30999", "290 denemesi: uzun eğitim (800 bin), büyük ağ, eğitimde yakıt cezası."),
    ("Aşama 4", "final_test2", "final_test2_1000", "final_val3", "ana_sonuc_secimi_v2.json", "en_iyi_ajan_v2.gif",
     "20000–20999", "Çakılmayı sıfırlama: daha sağlam TD3 (v2a, v2b) ve çakılmaya duyarlı kontrol noktası seçimi."),
    ("Aşama 3", "final_test", None, "final_val", "ana_sonuc_secimi.json", "en_iyi_ajan.gif",
     "10000–10099", "Optuna ayarlarıyla 5'er tohum, ilk resmi test (hedef karşılanmadı)."),
]

CSS = """
:root{--bg:#fcfcfb;--ink:#1f2328;--muted:#59636e;--line:#d8dee4;--soft:#f1f5f9;--accent:#6F5BC4}
body{font-family:system-ui,Segoe UI,sans-serif;background:var(--bg);color:var(--ink);margin:24px auto;max-width:1150px;
padding:0 16px;line-height:1.55}
h1{font-size:26px;margin:0} h2{font-size:20px;margin:36px 0 8px;padding-top:8px;border-top:1px solid var(--line)}
h3{font-size:17px;margin:22px 0 6px} h4{font-size:15px;margin:16px 0 4px}
.muted{color:var(--muted);font-size:14px} a{color:#0b5cad}
.kpi{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0} .kpi div{border:1px solid var(--line);border-radius:10px;
padding:10px 16px;min-width:150px;background:#fff} .kpi b{display:block;font-size:24px}
img{max-width:100%;border:1px solid var(--line);border-radius:8px}
table{border-collapse:collapse;width:100%;font-size:13.5px;margin:8px 0} td,th{padding:6px 8px;
border-bottom:1px solid var(--line);text-align:left;vertical-align:top} th{background:var(--soft)}
.info{background:var(--soft);border:1px solid var(--line);border-radius:10px;padding:12px 16px;margin:12px 0;font-size:15px}
.answer{background:#fff7ed;border-color:#f3c99b}
.tw{overflow-x:auto} figure{margin:12px 0} figcaption{color:var(--muted);font-size:13px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
nav{position:sticky;top:0;background:var(--bg);padding:8px 0;border-bottom:1px solid var(--line);z-index:2;font-size:14px}
nav a{margin-right:14px;text-decoration:none}
details{border:1px solid var(--line);border-radius:10px;padding:8px 14px;margin:10px 0;background:#fff}
summary{cursor:pointer;font-weight:600;font-size:16px;padding:4px 0}
pre{background:var(--soft);padding:10px;border-radius:8px;overflow-x:auto;font-size:13px}
code{background:var(--soft);padding:1px 4px;border-radius:4px;font-size:90%}
.report img{max-width:100%}
@media(max-width:800px){.grid{grid-template-columns:1fr}}
"""


# ------------------------------------------------------------------ küçük Markdown -> HTML (README ve tablolar için)
def _inline(s):
    s = html.escape(s, quote=False)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)\)", r"<img alt='\1' src='\2'>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r"<a href='\2' target='_blank'>\1</a>", s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = re.sub(r"(?<![\w*])\*(?!\s)([^*\n]+?)\*(?![\w*])", r"<i>\1</i>", s)
    s = re.sub(r"(?<![\w/])_(?!\s)([^_\n]+?)_(?![\w])", r"<i>\1</i>", s)
    return s


def md_to_html(text, shift=1):
    lines, out, i = text.splitlines(), [], 0
    n = len(lines)
    while i < n:
        l = lines[i]
        if l.startswith("```"):
            j, buf = i + 1, []
            while j < n and not lines[j].startswith("```"):
                buf.append(lines[j])
                j += 1
            out.append("<pre><code>" + html.escape("\n".join(buf)) + "</code></pre>")
            i = j + 1
            continue
        m = re.match(r"(#{1,5}) (.*)", l)
        if m:
            lv = min(len(m.group(1)) + shift, 6)
            out.append(f"<h{lv}>{_inline(m.group(2))}</h{lv}>")
            i += 1
            continue
        if l.startswith("|"):
            rows = []
            while i < n and lines[i].startswith("|"):
                rows.append(lines[i])
                i += 1
            body = []
            for k, row in enumerate(rows):
                if k == 1 and re.fullmatch(r"\|[\s:|-]+\|?", row.strip()):
                    continue
                tag = "th" if k == 0 else "td"
                cells = [c.strip() for c in row.strip().strip("|").split("|")]
                body.append("<tr>" + "".join(f"<{tag}>{_inline(c)}</{tag}>" for c in cells) + "</tr>")
            out.append("<div class=tw><table>" + "".join(body) + "</table></div>")
            continue
        if l.startswith("- "):
            items = []
            while i < n and (lines[i].startswith("- ") or (items and lines[i].startswith("  ") and lines[i].strip())):
                if lines[i].startswith("- "):
                    items.append(lines[i][2:])
                else:
                    items[-1] += " " + lines[i].strip()
                i += 1
            out.append("<ul>" + "".join(f"<li>{_inline(x)}</li>" for x in items) + "</ul>")
            continue
        if not l.strip():
            i += 1
            continue
        buf = []
        while i < n and lines[i].strip() and not lines[i].startswith(("#", "|", "- ", "```")):
            buf.append(lines[i].strip())
            i += 1
        out.append("<p>" + _inline(" ".join(buf)) + "</p>")
    return "\n".join(out)


def md_file(path, shift=2):
    p = Path(path)
    return md_to_html(p.read_text(encoding="utf-8"), shift) if p.exists() else ""


def readme_section(text, prefix):
    """README'de '## <prefix>...' başlıklı bölümün (bir sonraki '## 'ye kadar) Markdown metni."""
    parts = re.split(r"(?m)^(?=## )", text)
    return next((p for p in parts if p.startswith("## " + prefix)), "")


def img(path, caption=""):
    if not (RES / path).exists():
        return ""
    cap = f"<figcaption>{html.escape(caption)}</figcaption>" if caption else ""
    return f"<figure><img loading='lazy' src='results/{path}'>{cap}</figure>"


def below(x):  # 200 altı bölüm sayısı (yüzde yuvarlanınca %99,96 da "%100,0" görünür)
    return int(round((1 - x["success"]) * x["n_episodes"]))


def questions(tst, sel_f):
    """Aşamanın önceden tanımlı sorularının cevap kutusu (ölçüt o aşamanın kural dosyasındaki gibi). Hata -> boş."""
    from report import st
    try:
        sel = json.load(open(RES / sel_f, encoding="utf-8"))
        m = json.load(open(RES / tst / "ozet.json", encoding="utf-8"))[sel["main"]]
        q290 = ""
        if tst == "final_test6":  # Aşama 8'in önceden tanımlı soruları (results/secim_kurali_v6.md)
            bp = RES / "final_test6_1000" / "ozet.json"
            mb = json.load(open(bp, encoding="utf-8")).get(sel["main"]) if bp.exists() else None
            if mb:
                q290 = (f"<div class='info answer'><b>\"Sıfır çakılma?\" — cevap: {'EVET' if mb['n_crash'] == 0 else 'HAYIR'}</b>"
                        f" (genişletilmiş test, 60000–61999: {mb['n_crash']}/{mb['n_episodes']} çakılma, 200 altı "
                        f"{below(mb)}/{mb['n_episodes']}).<br><b>\"Puan ne oldu?\"</b> Aynı {mb['n_episodes']} bölümde ortalama "
                        f"<b>{mb['mean']:.2f}</b> ({'290 üstü' if mb['mean'] >= 290 else '290 altı'}). Resmi test (500 bölüm): "
                        f"ortalama {m['mean']:.2f}, çakılma {m['n_crash']}/{m['n_episodes']}.</div>")
        if tst == "final_test5":  # Aşama 7'nin önceden tanımlı sorusu (results/secim_kurali_v5.md)
            def verdict(x):
                return x["n_crash"] == 0 and below(x) == 0 and x["mean"] >= 290.0

            def facts(x):
                return (f"ortalama {x['mean']:.2f}, çakılma {x['n_crash']}/{x['n_episodes']}, "
                        f"200 altı {below(x)}/{x['n_episodes']}")
            bp = RES / "final_test5_1000" / "ozet.json"
            m1000 = json.load(open(bp, encoding="utf-8")).get(sel["main"]) if bp.exists() else None
            more = (f"<br>Genişletilmiş test (5000 bölüm, 50000–50999): {facts(m1000)} → "
                    f"<b>{'EVET' if verdict(m1000) else 'HAYIR'}</b>") if m1000 else ""
            q290 = (f"<div class='info answer'><b>\"Hiç çakılmadan 290 üstü?\" — cevap: {'EVET' if verdict(m) else 'HAYIR'}</b>"
                    f" (resmi test, 500 bölüm: {facts(m)}; üçü birden gerekli: 0 çakılma, 0 bölüm 200 altı, "
                    f"ortalama ≥ 290).{more}</div>")
        bp = RES / f"{tst}_1000" / "ozet.json"
        big = json.load(open(bp, encoding="utf-8")) if bp.exists() else {}

        def yn(b):
            return "EVET" if b else "HAYIR"

        def nm(g):
            return html.escape(st(g)[0])
        if tst == "final_test7" and big:  # Aşama 9 (results/secim_kurali_v7.md)
            c = sel["sac_champion"]
            x, t4, s4 = big[c], big["td3/v4big@1600k"], big["sac/v4@1600k"]
            lo, hi = big["sac/v9lowent@1600k"], big["sac/v9big@1600k"]
            n = x["n_episodes"]
            q290 = ("<div class='info answer'>"
                    f"<b>\"SAC, TD3'ü puanda geçti mi?\" — {yn(x['mean'] > t4['mean'])}</b>: SAC şampiyonu ({nm(c)}) "
                    f"{x['mean']:.2f}, en yüksek puanlı TD3 {t4['mean']:.2f} (fark {x['mean'] - t4['mean']:+.2f}; aynı {n} "
                    f"bölüm, 80000–81999). Çakılma: SAC {x['n_crash']}/{n}, TD3 {t4['n_crash']}/{n}.<br>"
                    f"<b>\"Büyük ağ SAC'ı iyileştirdi mi?\" — {yn(x['mean'] > s4['mean'])}</b>: {x['mean']:.2f}, eski SAC "
                    f"(küçük ağ) {s4['mean']:.2f}.<br>"
                    f"<b>\"Düşük entropi işe yaradı mı?\" — {yn(lo['mean'] > hi['mean'])}</b>: 1,6 milyon adımda düşük "
                    f"entropi {lo['mean']:.2f}, otomatik entropi {hi['mean']:.2f}.</div>")
        if tst == "final_test8" and big:  # Aşama 10 (results/secim_kurali_v8.md)
            c = sel["stage10_pick"]
            x, t4, t6 = big[c], big["td3/v4big@1600k"], big["td3/v6brake@1600k"]
            n = x["n_episodes"]
            both = x["mean"] >= t4["mean"] and x["n_crash"] == 0
            cost = []
            for k, lab in [("1600k", "1,6 milyon"), ("800k", "800 bin")]:
                lo = big[f"sac/v9lowent@{k}"]
                parts = [f"{w} ceza: çakılma {big[f'sac/{t}@{k}']['n_crash']} (cezasız {lo['n_crash']}), ortalama farkı "
                         f"{big[f'sac/{t}@{k}']['mean'] - lo['mean']:+.2f}" for t, w in [("v10brake", "güçlü"), ("v10soft", "hafif")]]
                cost.append(f"{lab}: " + "; ".join(parts))
            b, so = big["sac/v10brake@1600k"], big["sac/v10soft@1600k"]
            win = "güçlü" if (b["n_crash"], -b["mean"]) < (so["n_crash"], -so["mean"]) else "hafif"
            q290 = ("<div class='info answer'>"
                    f"<b>\"Hem yüksek puan hem sıfır çakılma?\" — {yn(both)}</b>: seçilen frenli SAC ({nm(c)}) ortalama "
                    f"{x['mean']:.2f} (en yüksek puanlı TD3 {t4['mean']:.2f}: puan şartı "
                    f"{'sağlandı' if x['mean'] >= t4['mean'] else 'sağlanmadı'}), çakılma {x['n_crash']}/{n} (sıfır çakılma "
                    f"şartı {'sağlandı' if x['n_crash'] == 0 else 'sağlanmadı'}); aynı {n} bölüm, 100000–101999.<br>"
                    f"<b>\"Fren SAC'ta ne kazandırdı, neye mal oldu?\"</b> " + " · ".join(cost) + ".<br>"
                    f"<b>\"Güçlü mü hafif mi?\" — {win}</b> (1,6 milyon: güçlü {b['n_crash']} çakılma / {b['mean']:.2f}, "
                    f"hafif {so['n_crash']} / {so['mean']:.2f}).<br>"
                    f"<b>\"En güvenli TD3 kadar güvenli mi?\" — {yn(x['n_crash'] <= t6['n_crash'])}</b>: {x['n_crash']} "
                    f"çakılma, en güvenli TD3 {t6['n_crash']}.</div>")
        return q290
    except Exception as e:  # noqa: BLE001 - sayfa her durumda üretilsin
        return f"<div class=info>Soru kutusu üretilemedi: {html.escape(str(e))}</div>"


# ------------------------------------------------------------------ sayfa
def main():
    from report import st
    avail = [r for r in ROUNDS if (RES / r[1] / "ozet.json").exists() and (RES / r[4]).exists()]
    stage, tst, big, val, sel_f, gif, rng, _ = avail[0]  # en güncel tamamlanmış tur
    s = json.load(open(RES / tst / "ozet.json", encoding="utf-8"))
    sel = json.load(open(RES / sel_f, encoding="utf-8"))
    m = s[sel["main"]]
    main_name = st(sel["main"])[0].replace(" (ana sonuç)", "")

    q290 = questions(tst, sel_f)

    # tüm aşamalar bir bakışta
    rows = []
    for stg, t, b, _v, sf, _g, rg, desc in avail:
        o = json.load(open(RES / t / "ozet.json", encoding="utf-8"))
        sl = json.load(open(RES / sf, encoding="utf-8"))
        mm = o.get(sl["main"])
        if mm is None:
            continue
        ob = json.load(open(RES / b / "ozet.json", encoding="utf-8")).get(sl["main"]) if b and (RES / b / "ozet.json").exists() else None
        ext = (f"{ob['mean']:.1f} · {ob['n_crash']}/{ob['n_episodes']}" if ob else "—")
        if "n_episodes" not in mm:  # Aşama 3'ün özetinde sayılar yok: 100 bölüm/tohum, oran -> sayı
            mm = dict(mm, n_episodes=100 * mm["n_seeds"], n_crash=int(round(mm["crash"] * 100 * mm["n_seeds"])))
        rows.append(f"<tr><td><b>{stg}</b><br><span class=muted>{sl['decided'][:10]}</span></td><td>{html.escape(desc)}</td>"
                    f"<td>{html.escape(st(sl['main'])[0].replace(' (ana sonuç)', ''))}</td><td>{rg}</td>"
                    f"<td><b>{mm['mean']:.1f}</b> ± {mm['ci']:.1f}</td><td>{mm['n_crash']}/{mm['n_episodes']}</td>"
                    f"<td>%{100 * mm['success']:.1f}</td><td>{ext}</td></tr>")
    overview = ("<div class=tw><table><tr><th>Aşama</th><th>Ne denendi</th><th>Ana sonuç (önceden yazılmış kurala göre)</th>"
                "<th>Test bölümleri</th><th>Resmi test ort. ± %95 GA</th><th>Çakılma (resmi)</th><th>Başarı ≥200</th>"
                "<th>Genişletilmiş test (1000–2000 bölüm/tohum): ort. · çakılma</th></tr>" + "".join(rows) + "</table></div>"
                "<p class=muted>Aşama 1–2 (zoo ayarları, Optuna araması) yalnızca doğrulama verisiyle ölçüldü; test yoktu "
                "(aşağıda ayrıntıları var).</p>")

    # her aşamanın ayrıntısı (en yenisi açık)
    det = []
    for k, (stg, t, b, v, sf, g, rg, desc) in enumerate(avail):
        body = [f"<p>{html.escape(desc)}</p>", "<h4>Resmi test (100 bölüm/tohum)</h4>", md_file(RES / t / "sonuc_tablosu.md", 3)]
        if b:
            body += [f"<h4>Genişletilmiş test ({2000 if stg in ('Aşama 8', 'Aşama 9', 'Aşama 10') else 1000} bölüm/tohum)</h4>", md_file(RES / b / "sonuc_tablosu.md", 3)]
        gj = RES / g.replace(".gif", ".json")
        ng = len(json.load(open(gj, encoding="utf-8"))["episodes"]) if gj.exists() else 4
        body.append("<div class=grid>" + img(g, f"{stg}: ana sonucun testteki ilk {ng} bölümü (ayıklanmadan)")
                    + img(f"{v}/ogrenme_egrileri.png", "Öğrenme eğrileri (doğrulama bölümleri, eğitim sırasında)") + "</div>")
        body.append(img(f"{t}/algoritma_karsilastirma.png", "Karşılaştırma: ortalama, başarı, çakılma (resmi test)"))
        if b:
            body.append(img(f"{b}/algoritma_karsilastirma.png", f"Karşılaştırma ({2000 if stg in ('Aşama 8', 'Aşama 9', 'Aşama 10') else 1000} bölüm/tohum)"))
        body.append(img(f"{t}/puan_dagilimi.png", "Puan dağılımı (resmi test)"))
        if k > 0:  # en güncel turun soru kutusu zaten en üstte
            body.insert(1, questions(t, sf))
        extra = {"final_test7": [("sac_sampiyonu_v7.gif", "Aşama 9'un SAC şampiyonu, testin ilk 4 bölümü")],
                 "final_test8": [("en_yuksek_puan_v8.gif", "Aşama 10: en yüksek puanlı ajan (TD3 büyük ağ · 1,6 milyon, "
                                  "tohum 1), testin ilk 5 bölümü"),
                                 ("frenli_sac_v8.gif", "Aşama 10'un frenli SAC seçimi, testin ilk 4 bölümü")]}.get(t, [])
        for e in extra:
            body.append(img(*e))
        rule = {"ana_sonuc_secimi_v8.json": "secim_kurali_v8.md", "ana_sonuc_secimi_v7.json": "secim_kurali_v7.md", "ana_sonuc_secimi_v6.json": "secim_kurali_v6.md", "ana_sonuc_secimi_v5.json": "secim_kurali_v5.md", "ana_sonuc_secimi_v4.json": "secim_kurali_v4.md",
                "ana_sonuc_secimi_v3.json": "secim_kurali_v3.md", "ana_sonuc_secimi_v2.json": "secim_kurali_v2.md",
                "ana_sonuc_secimi.json": "secim_kurali.md"}[sf]
        body.append(f"<details><summary>Önceden yazılmış seçim kuralı ({rule})</summary>{md_file(RES / rule, 2)}</details>")
        det.append(f"<details {'open' if k == 0 else ''}><summary>{stg} — test {rg}</summary>{''.join(body)}</details>")
    det.append("<details><summary>Aşama 1–2 — zoo ayarları ve Optuna (yalnızca doğrulama)</summary>"
               + md_file(RES / "asama1_zoo" / "sonuc_tablosu.md", 3)
               + "<div class=grid>" + img("asama1_zoo/algoritma_karsilastirma.png", "Aşama 1: zoo ayarlarıyla SAC, TD3, PPO")
               + img("asama1_zoo/ogrenme_egrileri.png", "Aşama 1: öğrenme eğrileri") + "</div>"
               + md_file(RES / "asama2_optuna" / "OZET.md", 3) + "</details>")

    readme = (R / "README.md").read_text(encoding="utf-8")
    summary_md = readme_section(readme, "Kısaca sonuç")
    tests_dir = (DESKTOP if DESKTOP.exists() else R) / "kullanici_testleri"  # my_test.py ile aynı yer
    tests = sorted(tests_dir.glob("test_*.png"), reverse=True)[:6] if tests_dir.exists() else []
    tests_html = "".join(f"<figure><img src='kullanici_testleri/{p.name}'><figcaption>{p.stem}</figcaption></figure>"
                         for p in tests) or "<p class=muted>Henüz kendi testin yok: <b>2-AJANI-TEST-ET</b> dosyasına çift tıkla.</p>"
    running = any(json.load(open(p)).get("state") == "running" for p in R.glob("runs/*/*/seed*/progress.json"))
    live = ("<div class=info><b>Şu an bir eğitim sürüyor.</b> Canlı durum: <b>4-SUREN-EGITIMI-IZLE</b>. Bitip test edilince "
            "bu sayfa kendiliğinden güncellenir.</div>" + img("canli_egriler.png", "Süren eğitimin eğrileri")) if running else ""

    page = f"""<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ay'a İniş — Tüm Sonuçlar</title><style>{CSS}</style></head><body>
<h1>Ay'a İniş Ajanı — Tüm Sonuçlar</h1>
<p class=muted>Son güncelleme: {common.now_iso()} · En son tamamlanmış tur: {stage} (test {rng}) · Ana sonuç: <b>{html.escape(main_name)}</b></p>
<nav><a href="#ozet">Özet</a><a href="#asamalar">Tüm aşamalar</a><a href="#ayrinti">Aşama ayrıntıları</a>
<a href="#testlerin">Kendi testlerin</a><a href="#rapor">Tam rapor</a></nav>
{live}
<h2 id="ozet">Özet — {stage}</h2>
<div class="kpi"><div>Çakılma (resmi test)<b>{m['n_crash']}/{m['n_episodes']}</b></div>
<div>200 altı bölüm<b>{below(m)}/{m['n_episodes']}</b></div><div>Ortalama puan<b>{m['mean']:.1f}</b></div>
<div>En kötü bölüm<b>{m['worst']:.0f}</b></div></div>
{q290}
<div class=report>{md_to_html(summary_md, shift=1)}</div>
<h2 id="asamalar">Tüm aşamalar bir bakışta</h2>
{overview}
<h2 id="ayrinti">Aşama ayrıntıları (tıklayınca açılır)</h2>
{''.join(det)}
<h2 id="testlerin">Kendi testlerin (en yeni 6)</h2><div class="grid">{tests_html}</div>
<h2 id="rapor">Tam rapor (README'nin tamamı)</h2>
<details><summary>Açmak için tıkla: ne yapıldı, nasıl çalıştırılır, sınırlılıklar…</summary><div class=report>{md_to_html(readme, shift=1)}</div></details>
<p class="muted">Ham veriler: Ubuntu'da <proje_klasörü>/runs/ · Bu sayfa: make_dashboard.py</p></body></html>"""
    (R / "SONUCLAR.html").write_text(page, encoding="utf-8")
    if DESKTOP.exists():
        shutil.copyfile(R / "SONUCLAR.html", DESKTOP / "SONUCLAR.html")
        shutil.copyfile(R / "README.md", DESKTOP / "README.md")
    print("SONUCLAR.html yazıldı")


if __name__ == "__main__":
    main()
