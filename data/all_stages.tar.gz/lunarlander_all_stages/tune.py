"""Optuna ile hiperparametre araması. Seçim ölçütü: DOĞRULAMA tohumlarında (5000-5019) deterministik politika.
TEST tohumlarına hiç dokunmaz. Optuna deneme koşuları 100+ tohumlarını kullanır (nihai eğitim tohumlarından ayrık).

Her algoritmaya EŞİT bütçe: aynı deneme sayısı (--trials). Deneme 0 her zaman zoo ayarıdır (kontrol).

Kullanım (4 paralel süreç, toplam 12 deneme = süreç başına 3):
  python3 tune.py --algo sac --trials 12 --trial-steps 100000 --workers 4
En iyi ayarı dışa aktar (configs/tuned_<algo>.json + runs/tune/<algo>/trials.csv):
  python3 tune.py --algo sac --export
"""
import os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import _deps  # noqa: F401,E402

import argparse  # noqa: E402
import json  # noqa: E402
import subprocess  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402
from pathlib import Path  # noqa: E402

import common  # noqa: E402
import configs  # noqa: E402

TUNE_DIR = common.RUNS / "tune"
NETS = {"64x64": [64, 64], "128x128": [128, 128], "256x256": [256, 256], "400x300": [400, 300]}

# Deneme 0: zoo ayarı (arama uzayı içinde, kontrol olarak kullanılır)
ZOO_PARAMS = {
    "sac": dict(lr=7.3e-4, net="400x300", batch=256, tau=0.01, gamma=0.99, utd=1.0, learning_starts=10_000),
    "td3": dict(lr=1e-3, net="400x300", batch=256, tau=0.005, gamma=0.98, noise_std=0.1, utd=1.0,
                learning_starts=10_000),
    "ppo": dict(lr=3e-4, net="64x64", n_steps=1024, batch=64, n_epochs=4, gae_lambda=0.98, gamma=0.999,
                ent_coef=0.01, clip_range=0.2),
}


def sample(trial, algo):
    s = trial.suggest_categorical
    f = trial.suggest_float
    if algo == "sac":
        return dict(lr=f("lr", 1e-4, 2e-3, log=True), net=s("net", ["128x128", "256x256", "400x300"]),
                    batch=s("batch", [128, 256]), tau=s("tau", [0.005, 0.01, 0.02]),
                    gamma=s("gamma", [0.98, 0.99, 0.995]), utd=s("utd", [0.5, 1.0]),
                    learning_starts=s("learning_starts", [2000, 5000, 10000]))
    if algo == "td3":
        return dict(lr=f("lr", 3e-4, 3e-3, log=True), net=s("net", ["128x128", "256x256", "400x300"]),
                    batch=s("batch", [128, 256]), tau=s("tau", [0.005, 0.01, 0.02]),
                    gamma=s("gamma", [0.98, 0.99, 0.995]), noise_std=s("noise_std", [0.1, 0.2, 0.3]),
                    utd=s("utd", [0.5, 1.0]), learning_starts=s("learning_starts", [2000, 5000, 10000]))
    if algo == "ppo":
        return dict(lr=f("lr", 1e-4, 1e-3, log=True), net=s("net", ["64x64", "128x128", "256x256"]),
                    n_steps=s("n_steps", [512, 1024, 2048]), batch=s("batch", [64, 128, 256, 512]),
                    n_epochs=s("n_epochs", [4, 8, 10]), gae_lambda=s("gae_lambda", [0.95, 0.98]),
                    gamma=s("gamma", [0.99, 0.999]), ent_coef=f("ent_coef", 1e-4, 3e-2, log=True),
                    clip_range=s("clip_range", [0.1, 0.2, 0.3]))
    raise ValueError(algo)


def params_to_cfg(algo, p):
    cfg = configs.get_config(algo)
    p = dict(p)
    cfg["net"] = NETS[p.pop("net")]
    utd = p.pop("utd", 1.0)
    if algo in ("sac", "td3"):
        cfg["train_freq"], cfg["gradient_steps"] = (2, 1) if utd == 0.5 else (1, 1)
    cfg.update(p)
    return cfg


def study_for(algo, trial_steps=100_000, sampler_seed=0):
    import optuna
    d = TUNE_DIR / algo
    d.mkdir(parents=True, exist_ok=True)
    # kalp atışı: süreç/VM ölürse yarım kalan deneme "başarısız" sayılır ve aynı parametrelerle yeniden kuyruğa alınır
    storage = optuna.storages.RDBStorage(
        f"sqlite:///{d / 'study.db'}", engine_kwargs={"connect_args": {"timeout": 120}},
        heartbeat_interval=60, grace_period=600,
        failed_trial_callback=optuna.storages.RetryFailedTrialCallback(max_retry=2))
    # DİKKAT: her işçi süreci KENDİ tohumuyla kurulmalı. (Aşama 2'nin ilk koşusunda hepsi seed=0 kullanmış, işçiler
    # aynı rastgele ayarları çekmiş; düzeltildi, bkz. results/asama2_optuna/OZET.md)
    sampler = optuna.samplers.TPESampler(seed=sampler_seed, n_startup_trials=4)
    # ısınma: deneme uzunluğunun %40'ı (PPO yavaş başlar; erken budanmasın)
    pruner = optuna.pruners.MedianPruner(n_startup_trials=4, n_warmup_steps=int(0.4 * trial_steps))
    return optuna.create_study(study_name=f"{algo}_tune", storage=storage, sampler=sampler, pruner=pruner,
                               direction="maximize", load_if_exists=True)


def make_objective(algo, trial_steps, eval_every):
    import optuna
    from stable_baselines3.common.callbacks import BaseCallback
    from stable_baselines3.common.env_util import make_vec_env
    from stable_baselines3.common.vec_env import DummyVecEnv

    class CB(BaseCallback):
        def __init__(self, trial, out_dir):
            super().__init__(0)
            self.trial, self.out_dir = trial, out_dir
            self.env = common.make_env()
            self.scores, self.next_eval, self.t0 = [], eval_every, time.time()

        def _prog(self, state):
            common.write_json_atomic(self.out_dir / "progress.json", dict(
                algo=algo, tag=f"tune/trial{self.trial.number}", seed=common.TUNE_SEED_START + self.trial.number,
                state=state, step=int(self.num_timesteps), total=int(trial_steps),
                sps=round(self.num_timesteps / max(time.time() - self.t0, 1), 1), elapsed_s=round(time.time() - self.t0),
                eta_s=None, last_val_mean=self.scores[-1] if self.scores else None,
                best_val_mean=max(self.scores) if self.scores else None, updated=common.now_iso(),
                updated_ts=time.time(), pid=os.getpid(), error=None))

        def _on_step(self):
            if self.num_timesteps >= self.next_eval:
                self.next_eval += eval_every
                rows = common.evaluate_episodes(common.policy_act_fn(self.model.policy),
                                                common.VAL_CURVE_SEEDS, env=self.env)
                m = common.summarize(rows)["mean"]
                self.scores.append(round(m, 2))
                common.append_csv(self.out_dir / "val_curve.csv", dict(step=int(self.num_timesteps), val_mean=round(m, 3)))
                self.trial.report(m, int(self.num_timesteps))
                self._prog("running")
                if self.trial.should_prune():
                    self._prog("pruned")
                    raise optuna.TrialPruned()
            return True

    def objective(trial):
        params = sample(trial, algo)
        cfg = params_to_cfg(algo, params)
        cfg["steps"] = trial_steps
        seed = common.TUNE_SEED_START + trial.number
        out_dir = TUNE_DIR / algo / f"trial{trial.number}"
        out_dir.mkdir(parents=True, exist_ok=True)
        common.write_json_atomic(out_dir / "config.json", dict(algo=algo, trial=trial.number, seed=seed, params=params,
                                                               cfg=cfg))
        env = make_vec_env(common.make_env, n_envs=configs.n_envs_for(algo, cfg), seed=seed, vec_env_cls=DummyVecEnv)
        model = configs.build_model(algo, cfg, env, seed)
        cb = CB(trial, out_dir)
        model.learn(total_timesteps=trial_steps, callback=cb)
        cb._prog("done")
        tail = cb.scores[-3:]
        value = sum(tail) / len(tail)  # son 3 değerlendirmenin ortalaması (gürültüyü azaltır)
        trial.set_user_attr("val_scores", cb.scores)
        trial.set_user_attr("seed", seed)
        return value

    return objective


def export(algo):
    study = study_for(algo)
    df = study.trials_dataframe()
    d = TUNE_DIR / algo
    df.to_csv(d / "trials.csv", index=False)
    done = [t for t in study.trials if t.state.name == "COMPLETE"]
    if not done:
        sys.exit("tamamlanmış deneme yok")
    best = max(done, key=lambda t: t.value)
    cfg = params_to_cfg(algo, best.params)
    cfg.pop("steps", None)
    out = common.ROOT / "configs" / f"tuned_{algo}.json"
    out.parent.mkdir(exist_ok=True)
    common.write_json_atomic(out, cfg)
    zoo = [t for t in study.trials if t.number == 0]
    print(f"[{algo}] {len(study.trials)} deneme ({len(done)} tamam, "
          f"{sum(t.state.name == 'PRUNED' for t in study.trials)} budandı)")
    if zoo and zoo[0].value is not None:
        print(f"  zoo ayarı (deneme 0) doğrulama değeri: {zoo[0].value:.1f}")
    print(f"  en iyi deneme #{best.number}: {best.value:.1f}  params={best.params}")
    print(f"  yazıldı: {out}")


def worker(algo, n_trials, trial_steps, eval_every, sampler_seed):
    study = study_for(algo, trial_steps, sampler_seed)
    if not study.trials:  # deneme 0 = zoo ayarı
        study.enqueue_trial(ZOO_PARAMS[algo], skip_if_exists=True)
    study.optimize(make_objective(algo, trial_steps, eval_every), n_trials=n_trials, gc_after_trial=True)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--algo", choices=["sac", "td3", "ppo"], required=True)
    p.add_argument("--trials", type=int, default=12, help="TOPLAM deneme sayısı (workers'a bölünebilmeli)")
    p.add_argument("--trial-steps", type=int, default=100_000)
    p.add_argument("--eval-every", type=int, default=None)
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--worker", action="store_true", help="(iç kullanım) tek işçi")
    p.add_argument("--per-worker", type=int, default=None, help="(iç kullanım)")
    p.add_argument("--sampler-seed", type=int, default=0, help="(iç kullanım) işçiye özgü örnekleyici tohumu")
    p.add_argument("--export", action="store_true")
    a = p.parse_args()

    if a.export:
        return export(a.algo)
    eval_every = a.eval_every or (25_000 if a.algo == "ppo" else 10_000)
    if a.worker:
        return worker(a.algo, a.per_worker, a.trial_steps, eval_every, a.sampler_seed)

    if a.trials % a.workers:
        sys.exit("--trials, --workers'a tam bölünmeli (her işçiye eşit deneme)")
    s = study_for(a.algo, a.trial_steps)  # veritabanını önce tek süreçte oluştur
    if not s.trials:
        s.enqueue_trial(ZOO_PARAMS[a.algo], skip_if_exists=True)
    procs = []
    for k in range(a.workers):
        cmd = ["nice", "-n", "10", sys.executable, str(common.ROOT / "tune.py"), "--algo", a.algo, "--worker",
               "--per-worker", str(a.trials // a.workers), "--trial-steps", str(a.trial_steps),
               "--eval-every", str(eval_every), "--sampler-seed", str(k + 1)]
        log = open(common.ROOT / "logs" / f"tune_{a.algo}_w{k}.log", "a", encoding="utf-8")
        procs.append(subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, cwd=str(common.ROOT)))
        time.sleep(3)  # SQLite'a aynı anda yüklenmesinler
    for pr in procs:
        pr.wait()
    export(a.algo)


if __name__ == "__main__":
    (common.ROOT / "logs").mkdir(exist_ok=True)
    main()
