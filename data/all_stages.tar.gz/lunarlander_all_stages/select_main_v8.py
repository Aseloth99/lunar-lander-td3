"""Aşama 10 seçimi: results/secim_kurali_v8.md (eğitimden önce kayıt). YALNIZCA bağımsız doğrulama 90000-91999 (val9, 2000/tohum).
  Kural 1 (Aşama 10 seçimi): 4 frenli SAC adayı arasında uygun olanlardan en az çakılma, en az 200 altı, en yüksek ortalama.
  Kural 2 (genel kural seçimi): bütün 11 aday arasında aynı sıralama (Aşama 8-9 ile aynı).
  Uygunluk: her tohumda ortalama >= 280.
Çıktı: results/ana_sonuc_secimi_v8.json ("main" = kural 2; "stage10_pick" = kural 1)"""
import _deps  # noqa: F401

import json

import common

NEW = ["sac/v10brake@800k", "sac/v10brake@1600k", "sac/v10soft@800k", "sac/v10soft@1600k"]
REFS = ["td3/v4big@1600k", "td3/v6brake@1600k", "td3/v6soft@800k", "sac/v9lowent@800k", "sac/v9lowent@1600k",
        "sac/v9big@800k", "sac/v9big@1600k"]


def load(c):
    g, suf = c.split("@")
    runs = []
    for d in sorted((common.RUNS / g).glob("seed*")):
        f = d / f"val9_best_{suf}_summary.json"
        if f.exists():
            s = json.load(open(f, encoding="utf-8"))
            runs.append(dict(seed=s["seed"], crashes=int(round(s["crash"] * s["n"])), below200=int(round((1 - s["success"]) * s["n"])),
                             mean=s["mean"], n=s["n"]))
    if len(runs) < 5:
        return None
    return dict(group=c, eligible=all(r["mean"] >= 280.0 for r in runs), crashes=sum(r["crashes"] for r in runs),
                below200=sum(r["below200"] for r in runs), n=sum(r["n"] for r in runs),
                mean=sum(r["mean"] for r in runs) / len(runs), runs=runs,
                best_seed=max(runs, key=lambda r: (r["crashes"] == 0, r["mean"]))["seed"])


def safety_first(r):
    return (0 if r["eligible"] else 1, r["crashes"], r["below200"], -r["mean"])


def main():
    rows = {c: load(c) for c in NEW + REFS}
    missing = [c for c, r in rows.items() if r is None]
    if missing:
        raise SystemExit(f"eksik doğrulama: {missing}")
    new = sorted((rows[c] for c in NEW), key=safety_first)
    allr = sorted(rows.values(), key=safety_first)
    for r in allr:
        print(f"{r['group']:20s} uygun={'EVET' if r['eligible'] else 'hayır'} | çakılma {r['crashes']}/{r['n']} | "
              f"200 altı {r['below200']}/{r['n']} | ort {r['mean']:.2f} | tohum ort. {[round(x['mean'], 1) for x in r['runs']]}")
    out = dict(rule="results/secim_kurali_v8.md (kural 1: frenli SAC'ların en iyisi; kural 2: genel, güvenlik önce)",
               data="bağımsız doğrulama 90000-91999 (2000 bölüm/tohum)", decided=common.now_iso(),
               stage10_pick=new[0]["group"], stage10_ranking=[r["group"] for r in new],
               main=allr[0]["group"], main_video_seed=allr[0]["best_seed"], ranking=[r["group"] for r in allr],
               table=list(rows.values()))
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi_v8.json", out)
    print("AŞAMA 10 SEÇİMİ (kural 1):", out["stage10_pick"], "| GENEL KURAL SEÇİMİ (kural 2):", out["main"])


if __name__ == "__main__":
    main()
