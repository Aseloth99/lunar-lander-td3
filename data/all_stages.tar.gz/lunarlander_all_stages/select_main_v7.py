"""Aşama 9 seçimi: results/secim_kurali_v7.md (eğitimden önce kayıt). YALNIZCA bağımsız doğrulama 70000-71999 (val8, 2000/tohum).
  Kural 1 (SAC şampiyonu): SAC adayları arasında her tohumda ortalama >= 280 olanlardan en yüksek ortalama.
  Kural 2 (kural seçimi, güvenlik önce): bütün adaylar arasında uygunluk = her tohumda ortalama >= 280; sonra en az çakılma,
          en az 200 altı, en yüksek ortalama (Aşama 8 ile aynı).
Çıktı: results/ana_sonuc_secimi_v7.json ("main" = kural 2; "sac_champion" = kural 1)"""
import _deps  # noqa: F401

import json

import common

SAC = ["sac/v9big@800k", "sac/v9big@1600k", "sac/v9lowent@800k", "sac/v9lowent@1600k"]
REFS = ["td3/v4big@1600k", "td3/v6brake@1600k", "sac/v4@1600k"]


def load(c):
    g, suf = c.split("@")
    runs = []
    for d in sorted((common.RUNS / g).glob("seed*")):
        f = d / f"val8_best_{suf}_summary.json"
        if f.exists():
            s = json.load(open(f, encoding="utf-8"))
            runs.append(dict(seed=s["seed"], crashes=int(round(s["crash"] * s["n"])), below200=int(round((1 - s["success"]) * s["n"])),
                             mean=s["mean"], n=s["n"]))
    if len(runs) < 5:
        return None
    return dict(group=c, eligible=all(r["mean"] >= 280.0 for r in runs), crashes=sum(r["crashes"] for r in runs),
                below200=sum(r["below200"] for r in runs), n=sum(r["n"] for r in runs),
                mean=sum(r["mean"] for r in runs) / len(runs), runs=runs,
                best_seed=max(runs, key=lambda r: (r["crashes"] == 0, r["mean"]))["seed"])


def main():
    rows = {c: load(c) for c in SAC + REFS}
    missing = [c for c, r in rows.items() if r is None]
    if missing:
        raise SystemExit(f"eksik doğrulama: {missing}")
    sac = sorted((rows[c] for c in SAC), key=lambda r: (0 if r["eligible"] else 1, -r["mean"]))
    allr = sorted(rows.values(), key=lambda r: (0 if r["eligible"] else 1, r["crashes"], r["below200"], -r["mean"]))
    for r in allr:
        print(f"{r['group']:20s} uygun={'EVET' if r['eligible'] else 'hayır'} | çakılma {r['crashes']}/{r['n']} | "
              f"200 altı {r['below200']}/{r['n']} | ort {r['mean']:.2f} | tohum ort. {[round(x['mean'], 1) for x in r['runs']]}")
    out = dict(rule="results/secim_kurali_v7.md (kural 1: SAC şampiyonu = en yüksek ortalama; kural 2: güvenlik önce)",
               data="bağımsız doğrulama 70000-71999 (2000 bölüm/tohum)", decided=common.now_iso(),
               sac_champion=sac[0]["group"], sac_ranking=[r["group"] for r in sac],
               main=allr[0]["group"], main_video_seed=allr[0]["best_seed"], ranking=[r["group"] for r in allr],
               table=list(rows.values()))
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi_v7.json", out)
    print("SAC ŞAMPİYONU:", out["sac_champion"], "| KURAL SEÇİMİ (güvenlik önce):", out["main"])


if __name__ == "__main__":
    main()
