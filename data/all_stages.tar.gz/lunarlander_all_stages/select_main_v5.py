"""Ana sonuç v5: results/secim_kurali_v5.md (eğitimden önce kayıt). YALNIZCA bağımsız doğrulama 6800-7199 (val6).
Kural v4 + EK ile aynı: her tohumda 0 çakılma VE başarı %100 -> uygunlar arasında en yüksek ortalama.
Çıktı: results/ana_sonuc_secimi_v5.json"""
import _deps  # noqa: F401

import json

import common

CANDIDATES = ["td3/v4big@800k", "td3/v4big@1600k", "td3/v5big@800k", "td3/v5big@1600k"]


def main():
    rows = []
    for c in CANDIDATES:
        g, suf = c.split("@")
        runs = []
        for d in sorted((common.RUNS / g).glob("seed*")):
            f = d / f"val6_best_{suf}_summary.json"
            if (d / "DONE").exists() and f.exists():
                s = json.load(open(f, encoding="utf-8"))
                runs.append(dict(seed=s["seed"], crashes=int(round(s["crash"] * s["n"])), success=s["success"],
                                 below200=int(round((1 - s["success"]) * s["n"])), mean=s["mean"]))
        if len(runs) < 5:
            print(f"[aday değil] {c}: {len(runs)} tohum")
            continue
        eligible = all(r["crashes"] == 0 and r["below200"] == 0 for r in runs)
        rows.append(dict(group=c, eligible=eligible, crashes=sum(r["crashes"] for r in runs),
                         below200=sum(r["below200"] for r in runs),
                         mean=sum(r["mean"] for r in runs) / len(runs), runs=runs,
                         best_seed=max(runs, key=lambda r: (r["crashes"] == 0, r["mean"]))["seed"]))
    # uygunlar önce, kendi içlerinde ortalamaya göre; uygun olmayanlar sonra, az çakılma, az 200 altı, yüksek ortalama
    rows.sort(key=lambda r: (0, 0, 0, -r["mean"]) if r["eligible"] else (1, r["crashes"], r["below200"], -r["mean"]))
    for r in rows:
        print(f"{r['group']:18s} uygun={'EVET' if r['eligible'] else 'hayır'} | çakılma {r['crashes']}/2000 | "
              f"200 altı {r['below200']}/2000 | "
              f"ort {r['mean']:.1f} | tohum ort. {[round(x['mean'], 1) for x in r['runs']]}")
    out = dict(rule="results/secim_kurali_v5.md (başarı %100 + 0 çakılma, sonra ortalama; eğitimden önce kayıt)",
               data="bağımsız doğrulama 6800-7199 (400 bölüm/tohum)",
               decided=common.now_iso(), ranking=[r["group"] for r in rows], main=rows[0]["group"],
               main_video_seed=rows[0]["best_seed"], table=rows)
    common.write_json_atomic(common.ROOT / "results" / "ana_sonuc_secimi_v5.json", out)
    print("ANA SONUÇ (v5):", rows[0]["group"], "| video tohumu:", rows[0]["best_seed"])


if __name__ == "__main__":
    main()
