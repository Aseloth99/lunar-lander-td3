# Seçim kuralı v7 (Aşama 9: "SAC daha iyi skor çıkartamaz mı?") — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-26, Aşama 9 eğitimleri BAŞLAMADAN önce. Bu anda `runs/sac/v9big` ve `runs/sac/v9lowent` yoktu;
70000–71999 doğrulaması ve 80000–81999 test bölümleri hiçbir ajan için çalıştırılmamıştı (`FROZEN7` yok). Bu dosya
sonradan değiştirilmeyecek.

**Bağlam:** SAC şimdiye kadar hep küçük ağ ([256,256]) ve γ 0,99 ile eğitildi. Aşama 6'da SAC 1,6M çok güvenliydi
(5000 test bölümünde 0 çakılma) ama puanı TD3'ün altındaydı (≈284). TD3'ü iyileştiren büyük ağ ve γ 0,995 SAC'ta hiç
denenmedi. Hipotez (kanıtlanmadı): SAC'ın düşük puanı kısmen eğitimdeki entropi (rastgelelik) teşvikinden geliyor;
deterministik değerlendirmede bu, yakıt israfı olarak görünüyor.

**Yeni çeşitler** (ikisi de: SAC, ağ [400,300], γ 0,995, lr 3e-4 sabit, tampon 1e6, batch 256, τ 0,01,
güncelleme/veri oranı 0,5, 1,6M adım, orijinal ödül, eğitim tohumları 0–4):
- `sac/v9big`: entropi hedefi otomatik (−2) (`configs/sac_v9big.json`)
- `sac/v9lowent`: entropi hedefi −4 (`configs/sac_v9lowent.json`)

**Kontrol noktası seçimi:** `reselect.py`, yalnızca 5100–5599 doğrulama bölümleriyle; 800k için 400k–800k, 1600k için
800k–1,6M aralığı (önceki aşamalarla aynı).

**Adaylar:** SAC: `sac/v9big@800k`, `sac/v9big@1600k`, `sac/v9lowent@800k`, `sac/v9lowent@1600k`.
Karşılaştırma (aynı yeni test, modelleri değişmeden): `td3/v4big@1600k` (en yüksek puanlı TD3), `td3/v6brake@1600k`
(en güvenli TD3), `sac/v4@1600k` (önceki SAC).

**Sıralama verisi:** yeni bağımsız doğrulama 70000–71999 (tohum başına 2000 bölüm). Kontrol noktası seçiminde kullanılmaz.

**Kurallar:**
1. **SAC şampiyonu (puan sorusu):** SAC adayları arasında, 5 tohumun her birinde doğrulama ortalaması ≥ 280 olanlardan
   tohum ortalamalarının ortalaması en yüksek olan. Hiçbiri uygun değilse en yüksek ortalamalı SAC adayı.
2. **Aşama 9 kural seçimi (güvenlik önce, Aşama 8 ile aynı kural):** BÜTÜN adaylar (SAC + karşılaştırma) arasında
   uygunluk = her tohumda ortalama ≥ 280; sonra en az çakılma, eşitlikte en az 200 altı, eşitlikte en yüksek ortalama.

**Test:** Seçimden sonra `FROZEN7` oluşturulur; bütün adayların bütün koşuları 80000–80099 (resmi, 100 bölüm) +
80100–81999 (ek, 1900 bölüm) test bölümlerinde bir kez ölçülür (tohum başına 2000, grup başına 10 000); hepsi raporlanır.

**Önceden tanımlı sorular (cevaplar olduğu gibi yazılır):**
- **"SAC, TD3'ü puanda geçti mi?"** SAC şampiyonunun genişletilmiş testteki (10 000 bölüm) ortalaması,
  `td3/v4big@1600k`'nın aynı bölümlerdeki ortalamasından yüksekse EVET; değilse HAYIR ve fark yazılır.
- **"Büyük ağ SAC'ı iyileştirdi mi?"** SAC şampiyonu, `sac/v4@1600k`'dan aynı bölümlerde yüksekse EVET.
- **"Düşük entropi işe yaradı mı?"** Aynı uzunlukta (`@1600k`) `sac/v9lowent`, `sac/v9big`'den aynı bölümlerde
  yüksekse EVET.
- Ek (tanı): çakılma sayıları, yakıt ve iniş süresi.
