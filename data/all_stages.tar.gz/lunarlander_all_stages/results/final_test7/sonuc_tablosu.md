### Sonuçlar — EN YENİ TEST 80000–80099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 291.7 ± 0.3 | 293.9 | 100.0% | 0.0% (0/500) | 5/5 | 246.5 | 5/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 290.6 ± 1.3 | 293.0 | 99.8% | 0.0% (0/500) | 5/5 | 181.7 | 5/5 |
| SAC uzun · 1,6 milyon | orijinal | 5 | 285.8 ± 1.3 | 287.9 | 100.0% | 0.0% (0/500) | 5/5 | 240.8 | 5/5 |
| SAC büyük ağ · 800 bin | orijinal | 5 | 230.3 ± 148.3 | 276.6 | 80.0% | 0.0% (0/500) | 5/5 | -36.4 | 4/5 |
| SAC büyük ağ · 1,6 milyon | orijinal | 5 | 286.4 ± 3.6 | 288.5 | 100.0% | 0.0% (0/500) | 5/5 | 242.0 | 5/5 |
| SAC büyük ağ, düşük entropi · 800 bin | orijinal | 5 | 280.4 ± 7.4 | 282.9 | 100.0% | 0.0% (0/500) | 5/5 | 227.4 | 2/5 |
| SAC büyük ağ, düşük entropi · 1,6 milyon | orijinal | 5 | 287.3 ± 2.1 | 289.6 | 100.0% | 0.0% (0/500) | 5/5 | 242.0 | 5/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
