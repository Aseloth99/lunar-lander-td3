| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 1,6 milyon | 0 | 291.8 | 100% | 0% | 246.6 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 292.0 | 100% | 0% | 246.5 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 291.6 | 100% | 0% | 248.9 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 291.4 | 100% | 0% | 251.4 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 4 | 291.9 | 100% | 0% | 248.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.0 | 99% | 0% | 181.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 291.5 | 100% | 0% | 248.5 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 290.7 | 100% | 0% | 248.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 290.5 | 100% | 0% | 249.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 291.5 | 100% | 0% | 248.1 | ✔ |
| SAC uzun · 1,6 milyon | 0 | 284.2 | 100% | 0% | 242.3 | ✔ |
| SAC uzun · 1,6 milyon | 1 | 285.8 | 100% | 0% | 246.1 | ✔ |
| SAC uzun · 1,6 milyon | 2 | 287.0 | 100% | 0% | 240.8 | ✔ |
| SAC uzun · 1,6 milyon | 3 | 286.0 | 100% | 0% | 245.4 | ✔ |
| SAC uzun · 1,6 milyon | 4 | 285.8 | 100% | 0% | 242.2 | ✔ |
| SAC büyük ağ · 800 bin | 0 | 286.3 | 100% | 0% | 239.7 | ✔ |
| SAC büyük ağ · 800 bin | 1 | 283.0 | 100% | 0% | 235.1 | ✔ |
| SAC büyük ağ · 800 bin | 2 | 281.2 | 100% | 0% | 238.4 | ✔ |
| SAC büyük ağ · 800 bin | 3 | 16.7 | 0% | 0% | -36.4 | ✘ |
| SAC büyük ağ · 800 bin | 4 | 284.1 | 100% | 0% | 243.1 | ✔ |
| SAC büyük ağ · 1,6 milyon | 0 | 287.0 | 100% | 0% | 248.8 | ✔ |
| SAC büyük ağ · 1,6 milyon | 1 | 289.3 | 100% | 0% | 247.9 | ✔ |
| SAC büyük ağ · 1,6 milyon | 2 | 285.9 | 100% | 0% | 244.0 | ✔ |
| SAC büyük ağ · 1,6 milyon | 3 | 281.8 | 100% | 0% | 242.0 | ✔ |
| SAC büyük ağ · 1,6 milyon | 4 | 288.1 | 100% | 0% | 244.9 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 0 | 287.8 | 100% | 0% | 247.0 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 1 | 279.2 | 100% | 0% | 227.4 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 2 | 278.4 | 100% | 0% | 241.3 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 3 | 272.2 | 100% | 0% | 230.3 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 4 | 284.6 | 100% | 0% | 242.9 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 0 | 287.7 | 100% | 0% | 244.9 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 1 | 285.5 | 100% | 0% | 242.0 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 2 | 288.9 | 100% | 0% | 247.8 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 3 | 285.4 | 100% | 0% | 243.1 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 4 | 288.9 | 100% | 0% | 244.9 | ✔ |
