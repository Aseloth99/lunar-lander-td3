### Sonuçlar — BAĞIMSIZ DOĞRULAMA v7: 70000–71999 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.5 ± 0.3 | 291.4 | 100.0% | 0.0% (2/10000) | 4/5 | 60.5 | 4/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 289.6 ± 0.6 | 290.6 | 100.0% | 0.0% (2/10000) | 3/5 | 32.8 | 3/5 |
| SAC uzun · 1,6 milyon | orijinal | 5 | 284.4 ± 1.1 | 285.6 | 100.0% | 0.0% (2/10000) | 4/5 | 45.6 | 4/5 |
| SAC büyük ağ · 800 bin | orijinal | 5 | 228.8 ± 148.5 | 275.2 | 80.0% | 0.1% (7/10000) | 3/5 | -131.8 | 3/5 |
| SAC büyük ağ · 1,6 milyon | orijinal | 5 | 285.2 ± 3.3 | 286.1 | 100.0% | 0.0% (1/10000) | 4/5 | 69.2 | 4/5 |
| SAC büyük ağ, düşük entropi · 800 bin | orijinal | 5 | 279.1 ± 7.6 | 280.6 | 99.9% | 0.0% (4/10000) | 3/5 | -90.1 | 2/5 |
| SAC büyük ağ, düşük entropi · 1,6 milyon | orijinal | 5 | 285.7 ± 2.3 | 286.7 | 99.9% | 0.0% (3/10000) | 3/5 | 25.5 | 3/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
