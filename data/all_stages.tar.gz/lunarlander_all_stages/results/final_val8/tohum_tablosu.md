| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 1,6 milyon | 0 | 290.6 | 100% | 0% | 242.1 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 290.8 | 100% | 0% | 239.4 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.4 | 100% | 0% | 241.1 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.1 | 100% | 0% | 240.4 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 4 | 290.4 | 100% | 0% | 60.5 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 288.9 | 100% | 0% | 173.0 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.1 | 100% | 0% | 237.9 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 289.5 | 100% | 0% | 66.6 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.4 | 100% | 0% | 32.8 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.0 | 100% | 0% | 161.5 | ✔ |
| SAC uzun · 1,6 milyon | 0 | 282.8 | 100% | 0% | 235.8 | ✔ |
| SAC uzun · 1,6 milyon | 1 | 284.8 | 100% | 0% | 238.6 | ✔ |
| SAC uzun · 1,6 milyon | 2 | 284.8 | 100% | 0% | 45.6 | ✘ |
| SAC uzun · 1,6 milyon | 3 | 284.9 | 100% | 0% | 228.3 | ✔ |
| SAC uzun · 1,6 milyon | 4 | 284.8 | 100% | 0% | 235.4 | ✔ |
| SAC büyük ağ · 800 bin | 0 | 285.5 | 100% | 0% | 235.3 | ✔ |
| SAC büyük ağ · 800 bin | 1 | 281.0 | 100% | 0% | 222.0 | ✔ |
| SAC büyük ağ · 800 bin | 2 | 279.4 | 100% | 0% | -131.8 | ✘ |
| SAC büyük ağ · 800 bin | 3 | 14.9 | 0% | 0% | -65.9 | ✘ |
| SAC büyük ağ · 800 bin | 4 | 283.2 | 100% | 0% | 195.1 | ✔ |
| SAC büyük ağ · 1,6 milyon | 0 | 285.9 | 100% | 0% | 237.9 | ✔ |
| SAC büyük ağ · 1,6 milyon | 1 | 287.8 | 100% | 0% | 237.9 | ✔ |
| SAC büyük ağ · 1,6 milyon | 2 | 284.7 | 100% | 0% | 232.5 | ✔ |
| SAC büyük ağ · 1,6 milyon | 3 | 280.8 | 100% | 0% | 230.1 | ✔ |
| SAC büyük ağ · 1,6 milyon | 4 | 286.6 | 100% | 0% | 69.2 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 0 | 286.5 | 100% | 0% | 237.0 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 1 | 278.0 | 100% | 0% | -90.1 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 2 | 277.2 | 100% | 0% | 42.1 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 3 | 270.6 | 100% | 0% | 0.8 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 4 | 283.4 | 100% | 0% | 113.3 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 0 | 286.4 | 100% | 0% | 81.3 | ✘ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 1 | 283.6 | 100% | 0% | 165.5 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 2 | 287.1 | 100% | 0% | 25.5 | ✘ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 3 | 283.9 | 100% | 0% | 234.1 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 4 | 287.6 | 100% | 0% | 238.1 | ✔ |
