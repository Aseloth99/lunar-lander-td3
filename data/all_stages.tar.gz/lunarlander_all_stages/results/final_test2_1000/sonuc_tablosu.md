### Sonuçlar — YENİ TEST 20000–20999 (resmi 100 + ek 900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v2b (ana sonuç) | orijinal | 5 | 281.8 ± 3.5 | 282.2 | 99.9% | 0.0% (2/5000) | 4/5 | 71.6 | 2/5 |
| TD3 v2a | orijinal | 5 | 273.5 ± 7.0 | 274.2 | 99.9% | 0.0% (2/5000) | 4/5 | 37.4 | 0/5 |
| PPO (Optuna) | orijinal | 5 | 276.7 ± 6.0 | 277.4 | 99.7% | 0.2% (12/5000) | 2/5 | 18.6 | 0/5 |
| SAC + yakıt cezası† | yakıt cezası 2× | 5 | 274.3 ± 7.9 | 276.8 | 99.2% | 0.6% (32/5000) | 0/5 | -253.8 | 0/5 |
| TD3 (Optuna) | orijinal | 5 | 199.7 ± 191.6 | 260.4 | 79.7% | 0.0% (2/5000) | 4/5 | -131.4 | 1/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
