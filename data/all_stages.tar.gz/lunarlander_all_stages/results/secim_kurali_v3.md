# Ana sonuç seçim kuralı v3 (290 denemesi) — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-17, Aşama 5 eğitimleri yeni başlamışken. Bu anda hiçbir v3 doğrulama sonucu, 6000–6399
bağımsız doğrulaması veya 30000+ test sonucu yoktu. Bu dosya sonradan değiştirilmeyecek.

**Bağlam:** Mevcut şampiyon `td3/v2b` (yeni test 20000–20099: 0/500 çakılma, ort. 283.1). Kullanıcı ortalamayı 290'a
yaklaştırmayı istedi; çakılma %0 şartı korunur. 20000–20999 kullanıldı; yeni iddialar 30000+ test tohumlarına dayanır.

**Adaylar:** `td3/v2b` (mevcut şampiyon), `td3/v3long`, `td3/v3big`, `td3/v3fuel`† (5'er tohum; † eğitim ödülü
değişti, değerlendirme orijinal). Her koşunun kontrol noktası `reselect.py` ile (5100–5599) seçilir.

**Sıralama verisi:** yeni bağımsız doğrulama 6000–6399 (tohum başına 400 bölüm; seçimde kullanılmaz).

**Kural:**
1. **Uygunluk (güvenlik önce):** 5 tohumun hepsinde 0 çakılma VE her tohumda başarı ≥ %99 olan gruplar uygundur.
2. Uygun gruplar arasında **tohum ortalamalarının ortalaması en yüksek** olan seçilir.
3. Hiçbir grup uygun değilse: toplam çakılma az olan, eşitlikte ortalama yüksek olan.

Yani yeni bir çeşit, şampiyonu ancak çakılmasız kalıp ortalamada geçerse yerinden eder. Seçimden sonra `FROZEN3`
oluşturulur ve 4 grubun tüm koşuları 30000–30099 (resmi) + 30100–30999 (ek) test bölümlerinde bir kez ölçülür.
