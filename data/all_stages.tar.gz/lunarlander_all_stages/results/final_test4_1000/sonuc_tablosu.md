### Sonuçlar — EN YENİ TEST 40000–40999 (resmi 100 + ek 900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v3 uzun (800k) | orijinal | 5 | 289.0 ± 1.8 | 290.4 | 99.8% | 0.1% (4/5000) | 4/5 | 26.3 | 4/5 |
| TD3 büyük ağ · 800 bin | orijinal | 5 | 289.9 ± 0.9 | 290.9 | 100.0% | 0.0% (0/5000) | 5/5 | 239.0 | 5/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 291.1 ± 0.3 | 292.3 | 99.9% | 0.1% (6/5000) | 2/5 | 29.4 | 2/5 |
| TD3 küçük ağ · 800 bin | orijinal | 5 | 289.4 ± 0.9 | 290.4 | 99.9% | 0.1% (3/5000) | 2/5 | 23.4 | 2/5 |
| TD3 küçük ağ · 1,6 milyon | orijinal | 5 | 290.6 ± 0.3 | 292.0 | 99.8% | 0.2% (8/5000) | 2/5 | 20.2 | 2/5 |
| SAC uzun · 800 bin | orijinal | 5 | 279.9 ± 6.6 | 280.5 | 100.0% | 0.0% (1/5000) | 4/5 | 48.0 | 4/5 |
| SAC uzun · 1,6 milyon | orijinal | 5 | 285.4 ± 1.1 | 286.5 | 100.0% | 0.0% (0/5000) | 5/5 | 177.2 | 5/5 |
| PPO (Optuna) | orijinal | 5 | 277.9 ± 5.6 | 279.2 | 99.8% | 0.2% (10/5000) | 1/5 | 33.1 | 0/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
