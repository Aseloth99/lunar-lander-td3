# Aşama 2 — Optuna (doğrulama tohumlarıyla) + yakıt cezası pilotu

Tüm seçimler yalnızca doğrulama tohumlarıyla (5000–5019, deneme başına son 3 değerlendirmenin ortalaması) yapıldı;
test tohumlarına bakılmadı. Optuna denemeleri 100+ eğitim tohumlarını kullandı. Deneme tabloları: `*_denemeler.csv`.

## ⚠ Bilinen kusur (benim hatam, düzeltildi): işçiler aynı rastgele ayarları çekti

`tune.py` her paralel işçi sürecinde `TPESampler(seed=0)` kurmuştu. Dört işçi aynı rastgele ayarları üretti; bu yüzden
"12 deneme" aslında **PPO'da 8, TD3'te 7, SAC'ta 5 farklı ayar** denedi, gerisi aynı ayarın farklı eğitim tohumuyla
tekrarı oldu. Bütçe her algoritma için nominal olarak eşitti (12 deneme × aynı koşullar), ama etkin ayar çeşitliliği
eşit değil (8 / 7 / 5). Kod düzeltildi (işçi başına ayrı tohum); bu sonuçlar düzeltilmemiş koşudan.

Kusurun yan faydası: aynı ayarın farklı tohumlardaki tekrarları, ölçümün ne kadar gürültülü olduğunu gösterdi:

| Aynı ayar, farklı eğitim tohumu (10⁵ adımda doğrulama puanı) | Değerler |
|---|---|
| SAC [128,128], lr 5.2e-4 | −33, 80, 170 |
| SAC [400,300], lr 1.2e-3, utd 0.5 | −26, 118, 120 |
| TD3 [128,128], lr 1e-3 | 174, 183, −51 |
| TD3 [128,128], lr 2.9e-3 (en iyi bulunan) | −1\*, **256**, 41\* |
| PPO (seçilen ayar, 5×10⁵ adım) | 192, 259, 242, 248 |

(\* = medyan budayıcı tarafından erken budandı.) Tohumlar arası fark (yüzlerce puan), ayarlar arası farktan büyük:
SAC ve TD3 için 10⁵ adımlık denemeler ayar sıralamasını güvenilir şekilde ayıramıyor. TD3'ün "en iyi" ayarının 256'sı
muhtemelen şanslı bir tohumdan geliyor (aynı ayarın diğer iki tekrarı −1 ve 41).

## Sonuçlar

| Algoritma | Farklı ayar | Zoo ayarı (deneme 0) | En iyi deneme | Dışa aktarılan ayar |
|---|---:|---:|---:|---|
| PPO (5×10⁵ adım/deneme) | 8 | 179 | 259 (aynı ayarın 4 tekrarının ort. ≈ 235) | lr 3.5e-4, batch 128, 10 epoch, ent 0.0085 |
| TD3 (10⁵ adım/deneme) | 7 | −102\* | 256 (tekrar ort. ≈ 99, **şans payı büyük**) | lr 2.9e-3, [128,128], γ 0.995, gürültü 0.2, utd 0.5 |
| SAC (10⁵ adım/deneme) | 5 | **253 (en iyi)** | zoo ayarı | zoo ayarı değişmedi |

SAC için aramada zoo ayarını geçen bir ayar çıkmadı (yalnızca 5 farklı ayar denendi; bu "zoo en iyisidir" demek değil).

## Yakıt cezası pilotu (SAC, 1 tohum; **eğitim ödülü değiştirildi**; değerlendirme orijinal ödülle)

Eğitimde yakıt cezası 2 katına çıkarıldı (zoo SAC ayarı, tohum 0). Aynı tohumda zoo ile karşılaştırma
(100 doğrulama bölümü, seçilmiş kontrol noktası):

| | Zoo SAC (tohum 0) | Yakıt-cezalı SAC (tohum 0) |
|---|---:|---:|
| ortalama puan | 270.8 | **280.9** |
| başarı (≥200) / çakılma | %99 / %1 | **%100 / %0** |
| en kötü bölüm | 39 | 237 |
| yakıt cezası (gerçek ödülle) | 27.1 | 24.5 |
| bitiş potansiyeli (ideal ≈ +20) | 8.9 | 14.3 |
| bölüm uzunluğu | 210 adım | 181 adım |
| ≥ 280 olan bölümler | %40 | %55 |

Dikkat: (1) **tek tohum**; 5 tohumda tutacağı bilinmiyor. (2) 280.9, 3 aday kontrol noktası arasından seçilen en iyinin
100 bölümlük ölçümü, hafif iyimser olabilir; pilotun 20 bölümlük değerlendirmeleri 200k adımdan sonra ≈ 275–280 civarında
seyretti. (3) İyileşme beklenenden farklı yerden geliyor: gerçek yakıt yalnızca ~2.6 azaldı; kazancın büyük kısmı daha
isabetli ve daha hızlı iniş (bitiş potansiyeli +5.4, 29 adım daha kısa). Nedenini ölçmedim; yalnızca bu fark gözlendi.
