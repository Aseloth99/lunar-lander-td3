### Sonuçlar — BAĞIMSIZ DOĞRULAMA 5600–5999 (seçimde kullanılmadı; test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v2b (ana sonuç) | orijinal | 5 | 280.1 ± 3.3 | 280.6 | 100.0% | 0.0% (0/2000) | 5/5 | 232.1 | 3/5 |
| TD3 v2a | orijinal | 5 | 271.9 ± 7.1 | 272.6 | 100.0% | 0.0% (0/2000) | 5/5 | 213.6 | 0/5 |
| PPO (Optuna) | orijinal | 5 | 275.0 ± 5.8 | 275.9 | 99.9% | 0.1% (3/2000) | 3/5 | 56.3 | 0/5 |
| SAC + yakıt cezası† | yakıt cezası 2× | 5 | 273.5 ± 8.2 | 275.6 | 99.5% | 0.4% (8/2000) | 3/5 | -156.7 | 0/5 |
| TD3 (Optuna) | orijinal | 5 | 198.1 ± 191.7 | 259.1 | 79.7% | 0.1% (1/2000) | 4/5 | -127.2 | 0/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
