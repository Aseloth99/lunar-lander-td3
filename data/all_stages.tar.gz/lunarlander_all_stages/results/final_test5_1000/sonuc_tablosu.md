### Sonuçlar — EN YENİ TEST 50000–50999 (resmi 100 + ek 900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 800 bin | orijinal | 5 | 288.7 ± 0.9 | 289.6 | 100.0% | 0.0% (2/5000) | 3/5 | 54.9 | 3/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.1 ± 0.3 | 290.9 | 100.0% | 0.0% (2/5000) | 3/5 | 45.0 | 3/5 |
| TD3 büyük ağ + azalan öğr. hızı · 800 bin | orijinal | 5 | 287.4 ± 0.7 | 288.4 | 99.9% | 0.0% (2/5000) | 4/5 | 54.8 | 4/5 |
| TD3 büyük ağ + azalan öğr. hızı · 1,6 milyon | orijinal | 5 | 289.3 ± 0.3 | 290.2 | 100.0% | 0.0% (1/5000) | 4/5 | 47.9 | 4/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
