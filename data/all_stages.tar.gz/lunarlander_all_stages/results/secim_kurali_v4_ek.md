# Seçim kuralı v4 — EK (kullanıcı isteği, sonuçlardan ÖNCE)

Yazıldığı an: 2026-10-19 10:55. Bu anda Aşama 6'nın hiçbir kontrol noktası seçimi (800k/1600k), bağımsız doğrulama
(6400–6799) veya test (40000+) sonucu YOKTU (kontrol edildi: val5 dosyası 0, seçim dosyası 0, FROZEN4 yok).

Kullanıcı: "Başarı %99,8 olsun istemiyorum, minimum %100 istiyorum."

`secim_kurali_v4.md`'deki uygunluk şartı bu yüzden sıkılaştırıldı:

1. **Uygunluk:** 5 tohumun hepsinde, bağımsız doğrulamanın 400 bölümünün HEPSİNDE puan ≥ 200 (başarı **%100**) VE 0 çakılma.
2. Uygunlar arasında tohum ortalamalarının ortalaması en yüksek olan seçilir.
3. Hiçbiri uygun değilse: önce toplam çakılma az, sonra 200 altı bölüm sayısı az, sonra ortalama yüksek olan.

Geri kalan her şey (adaylar, kontrol noktası seçimi, veri kümeleri, test) `secim_kurali_v4.md`'deki gibidir.
Not: 2000 bölümde hiç 200 altı olmaması çok sıkı bir şarttır; hiçbir aday uygun çıkmayabilir. Bu durumda 3. madde uygulanır
ve raporda açıkça yazılır.
