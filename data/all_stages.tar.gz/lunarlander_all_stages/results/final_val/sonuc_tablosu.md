### Sonuçlar — DOĞRULAMA tohumları 5000–5099 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| SAC + yakıt cezası† | yakıt cezası 2× | 5 | 275.8 ± 6.0 | 277.3 | 99.6% | 0.2% (1/500) | 4/5 | 70.4 | 2/5 |
| SAC (zoo) | orijinal | 2 | 268.5 ± 28.9 | 269.0 | 99.5% | 0.5% (1/200) | 1/2 | 39.5 | 0/2 |
| PPO (Optuna) | orijinal | 5 | 274.8 ± 4.9 | 277.2 | 99.2% | 0.8% (4/500) | 2/5 | 16.9 | 0/5 |
| TD3 (Optuna) | orijinal | 5 | 213.5 ± 161.2 | 264.5 | 79.8% | 19.8% (99/500) | 4/5 | -341.5 | 0/5 |
| PPO (zoo) | orijinal | 5 | 262.0 ± 5.9 | 264.8 | 98.8% | 1.0% (5/500) | 2/5 | 10.9 | 0/5 |
| TD3 (zoo) | orijinal | 3 | 197.0 ± 193.5 | 232.1 | 70.0% | 7.0% (21/300) | 1/3 | -192.7 | 0/3 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
