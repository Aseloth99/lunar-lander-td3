### Sonuçlar — BAĞIMSIZ DOĞRULAMA v6: 7200–9199 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 800 bin | orijinal | 5 | 289.2 ± 0.9 | 290.0 | 100.0% | 0.0% (2/10000) | 4/5 | 62.7 | 4/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.6 ± 0.4 | 291.4 | 100.0% | 0.0% (4/10000) | 3/5 | 57.2 | 3/5 |
| TD3 erken fren (güçlü ceza)† · 800 bin | sert iniş cezası | 5 | 288.6 ± 1.4 | 289.5 | 99.9% | 0.0% (2/10000) | 3/5 | 58.4 | 3/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 289.8 ± 0.6 | 290.6 | 100.0% | 0.0% (0/10000) | 5/5 | 240.1 | 5/5 |
| TD3 erken fren (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 289.5 ± 0.6 | 290.3 | 100.0% | 0.0% (0/10000) | 5/5 | 240.2 | 5/5 |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | sert iniş cezası | 5 | 290.2 ± 0.7 | 291.1 | 99.9% | 0.0% (2/10000) | 4/5 | 47.7 | 4/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
