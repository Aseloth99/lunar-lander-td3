| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 800 bin | 0 | 288.7 | 100% | 0% | 203.5 | ✔ |
| TD3 büyük ağ · 800 bin | 1 | 288.9 | 100% | 0% | 240.1 | ✔ |
| TD3 büyük ağ · 800 bin | 2 | 290.4 | 100% | 0% | 240.5 | ✔ |
| TD3 büyük ağ · 800 bin | 3 | 288.8 | 100% | 0% | 239.3 | ✔ |
| TD3 büyük ağ · 800 bin | 4 | 289.1 | 100% | 0% | 62.7 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 0 | 290.8 | 100% | 0% | 244.2 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 291.0 | 100% | 0% | 242.0 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.6 | 100% | 0% | 243.9 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.2 | 100% | 0% | 77.5 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 4 | 290.4 | 100% | 0% | 57.2 | ✘ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 0 | 286.8 | 100% | 0% | 73.6 | ✘ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 1 | 289.9 | 100% | 0% | 58.4 | ✘ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 2 | 288.7 | 100% | 0% | 241.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 3 | 288.5 | 100% | 0% | 242.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 4 | 288.9 | 100% | 0% | 187.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.2 | 100% | 0% | 243.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.3 | 100% | 0% | 240.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 289.7 | 100% | 0% | 243.2 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.7 | 100% | 0% | 242.5 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.3 | 100% | 0% | 242.7 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 0 | 289.6 | 100% | 0% | 242.6 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 1 | 290.1 | 100% | 0% | 240.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 2 | 289.7 | 100% | 0% | 240.2 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 3 | 289.2 | 100% | 0% | 241.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 4 | 288.8 | 100% | 0% | 243.4 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 0 | 290.5 | 100% | 0% | 244.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 1 | 290.9 | 100% | 0% | 240.4 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 2 | 290.2 | 100% | 0% | 241.5 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 3 | 289.8 | 100% | 0% | 47.7 | ✘ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 4 | 289.5 | 100% | 0% | 180.9 | ✔ |
