| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 800 bin | 0 | 291.5 | 100% | 0% | 244.4 | ✔ |
| TD3 büyük ağ · 800 bin | 1 | 291.9 | 100% | 0% | 244.8 | ✔ |
| TD3 büyük ağ · 800 bin | 2 | 293.6 | 100% | 0% | 247.2 | ✔ |
| TD3 büyük ağ · 800 bin | 3 | 292.0 | 100% | 0% | 243.7 | ✔ |
| TD3 büyük ağ · 800 bin | 4 | 292.4 | 100% | 0% | 245.2 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 0 | 293.7 | 100% | 0% | 248.3 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 293.9 | 100% | 0% | 247.6 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 293.5 | 100% | 0% | 248.1 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 293.2 | 100% | 0% | 248.2 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 4 | 293.9 | 100% | 0% | 249.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 0 | 290.2 | 100% | 0% | 244.9 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 1 | 292.9 | 100% | 0% | 247.4 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 2 | 291.7 | 100% | 0% | 245.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 3 | 291.4 | 100% | 0% | 247.9 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 4 | 291.8 | 100% | 0% | 245.8 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 292.2 | 100% | 0% | 247.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 293.4 | 100% | 0% | 245.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 292.5 | 100% | 0% | 247.5 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 292.7 | 100% | 0% | 246.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 293.3 | 100% | 0% | 247.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 0 | 291.9 | 100% | 0% | 246.7 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 1 | 293.5 | 100% | 0% | 249.2 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 2 | 292.8 | 100% | 0% | 244.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 3 | 292.1 | 100% | 0% | 247.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 4 | 290.9 | 100% | 0% | 247.9 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 0 | 293.4 | 100% | 0% | 248.9 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 1 | 294.2 | 100% | 0% | 244.2 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 2 | 292.8 | 100% | 0% | 247.0 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 3 | 292.8 | 100% | 0% | 247.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 4 | 292.7 | 100% | 0% | 248.8 | ✔ |
