### Sonuçlar — EN YENİ TEST 60000–60099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 800 bin | orijinal | 5 | 292.3 ± 1.0 | 292.9 | 100.0% | 0.0% (0/500) | 5/5 | 243.7 | 5/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 293.6 ± 0.4 | 294.1 | 100.0% | 0.0% (0/500) | 5/5 | 247.6 | 5/5 |
| TD3 erken fren (güçlü ceza)† · 800 bin | sert iniş cezası | 5 | 291.6 ± 1.2 | 292.3 | 100.0% | 0.0% (0/500) | 5/5 | 244.9 | 5/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 292.8 ± 0.6 | 293.5 | 100.0% | 0.0% (0/500) | 5/5 | 245.3 | 5/5 |
| TD3 erken fren (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 292.2 ± 1.2 | 292.8 | 100.0% | 0.0% (0/500) | 5/5 | 244.8 | 5/5 |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | sert iniş cezası | 5 | 293.2 ± 0.8 | 293.7 | 100.0% | 0.0% (0/500) | 5/5 | 244.2 | 5/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
