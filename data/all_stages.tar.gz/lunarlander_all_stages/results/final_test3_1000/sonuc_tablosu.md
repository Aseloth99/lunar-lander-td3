### Sonuçlar — EN YENİ TEST 30000–30999 (resmi 100 + ek 900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v2b (ana sonuç) | orijinal | 5 | 281.9 ± 3.5 | 282.4 | 99.9% | 0.0% (2/5000) | 4/5 | 80.1 | 2/5 |
| TD3 v3 uzun (800k) | orijinal | 5 | 288.2 ± 1.8 | 289.1 | 99.9% | 0.0% (1/5000) | 4/5 | 84.9 | 4/5 |
| TD3 v3 büyük ağ | orijinal | 5 | 283.1 ± 3.9 | 284.2 | 99.9% | 0.1% (6/5000) | 1/5 | -278.1 | 1/5 |
| TD3 v3 + yakıt cezası† | yakıt cezası 2× | 5 | 282.4 ± 5.4 | 283.9 | 99.8% | 0.1% (5/5000) | 2/5 | -1234.9 | 1/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
