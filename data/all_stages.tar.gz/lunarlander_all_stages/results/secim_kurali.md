# Ana sonuç seçim kuralı — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-15 10:40 (Aşama 3 eğitimleri yeni başlamışken). O anda Aşama 3'ün hiçbir doğrulama
sonucu yoktu; test tohumlarına (10000–10099) hiç bakılmamıştı. Bu dosya sonradan değiştirilmeyecek.

**Adaylar** (5 tamamlanmış tohumu olan gruplar):
- `sac/fuel2x` — SAC, zoo ayarı + eğitimde yakıt cezası 2× (**eğitim ödülü değiştirildi**, değerlendirme orijinal ödül)
- `td3/tuned` — TD3, Aşama 2 Optuna ayarı
- `ppo/tuned` — PPO, Aşama 2 Optuna ayarı
- `ppo/zoo` — PPO, zoo ayarı

Referans satırları (aday değil, 5 tohum yok): `sac/zoo` (2 tohum), `td3/zoo` (3 tohum).

**Kural** (yalnızca DOĞRULAMA verisi: tohum başına 100 doğrulama bölümü, doğrulamayla seçilmiş kontrol noktası,
deterministik politika). Sırayla, eşitlikte bir sonrakine geçilir:
1. Tohum başına hedefi sağlayan tohum sayısı (ortalama ≥ 280 VE başarı ≥ %99 VE çakılma = 0) — çok olan önde.
2. Birleşik başarı oranı (puan ≥ 200) — yüksek olan önde.
3. Birleşik çakılma oranı — düşük olan önde.
4. Tohum ortalamalarının ortalaması — yüksek olan önde.

Seçilen grup "ana sonuç" olarak raporlanır ve videosu çekilir. Ardından `FROZEN` dosyası oluşturulur ve
TÜM grupların tüm koşuları test tohumlarında bir kez değerlendirilir; hepsi raporlanır (başarısızlar dahil).
Eğer kazanan `sac/fuel2x` olursa, raporda eğitim ödülünün değiştirildiği ve bunun ilk listede olmayan bir yöntem
olduğu (kullanıcı onayıyla eklendiği) açıkça yazılır; orijinal ödülle eğitilen en iyi aday da ayrıca belirtilir.
