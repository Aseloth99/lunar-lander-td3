| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 1,6 milyon | 0 | 290.6 | 100% | 0% | 60.5 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 1 | 291.0 | 100% | 0% | 33.1 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.7 | 100% | 0% | 241.6 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.2 | 100% | 0% | 41.7 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 4 | 290.7 | 100% | 0% | 58.5 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.1 | 100% | 0% | 185.4 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.3 | 100% | 0% | 240.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 289.8 | 100% | 0% | 240.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.7 | 100% | 0% | 239.4 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.4 | 100% | 0% | 241.1 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 0 | 289.5 | 100% | 0% | 241.7 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 1 | 290.3 | 100% | 0% | 240.5 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 2 | 289.8 | 100% | 0% | 240.3 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 3 | 289.1 | 100% | 0% | 238.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 4 | 288.8 | 100% | 0% | 242.3 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 0 | 286.7 | 100% | 0% | 238.0 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 1 | 278.7 | 100% | 0% | 169.3 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 2 | 278.0 | 100% | 0% | 231.4 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 3 | 270.9 | 100% | 0% | 170.7 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 4 | 283.4 | 100% | 0% | 66.3 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 0 | 286.8 | 100% | 0% | 213.8 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 1 | 284.0 | 100% | 0% | 231.0 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 2 | 287.7 | 100% | 0% | 240.5 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 3 | 284.2 | 100% | 0% | 233.4 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 4 | 287.8 | 100% | 0% | 237.8 | ✔ |
| SAC büyük ağ · 800 bin | 0 | 285.7 | 100% | 0% | 235.1 | ✔ |
| SAC büyük ağ · 800 bin | 1 | 281.5 | 100% | 0% | 223.6 | ✔ |
| SAC büyük ağ · 800 bin | 2 | 279.4 | 100% | 0% | -195.8 | ✘ |
| SAC büyük ağ · 800 bin | 3 | 15.0 | 0% | 0% | -72.2 | ✘ |
| SAC büyük ağ · 800 bin | 4 | 283.5 | 100% | 0% | 231.8 | ✔ |
| SAC büyük ağ · 1,6 milyon | 0 | 286.1 | 100% | 0% | 237.9 | ✔ |
| SAC büyük ağ · 1,6 milyon | 1 | 287.9 | 100% | 0% | 237.1 | ✔ |
| SAC büyük ağ · 1,6 milyon | 2 | 284.8 | 100% | 0% | 233.8 | ✔ |
| SAC büyük ağ · 1,6 milyon | 3 | 280.9 | 100% | 0% | 231.5 | ✔ |
| SAC büyük ağ · 1,6 milyon | 4 | 286.9 | 100% | 0% | 234.5 | ✔ |
| SAC frenli (güçlü ceza)† · 800 bin | 0 | 281.8 | 100% | 0% | 177.2 | ✔ |
| SAC frenli (güçlü ceza)† · 800 bin | 1 | 270.0 | 100% | 0% | 136.3 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 2 | 259.7 | 99% | 0% | 24.0 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 3 | 270.0 | 100% | 0% | 34.5 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 4 | 280.0 | 100% | 0% | 234.7 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 0 | 285.2 | 100% | 0% | 175.4 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 1 | 286.5 | 100% | 0% | 237.1 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 2 | 282.8 | 100% | 0% | 184.0 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 3 | 282.5 | 100% | 0% | 232.5 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 4 | 287.8 | 100% | 0% | 238.2 | ✔ |
| SAC frenli (hafif ceza)† · 800 bin | 0 | 278.8 | 99% | 0% | 23.3 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 1 | 276.6 | 100% | 0% | 116.4 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 2 | 276.8 | 100% | 0% | 44.9 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 3 | 274.7 | 100% | 0% | 212.5 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 4 | 282.2 | 100% | 0% | 232.6 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 0 | 288.3 | 100% | 0% | 236.8 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 1 | 282.9 | 100% | 0% | 233.0 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 2 | 281.9 | 100% | 0% | 234.2 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 3 | 284.7 | 100% | 0% | 237.7 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 4 | 288.2 | 100% | 0% | 167.7 | ✔ |
