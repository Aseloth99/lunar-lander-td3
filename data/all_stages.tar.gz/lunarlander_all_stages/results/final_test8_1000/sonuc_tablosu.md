### Sonuçlar — EN YENİ TEST 100000–101999 (resmi 100 + ek 1900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.6 ± 0.3 | 291.5 | 99.9% | 0.1% (5/10000) | 1/5 | 33.1 | 1/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 289.9 ± 0.6 | 290.7 | 100.0% | 0.0% (0/10000) | 5/5 | 185.4 | 5/5 |
| TD3 erken fren (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 289.5 ± 0.7 | 290.3 | 100.0% | 0.0% (0/10000) | 5/5 | 238.8 | 5/5 |
| SAC büyük ağ, düşük entropi · 800 bin | orijinal | 5 | 279.5 ± 7.4 | 280.6 | 99.9% | 0.0% (0/10000) | 5/5 | 66.3 | 2/5 |
| SAC büyük ağ, düşük entropi · 1,6 milyon | orijinal | 5 | 286.1 ± 2.3 | 286.9 | 100.0% | 0.0% (0/10000) | 5/5 | 213.8 | 5/5 |
| SAC büyük ağ · 800 bin | orijinal | 5 | 229.1 ± 148.6 | 275.5 | 80.0% | 0.1% (9/10000) | 3/5 | -195.8 | 3/5 |
| SAC büyük ağ · 1,6 milyon | orijinal | 5 | 285.3 ± 3.4 | 286.1 | 100.0% | 0.0% (0/10000) | 5/5 | 231.5 | 5/5 |
| SAC frenli (güçlü ceza)† · 800 bin | sert iniş cezası | 5 | 272.3 ± 11.1 | 274.0 | 99.6% | 0.0% (2/10000) | 3/5 | 24.0 | 2/5 |
| SAC frenli (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 285.0 ± 2.8 | 285.9 | 100.0% | 0.0% (0/10000) | 5/5 | 175.4 | 5/5 |
| SAC frenli (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 277.8 ± 3.5 | 279.0 | 99.8% | 0.1% (11/10000) | 3/5 | 23.3 | 1/5 |
| SAC frenli (hafif ceza)† · 1,6 milyon | sert iniş cezası | 5 | 285.2 ± 3.7 | 285.9 | 99.9% | 0.0% (0/10000) | 5/5 | 167.7 | 5/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
