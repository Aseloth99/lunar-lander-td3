# Ana sonuç seçim kuralı v5 (Aşama 7: "hiç çakılmadan 290 üstü?") — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-20 16:16, Aşama 7 eğitimleri BAŞLAMADAN önce. Bu anda `runs/td3/v5big` yoktu; 6800–7199
bağımsız doğrulaması ve 50000+ test bölümleri hiçbir ajan için çalıştırılmamıştı (`FROZEN5` yok). Bu dosya sonradan
değiştirilmeyecek.

**Bağlam:** Şampiyon `td3/v4big@800k` (test 40000–40999: ort. 289,9, 5000 bölümde 0 çakılma, hiçbir bölüm 200 altı
değil). `td3/v4big@1600k` 5000 bölümde ≈291 ama 6 çakılma. Kullanıcının sorusu: "Hiç çakılmadan 290 üstü çıkacak mı?"

**Hipotez (kanıtlanmadı):** Aşama 6'da öğrenme hızı sabitti; geç dönemdeki nadir bozulmalar buna bağlı olabilir.
Öğrenme hızı sona doğru sıfıra inerse, 1,6 milyonun yakıt verimi korunurken sağlamlık geri gelebilir.

**Yeni çeşit:** `td3/v5big` = `td3/v4big` ile birebir aynı (TD3, ağ [400,300], 1,6M adım, orijinal ödül, aynı
eğitim tohumları 0–4). Tek fark: öğrenme hızı doğrusal azalır, 1e-3 → 0 (`configs/td3_v5big.json`, `lr_linear=true`).

**Adaylar** (5'er tohum; "@" sonrası kontrol noktası):
`td3/v4big@800k` (şampiyon), `td3/v4big@1600k`, `td3/v5big@800k`, `td3/v5big@1600k`.

**Kontrol noktası seçimi:** `reselect.py`, yalnızca 5100–5599 doğrulama bölümleriyle; 800k için 400k–800k aralığı,
1600k için 800k–1,6M aralığı (Aşama 6 ile aynı). Not: v5big'in 800k anında öğrenme hızı henüz yarıdadır; bu an
800 binlik ayrı bir eğitimle aynı yöntem değildir, yalnızca aynı koşunun bir anı olarak raporlanır.
v4big'in seçilmiş modelleri (Aşama 6'dan) olduğu gibi kullanılır.

**Sıralama verisi:** yeni bağımsız doğrulama 6800–7199 (tohum başına 400 bölüm; kontrol noktası seçiminde kullanılmaz).

**Kural** (Aşama 6'nın v4 + EK kuralıyla aynı):
1. **Uygunluk:** 5 tohumun hepsinde, 400 bağımsız doğrulama bölümünün HEPSİNDE puan ≥ 200 (başarı %100) VE 0 çakılma.
2. Uygunlar arasında **tohum ortalamalarının ortalaması en yüksek** olan seçilir.
3. Hiçbiri uygun değilse: önce toplam çakılma az, sonra 200 altı bölüm sayısı az, sonra ortalama yüksek olan.

**Test:** Seçimden sonra `FROZEN5` oluşturulur ve tüm adayların tüm koşuları 50000–50099 (resmi) + 50100–50999 (ek)
test bölümlerinde bir kez ölçülür; hepsi raporlanır.

**"290 sorusu"nun cevabı (önceden tanımlı):** Ana sonuç resmi testte (50000–50099, 500 bölüm) **0 çakılma**,
**başarı %100** ve **tohum ortalamalarının ortalaması ≥ 290,0** verirse cevap EVET; biri bile tutmazsa HAYIR ve
ne kadar uzak kaldığı yazılır. 5000 bölümlük genişletilmiş test (50000–50999) için aynı üç ölçüt ayrıca raporlanır.
Sonuç ne çıkarsa çıksın (v5big kazanmasa da) olduğu gibi yazılır.
