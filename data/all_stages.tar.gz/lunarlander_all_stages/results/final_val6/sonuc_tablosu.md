### Sonuçlar — BAĞIMSIZ DOĞRULAMA v5: 6800–7199 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 800 bin | orijinal | 5 | 289.5 ± 0.8 | 290.6 | 100.0% | 0.0% (0/2000) | 5/5 | 241.1 | 5/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 291.0 ± 0.4 | 291.9 | 100.0% | 0.0% (0/2000) | 5/5 | 244.1 | 5/5 |
| TD3 büyük ağ + azalan öğr. hızı · 800 bin | orijinal | 5 | 288.3 ± 0.8 | 289.4 | 99.9% | 0.0% (0/2000) | 5/5 | 171.5 | 5/5 |
| TD3 büyük ağ + azalan öğr. hızı · 1,6 milyon | orijinal | 5 | 290.1 ± 0.3 | 291.1 | 100.0% | 0.0% (0/2000) | 5/5 | 237.6 | 5/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
