### Sonuçlar — İLK TEST tohumları 10000–10099

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| SAC + yakıt cezası† | yakıt cezası 2× | 5 | 273.6 ± 8.7 | 279.3 | 97.8% | 2.2% (11/500) | 0/5 | -116.8 | 0/5 |
| SAC (zoo) | orijinal | 2 | 268.5 ± 101.7 | 273.0 | 98.0% | 2.0% (4/200) | 1/2 | 16.6 | 0/2 |
| PPO (Optuna) | orijinal | 5 | 276.2 ± 6.5 | 280.6 | 98.0% | 2.0% (10/500) | 1/5 | 31.7 | 0/5 |
| TD3 (Optuna) | orijinal | 5 | 219.2 ± 157.6 | 269.0 | 79.8% | 20.0% (100/500) | 4/5 | -105.1 | 1/5 |
| PPO (zoo) | orijinal | 5 | 265.5 ± 8.1 | 268.2 | 98.8% | 1.2% (6/500) | 2/5 | 2.2 | 0/5 |
| TD3 (zoo) | orijinal | 3 | 192.3 ± 209.9 | 234.2 | 69.3% | 6.7% (20/300) | 0/3 | -187.9 | 0/3 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
