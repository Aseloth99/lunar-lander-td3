### Sonuçlar — EN YENİ TEST 40000–40099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v3 uzun (800k) | orijinal | 5 | 287.5 ± 2.0 | 288.1 | 99.8% | 0.2% (1/500) | 4/5 | 97.5 | 4/5 |
| TD3 büyük ağ · 800 bin | orijinal | 5 | 288.5 ± 1.1 | 288.7 | 100.0% | 0.0% (0/500) | 5/5 | 243.2 | 5/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 289.1 ± 1.5 | 289.8 | 99.6% | 0.4% (2/500) | 3/5 | 69.1 | 3/5 |
| TD3 küçük ağ · 800 bin | orijinal | 5 | 287.8 ± 1.3 | 288.2 | 99.8% | 0.2% (1/500) | 4/5 | 87.7 | 4/5 |
| TD3 küçük ağ · 1,6 milyon | orijinal | 5 | 288.8 ± 2.3 | 289.7 | 99.6% | 0.4% (2/500) | 4/5 | 68.5 | 4/5 |
| SAC uzun · 800 bin | orijinal | 5 | 278.6 ± 6.0 | 278.5 | 100.0% | 0.0% (0/500) | 5/5 | 233.1 | 3/5 |
| SAC uzun · 1,6 milyon | orijinal | 5 | 284.1 ± 1.3 | 284.3 | 100.0% | 0.0% (0/500) | 5/5 | 238.2 | 5/5 |
| PPO (Optuna) | orijinal | 5 | 276.5 ± 4.7 | 276.7 | 99.8% | 0.2% (1/500) | 4/5 | 90.8 | 0/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
