### Sonuçlar — EN YENİ TEST 50000–50099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 800 bin | orijinal | 5 | 285.8 ± 0.8 | 285.3 | 100.0% | 0.0% (0/500) | 5/5 | 237.7 | 5/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 287.2 ± 0.4 | 286.4 | 100.0% | 0.0% (0/500) | 5/5 | 241.1 | 5/5 |
| TD3 büyük ağ + azalan öğr. hızı · 800 bin | orijinal | 5 | 284.6 ± 0.8 | 284.0 | 100.0% | 0.0% (0/500) | 5/5 | 236.2 | 5/5 |
| TD3 büyük ağ + azalan öğr. hızı · 1,6 milyon | orijinal | 5 | 286.3 ± 0.4 | 285.6 | 100.0% | 0.0% (0/500) | 5/5 | 238.5 | 5/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
