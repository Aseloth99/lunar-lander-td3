| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 1,6 milyon | 0 | 290.8 | 100% | 0% | 242.3 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 291.1 | 100% | 0% | 241.3 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.5 | 100% | 0% | 74.6 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.2 | 100% | 0% | 69.3 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 4 | 290.7 | 100% | 0% | 71.2 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.1 | 100% | 0% | 181.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.3 | 100% | 0% | 238.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 289.8 | 100% | 0% | 240.6 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.7 | 100% | 0% | 241.0 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.2 | 100% | 0% | 67.4 | ✘ |
| SAC uzun · 1,6 milyon | 0 | 283.0 | 100% | 0% | 236.8 | ✔ |
| SAC uzun · 1,6 milyon | 1 | 284.9 | 100% | 0% | 167.1 | ✔ |
| SAC uzun · 1,6 milyon | 2 | 285.0 | 100% | 0% | 232.7 | ✔ |
| SAC uzun · 1,6 milyon | 3 | 285.0 | 100% | 0% | 232.5 | ✔ |
| SAC uzun · 1,6 milyon | 4 | 284.9 | 100% | 0% | 223.4 | ✔ |
| SAC büyük ağ · 800 bin | 0 | 285.8 | 100% | 0% | 236.2 | ✔ |
| SAC büyük ağ · 800 bin | 1 | 281.3 | 100% | 0% | 58.0 | ✘ |
| SAC büyük ağ · 800 bin | 2 | 279.2 | 100% | 0% | 27.2 | ✘ |
| SAC büyük ağ · 800 bin | 3 | 14.5 | 0% | 0% | -369.1 | ✘ |
| SAC büyük ağ · 800 bin | 4 | 283.5 | 100% | 0% | 181.4 | ✔ |
| SAC büyük ağ · 1,6 milyon | 0 | 286.1 | 100% | 0% | 236.5 | ✔ |
| SAC büyük ağ · 1,6 milyon | 1 | 287.9 | 100% | 0% | 83.4 | ✘ |
| SAC büyük ağ · 1,6 milyon | 2 | 284.9 | 100% | 0% | 232.9 | ✔ |
| SAC büyük ağ · 1,6 milyon | 3 | 281.0 | 100% | 0% | 231.5 | ✔ |
| SAC büyük ağ · 1,6 milyon | 4 | 287.0 | 100% | 0% | 233.9 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 0 | 286.7 | 100% | 0% | 237.1 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 1 | 278.4 | 100% | 0% | -192.5 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 2 | 277.9 | 100% | 0% | 230.0 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 3 | 270.9 | 100% | 0% | -2.5 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 4 | 283.6 | 100% | 0% | 164.1 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 0 | 286.8 | 100% | 0% | 201.8 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 1 | 284.0 | 100% | 0% | 235.7 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 2 | 287.3 | 100% | 0% | 63.5 | ✘ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 3 | 284.2 | 100% | 0% | 234.6 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 4 | 287.7 | 100% | 0% | 239.6 | ✔ |
