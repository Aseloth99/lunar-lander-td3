### Sonuçlar — EN YENİ TEST 80000–81999 (resmi 100 + ek 1900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.7 ± 0.4 | 291.8 | 100.0% | 0.0% (3/10000) | 2/5 | 69.3 | 2/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 289.8 ± 0.6 | 291.1 | 100.0% | 0.0% (1/10000) | 4/5 | 67.4 | 4/5 |
| SAC uzun · 1,6 milyon | orijinal | 5 | 284.6 ± 1.1 | 285.9 | 100.0% | 0.0% (0/10000) | 5/5 | 167.1 | 5/5 |
| SAC büyük ağ · 800 bin | orijinal | 5 | 228.9 ± 148.8 | 275.5 | 79.9% | 0.1% (8/10000) | 2/5 | -369.1 | 2/5 |
| SAC büyük ağ · 1,6 milyon | orijinal | 5 | 285.4 ± 3.3 | 286.7 | 100.0% | 0.0% (1/10000) | 4/5 | 83.4 | 4/5 |
| SAC büyük ağ, düşük entropi · 800 bin | orijinal | 5 | 279.5 ± 7.5 | 281.2 | 99.9% | 0.0% (2/10000) | 4/5 | -192.5 | 2/5 |
| SAC büyük ağ, düşük entropi · 1,6 milyon | orijinal | 5 | 286.0 ± 2.2 | 287.2 | 100.0% | 0.0% (2/10000) | 4/5 | 63.5 | 4/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
