### Sonuçlar — DOĞRULAMA tohumları (test değil)

| Algoritma | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma | En kötü bölüm | Hedefi sağlayan tohum |
|---|---:|---:|---:|---:|---:|---:|---:|
| SAC | 1 | 280.9 – | 282.2 | 100.0% | 0.0% | 236.8 | 1/1 |

_Hedef: HER tohumda 100 bölümde ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
