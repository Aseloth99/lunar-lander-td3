| Algoritma | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm |
|---|---:|---:|---:|---:|---:|
| SAC | 0 | 280.9 | 100% | 0% | 236.8 |
