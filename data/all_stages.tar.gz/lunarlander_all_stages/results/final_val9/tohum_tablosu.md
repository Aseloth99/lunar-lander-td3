| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 1,6 milyon | 0 | 290.7 | 100% | 0% | 241.9 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 290.9 | 100% | 0% | 241.4 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.6 | 100% | 0% | 240.2 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.2 | 100% | 0% | 241.9 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 4 | 290.6 | 100% | 0% | 61.6 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.0 | 100% | 0% | 173.2 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.2 | 100% | 0% | 240.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 289.8 | 100% | 0% | 238.9 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.6 | 100% | 0% | 241.5 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.3 | 100% | 0% | 239.6 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 0 | 289.5 | 100% | 0% | 239.6 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 1 | 290.1 | 100% | 0% | 239.7 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 2 | 289.7 | 100% | 0% | 239.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 3 | 289.1 | 100% | 0% | 241.0 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 4 | 288.7 | 100% | 0% | 241.4 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 0 | 286.7 | 100% | 0% | 238.7 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 1 | 278.1 | 100% | 0% | -185.8 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 2 | 277.5 | 100% | 0% | 11.2 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 3 | 270.9 | 100% | 0% | 172.2 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 4 | 283.6 | 100% | 0% | 166.4 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 0 | 286.7 | 100% | 0% | 214.0 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 1 | 283.8 | 100% | 0% | 159.9 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 2 | 287.4 | 100% | 0% | 43.5 | ✘ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 3 | 284.0 | 100% | 0% | 235.1 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 4 | 287.7 | 100% | 0% | 236.4 | ✔ |
| SAC büyük ağ · 800 bin | 0 | 285.7 | 100% | 0% | 232.4 | ✔ |
| SAC büyük ağ · 800 bin | 1 | 281.3 | 100% | 0% | 68.2 | ✘ |
| SAC büyük ağ · 800 bin | 2 | 279.6 | 100% | 0% | 31.9 | ✘ |
| SAC büyük ağ · 800 bin | 3 | 14.7 | 0% | 0% | -151.3 | ✘ |
| SAC büyük ağ · 800 bin | 4 | 283.4 | 100% | 0% | 231.2 | ✔ |
| SAC büyük ağ · 1,6 milyon | 0 | 286.0 | 100% | 0% | 231.1 | ✔ |
| SAC büyük ağ · 1,6 milyon | 1 | 287.7 | 100% | 0% | 69.3 | ✘ |
| SAC büyük ağ · 1,6 milyon | 2 | 284.8 | 100% | 0% | 234.5 | ✔ |
| SAC büyük ağ · 1,6 milyon | 3 | 280.8 | 100% | 0% | 230.1 | ✔ |
| SAC büyük ağ · 1,6 milyon | 4 | 286.9 | 100% | 0% | 236.5 | ✔ |
| SAC frenli (güçlü ceza)† · 800 bin | 0 | 281.6 | 100% | 0% | 180.8 | ✔ |
| SAC frenli (güçlü ceza)† · 800 bin | 1 | 269.7 | 100% | 0% | 140.9 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 2 | 259.0 | 99% | 0% | 111.7 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 3 | 269.5 | 100% | 0% | 46.5 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 4 | 279.9 | 100% | 0% | 232.8 | ✘ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 0 | 285.4 | 100% | 0% | 237.2 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 1 | 286.4 | 100% | 0% | 235.3 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 2 | 282.9 | 100% | 0% | 228.5 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 3 | 282.5 | 100% | 0% | 234.3 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 4 | 287.7 | 100% | 0% | 238.6 | ✔ |
| SAC frenli (hafif ceza)† · 800 bin | 0 | 279.7 | 100% | 0% | 37.2 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 1 | 276.7 | 100% | 0% | -4.5 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 2 | 276.7 | 100% | 0% | 228.3 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 3 | 274.6 | 100% | 0% | 213.6 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 4 | 282.1 | 100% | 0% | 230.4 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 0 | 288.3 | 100% | 0% | 237.7 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 1 | 282.9 | 100% | 0% | 233.4 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 2 | 281.9 | 100% | 0% | 229.6 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 3 | 284.5 | 100% | 0% | 63.5 | ✘ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 4 | 288.3 | 100% | 0% | 165.6 | ✔ |
