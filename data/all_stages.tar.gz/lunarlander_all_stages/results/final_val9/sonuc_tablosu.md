### Sonuçlar — BAĞIMSIZ DOĞRULAMA v8: 90000–91999 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.6 ± 0.3 | 291.3 | 100.0% | 0.0% (2/10000) | 4/5 | 61.6 | 4/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 289.8 ± 0.7 | 290.6 | 100.0% | 0.0% (0/10000) | 5/5 | 173.2 | 5/5 |
| TD3 erken fren (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 289.4 ± 0.7 | 290.2 | 100.0% | 0.0% (0/10000) | 5/5 | 239.6 | 5/5 |
| SAC büyük ağ, düşük entropi · 800 bin | orijinal | 5 | 279.4 ± 7.5 | 280.7 | 99.9% | 0.1% (5/10000) | 3/5 | -185.8 | 2/5 |
| SAC büyük ağ, düşük entropi · 1,6 milyon | orijinal | 5 | 285.9 ± 2.3 | 286.7 | 100.0% | 0.0% (1/10000) | 4/5 | 43.5 | 4/5 |
| SAC büyük ağ · 800 bin | orijinal | 5 | 228.9 ± 148.7 | 275.5 | 80.0% | 0.1% (7/10000) | 3/5 | -151.3 | 2/5 |
| SAC büyük ağ · 1,6 milyon | orijinal | 5 | 285.2 ± 3.3 | 286.0 | 100.0% | 0.0% (1/10000) | 4/5 | 69.3 | 4/5 |
| SAC frenli (güçlü ceza)† · 800 bin | sert iniş cezası | 5 | 271.9 ± 11.3 | 273.7 | 99.6% | 0.0% (1/10000) | 4/5 | 46.5 | 1/5 |
| SAC frenli (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 285.0 ± 2.8 | 285.9 | 100.0% | 0.0% (0/10000) | 5/5 | 228.5 | 5/5 |
| SAC frenli (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 278.0 ± 3.7 | 278.8 | 99.9% | 0.0% (2/10000) | 4/5 | -4.5 | 1/5 |
| SAC frenli (hafif ceza)† · 1,6 milyon | sert iniş cezası | 5 | 285.2 ± 3.7 | 285.8 | 100.0% | 0.0% (1/10000) | 4/5 | 63.5 | 4/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
