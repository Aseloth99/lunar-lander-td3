# Ana sonuç seçim kuralı v2 (çakılma %0 hedefi) — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-16, Aşama 4 başlarken. Bu anda hiçbir v2 kontrol noktası seçimi, bağımsız doğrulama (5600–5999)
veya yeni test (20000+) sonucu yoktu. Bu dosya sonradan değiştirilmeyecek.

**Bağlam:** Eski test (10000–10099) bir kez kullanıldı ve hedef karşılanmadı. Kullanıcı çakılma %0 istedi. Eski test
bölümleri bundan sonra GELİŞTİRME verisidir (çakılma analizi onlarla yapıldı); yeni iddialar yalnızca yeni test
tohumlarına dayanır.

**Adaylar** (5 tamamlanmış tohum): `sac/fuel2x`, `ppo/tuned`, `td3/tuned`, `td3/v2a`, `td3/v2b`.
Her koşu için kontrol noktası `reselect.py` ile yalnızca 5100–5599 doğrulama bölümleriyle seçilir (`best_policy_v2.pt`).

**Gruplar arası sıralama**, seçimde KULLANILMAYAN bağımsız doğrulama kümesiyle yapılır: 5600–5999 (tohum başına 400
bölüm, seçilmiş kontrol noktası, deterministik). Sırayla, eşitlikte bir sonrakine geçilir:
1. Çakılmasız tohum sayısı: 400 bölümde 0 çakılma VE başarı (≥ 200) ≥ %99 olan tohum sayısı — çok olan önde.
2. 5 tohumdaki toplam çakılma sayısı — az olan önde.
3. Birleşik başarı oranı — yüksek olan önde.
4. Tohum ortalamalarının ortalaması — yüksek olan önde.

Seçim yapıldıktan sonra `FROZEN2` oluşturulur ve TÜM aday grupların tüm koşuları yeni test tohumlarında bir kez
değerlendirilir: resmi test 20000–20099 (100 bölüm, ilk hedef tanımıyla aynı) + ek dayanıklılık testi 20100–20999
(900 bölüm). Hepsi raporlanır.
