# Ana sonuç seçim kuralı v6 (Aşama 8: "erken fren", hedef sıfır çakılma + en yüksek puan) — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-22 08:50, Aşama 8 eğitimleri BAŞLAMADAN önce. (İlk taslak 2026-10-21 14:30'da tek çeşitle
yazılmıştı; o gün eğitim başlatılmadı. Bugün, hâlâ hiçbir eğitim yokken, ikinci çeşit ve sıralama eklendi.) Bu anda
`runs/td3/v6brake` ve `runs/td3/v6soft` yoktu; 7200–9199 bağımsız doğrulaması ve 60000+ test bölümleri hiçbir ajan için
çalıştırılmamıştı (`FROZEN6` yok). Bu dosya bundan sonra değiştirilmeyecek.

**Bağlam:** Aşama 7 ana sonucu `td3/v4big@1600k` (test 50000–50999: ort. 290,1, 5000'de 2 çakılma). Kalan çakılmaların
13'ünün 13'ü sert inişti: yere değme anında dikey hız normal inişlerin en az %99'undan hızlıydı
(`scripts/crash_analysis_v5.py`). Kullanıcı: "Hiç çakılmaması lazım", "en yüksek puan da olsun".

**Yeni çeşitler** (ikisi de `td3/v4big` ile birebir aynı: TD3, ağ [400,300], 1,6M adım, sabit öğrenme hızı, eğitim
tohumları 0–4). Tek fark YALNIZCA EĞİTİM ödülünde: bir bacak bölümde ilk kez yere değdiğinde, temastan hemen önceki
dikey düşüş hızı |vy| v0'ı aşıyorsa k × (|vy| − v0) ceza (`common.TouchdownPenalty`).
- `td3/v6brake`: güçlü ceza, k = 100, v0 = 0,25 (`configs/td3_v6brake.json`)
- `td3/v6soft`: hafif ceza, k = 50, v0 = 0,30 (`configs/td3_v6soft.json`)
Doğrulama ve test HER ZAMAN orijinal ödülle ve değiştirilmemiş ortamla yapılır.

**Adaylar** (5'er tohum): `td3/v4big@800k`, `td3/v4big@1600k`, `td3/v6brake@800k`, `td3/v6brake@1600k`,
`td3/v6soft@800k`, `td3/v6soft@1600k`.

**Kontrol noktası seçimi:** `reselect.py`, yalnızca 5100–5599 doğrulama bölümleriyle; 800k için 400k–800k, 1600k için
800k–1,6M aralığı (Aşama 6–7 ile aynı). v4big'in seçilmiş modelleri olduğu gibi kullanılır.

**Sıralama verisi:** yeni bağımsız doğrulama 7200–9199 (tohum başına **2000** bölüm, grup başına 10 000; çakılma çok nadir
olduğu için öncekilerden 5 kat büyük). Kontrol noktası seçiminde kullanılmaz.

**Kural (önce güvenlik, sonra puan):**
1. **Uygunluk:** 5 tohumun her birinde doğrulama ortalaması ≥ 280 (ilk hedef).
2. Uygunlar arasında önce **toplam çakılma (10 000 bölüm) en az** olan; eşitlikte **200 altı bölüm sayısı en az**;
   eşitlikte **tohum ortalamalarının ortalaması en yüksek** olan seçilir.
3. Hiçbiri uygun değilse aynı sıralama tüm adaylara uygulanır ve raporda yazılır.

**Test:** Seçimden sonra `FROZEN6` oluşturulur; tüm adayların tüm koşuları 60000–60099 (resmi, 100 bölüm) + 60100–61999
(ek, 1900 bölüm) test bölümlerinde bir kez ölçülür (tohum başına 2000, grup başına 10 000); hepsi raporlanır.

**Önceden tanımlı sorular (cevaplar test sonrası olduğu gibi yazılır):**
- **"Sıfır çakılma?"** Ana sonuç genişletilmiş testte (60000–61999, 10 000 bölüm) hiç çakılmazsa EVET; değilse HAYIR ve
  çakılma sayısı. Not: 10 000'de 0 çakılma gerçek oranın sıfır olduğunu kanıtlamaz; kabaca %0,03'ün altında olduğunu
  gösterir.
- **"Puan ne oldu?"** Ana sonucun aynı 10 000 bölümdeki ortalaması; 290'ın üstünde mi.
- Ek (yalnızca tanı, seçimde kullanılmaz): yere değme hızı nasıl değişti; aynı test bölümlerinde v4big'e göre çakılma
  azaldı mı; ceza puanı ne kadar düşürdü.
