# Aşama 1 — zoo ayarlarıyla referans koşuları (DOĞRULAMA tohumları; test tohumlarına bakılmadı)

Ayarlar `rl-baselines3-zoo`'nun `LunarLanderContinuous-v3` girdilerinden birebir alındı (bkz. `configs.py`).
Değerlendirme: 100 doğrulama bölümü (tohum 5000–5099), deterministik politika, doğrulamayla seçilmiş kontrol noktası.

| Algoritma | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma | En kötü bölüm | Hedefi sağlayan tohum |
|---|---:|---:|---:|---:|---:|---:|---:|
| SAC (5e5 adım) | 2 | 268.5 ± 28.9 | 269.0 | 99.5% | 0.5% | 39.5 | 0/2 |
| TD3 (3e5 adım) | 3 | 197.0 ± 193.5 | 232.1 | 70.0% | 7.0% | -192.7 | 0/3 |
| PPO (1e6 adım) | 5 | 262.0 ± 5.9 | 264.8 | 98.8% | 1.0% | 10.9 | 0/5 |

Tohum başına sonuçlar: `tohum_tablosu.md`. Grafikler: `ogrenme_egrileri`, `puan_dagilimi`, `algoritma_karsilastirma` (PNG + SVG).
SAC için yalnızca 2 tohum olduğundan güven aralığı anlamlı değildir (n=2).

## Hedef karşılandı mı? Hayır.

Hedef: her tohumda ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200, sıfır çakılma, en az 5 tohum. Hiçbir koşu bunu sağlamadı
(en iyi tek koşu: SAC tohum 0, ortalama 270.8; en iyi algoritma ortalaması: SAC 268.5).

## Neden? (ödül yapısından ölçüm, `scripts/reward_decomposition.py`)

Bir bölümün getirisi, inen bölümlerde: `R = S_bitiş − S_başlangıç − yakıt + 100`
(S: konum, hız, açı ve bacak teması içeren "şekillendirme" puanı). Aynı 100 doğrulama bölümünde:

| | SAC | PPO | TD3 |
|---|---:|---:|---:|
| ortalama getiri | 268.5 | 262.0 | 241.9 |
| yakıt cezası | 28.3 | 40.6 | 46.6 |
| bitiş potansiyeli (ideal ≈ +20) | 6.8 | 13.6 | 3.1 |
| bölüm uzunluğu (adım) | 227 | 294 | 328 |
| getirisi ≥ 280 olan bölüm | %34 | %26 | %16 |

Başlangıç potansiyeli bu bölümlerde ortalama −191.1 (ilk rastgele itmeye bağlı). Yani kusursuz iniş + sıfır yakıtla
tavan ≈ 100 + 20 + 191 ≈ 311. SAC bundan ≈ 28 yakıt ve ≈ 13 puanlık iniş sapması (pist merkezinden uzaklık/hız) kaybediyor.
Ortalama 280 için bu iki kaybın toplamı ~41'den ~31'in altına inmeli: ana motor yakıtının yaklaşık dörtte biri
daha az harcanması veya daha merkezî iniş. Bu, fiziksel olarak yapılabilir görünse de neredeyse en iyi (yakıt-verimli)
iniş davranışını gerektirir. (Ortamın kendi açıklamasında sezgisel inişin ~−30 yakıt harcadığı yazar.)

Güvenilirlik hedefleri (≥ %99 başarı, 0 çakılma) SAC ve PPO için yakın ama henüz her tohumda sağlanmıyor:
SAC tohum 0'da 1/100, PPO'da 5 tohumun 3'ünde 1–3/100 çakılma var. TD3 zoo ayarıyla kararsız (tohum 0: %32 başarı).

## Sınırlılıklar
- SAC için 2, TD3 için 3 tohum (zaman bütçesi); bu aşamanın amacı referans noktası.
- Öğrenme hızı programı (SAC: doğrusal azalan) eğriyi ~270'te düzleştirmiş olabilir; Aşama 2'de araştırılacak.
