### Sonuçlar — DOĞRULAMA tohumları (test değil)

| Algoritma | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma | En kötü bölüm | Hedefi sağlayan tohum |
|---|---:|---:|---:|---:|---:|---:|---:|
| SAC | 2 | 268.5 ± 28.9 | 269.0 | 99.5% | 0.5% | 39.5 | 0/2 |
| TD3 | 3 | 197.0 ± 193.5 | 232.1 | 70.0% | 7.0% | -192.7 | 0/3 |
| PPO | 5 | 262.0 ± 5.9 | 264.8 | 98.8% | 1.0% | 10.9 | 0/5 |

_Hedef: HER tohumda 100 bölümde ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
