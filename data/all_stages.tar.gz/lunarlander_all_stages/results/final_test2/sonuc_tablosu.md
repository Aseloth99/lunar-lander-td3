### Sonuçlar — YENİ TEST tohumları 20000–20099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v2b (ana sonuç) | orijinal | 5 | 283.1 ± 3.7 | 284.3 | 100.0% | 0.0% (0/500) | 5/5 | 233.2 | 4/5 |
| TD3 v2a | orijinal | 5 | 273.9 ± 7.0 | 275.4 | 99.8% | 0.2% (1/500) | 4/5 | 37.4 | 1/5 |
| PPO (Optuna) | orijinal | 5 | 278.5 ± 6.1 | 279.5 | 99.8% | 0.2% (1/500) | 4/5 | 69.5 | 2/5 |
| SAC + yakıt cezası† | yakıt cezası 2× | 5 | 276.1 ± 7.3 | 278.1 | 99.4% | 0.4% (2/500) | 3/5 | 47.0 | 2/5 |
| TD3 (Optuna) | orijinal | 5 | 201.1 ± 191.9 | 261.6 | 79.8% | 0.0% (0/500) | 5/5 | -125.6 | 1/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
