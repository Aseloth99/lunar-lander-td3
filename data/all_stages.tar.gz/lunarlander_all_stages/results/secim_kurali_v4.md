# Ana sonuç seçim kuralı v4 (sınırları zorlama) — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-18, Aşama 6 eğitimleri yeni başlamışken. Bu anda hiçbir Aşama 6 doğrulama sonucu, 6400–6799
bağımsız doğrulaması veya 40000+ test sonucu yoktu. Bu dosya sonradan değiştirilmeyecek.

**Bağlam:** Şampiyon `td3/v3long` (test 30000–30099: ort. 290.0, 0/500 çakılma). Kullanıcı daha uzun eğitimle sınırları
zorlamak istedi: TD3 büyük ağ 800 bin ve 1,6 milyon, TD3 küçük ağ 1,6 milyon, SAC. Çakılma %0 şartı korunur.
30000–30999 kullanıldı; yeni iddialar 40000+ test tohumlarına dayanır.

**Adaylar** (5'er tohum; "@" sonrası kontrol noktası):
`td3/v3long@v2` (şampiyon), `td3/v4big@800k`, `td3/v4big@1600k`, `td3/v4small@800k`, `td3/v4small@1600k`,
`sac/v4@800k`, `sac/v4@1600k`, `ppo/tuned@v2` (PPO temsilcisi).

**Kontrol noktası seçimi:** `reselect.py`, yalnızca 5100–5599 doğrulama bölümleriyle; 800k için 400k–800k aralığı,
1600k için 800k–1,6M aralığı (sabit öğrenme hızı: 1,6M'lik koşunun 800k anı, 800k'lık bir koşuyla aynı yöntemdir).

**Sıralama verisi:** yeni bağımsız doğrulama 6400–6799 (tohum başına 400 bölüm; seçimde kullanılmaz).

**Kural:**
1. **Uygunluk (güvenlik önce):** 5 tohumun hepsinde 0 çakılma VE her tohumda başarı ≥ %99.
2. Uygunlar arasında **tohum ortalamalarının ortalaması en yüksek** olan seçilir.
3. Hiçbiri uygun değilse: toplam çakılma az olan, eşitlikte ortalama yüksek olan.

Seçimden sonra `FROZEN4` oluşturulur ve tüm adayların tüm koşuları 40000–40099 (resmi) + 40100–40999 (ek) test
bölümlerinde bir kez ölçülür; hepsi raporlanır.
