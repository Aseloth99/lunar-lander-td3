### Sonuçlar — EN YENİ TEST 100000–100099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.9 ± 0.4 | 291.9 | 100.0% | 0.0% (0/500) | 5/5 | 241.1 | 5/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 290.0 ± 0.6 | 291.0 | 100.0% | 0.0% (0/500) | 5/5 | 240.3 | 5/5 |
| TD3 erken fren (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 289.6 ± 0.9 | 290.5 | 100.0% | 0.0% (0/500) | 5/5 | 240.3 | 5/5 |
| SAC büyük ağ, düşük entropi · 800 bin | orijinal | 5 | 279.5 ± 6.7 | 281.0 | 99.8% | 0.0% (0/500) | 5/5 | 66.3 | 2/5 |
| SAC büyük ağ, düşük entropi · 1,6 milyon | orijinal | 5 | 286.3 ± 2.4 | 287.2 | 100.0% | 0.0% (0/500) | 5/5 | 231.0 | 5/5 |
| SAC büyük ağ · 800 bin | orijinal | 5 | 229.1 ± 148.5 | 276.1 | 80.0% | 0.0% (0/500) | 5/5 | -32.7 | 3/5 |
| SAC büyük ağ · 1,6 milyon | orijinal | 5 | 285.5 ± 3.4 | 286.7 | 100.0% | 0.0% (0/500) | 5/5 | 232.3 | 5/5 |
| SAC frenli (güçlü ceza)† · 800 bin | sert iniş cezası | 5 | 272.2 ± 11.7 | 274.5 | 100.0% | 0.0% (0/500) | 5/5 | 206.8 | 1/5 |
| SAC frenli (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 285.2 ± 2.7 | 286.5 | 100.0% | 0.0% (0/500) | 5/5 | 233.5 | 5/5 |
| SAC frenli (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 277.6 ± 3.8 | 279.1 | 99.8% | 0.2% (1/500) | 4/5 | 44.9 | 1/5 |
| SAC frenli (hafif ceza)† · 1,6 milyon | sert iniş cezası | 5 | 285.2 ± 3.7 | 286.3 | 99.8% | 0.0% (0/500) | 5/5 | 182.1 | 5/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
