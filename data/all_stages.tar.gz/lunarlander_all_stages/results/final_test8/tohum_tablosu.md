| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 1,6 milyon | 0 | 290.8 | 100% | 0% | 241.1 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 1 | 291.3 | 100% | 0% | 242.0 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.9 | 100% | 0% | 242.6 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.4 | 100% | 0% | 244.7 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 4 | 291.2 | 100% | 0% | 244.0 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.3 | 100% | 0% | 243.2 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.4 | 100% | 0% | 240.3 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 290.0 | 100% | 0% | 243.2 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.8 | 100% | 0% | 241.9 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.5 | 100% | 0% | 242.9 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 0 | 289.8 | 100% | 0% | 242.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 1 | 290.4 | 100% | 0% | 243.2 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 2 | 290.0 | 100% | 0% | 240.3 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 3 | 288.9 | 100% | 0% | 241.1 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 4 | 288.7 | 100% | 0% | 243.4 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 0 | 287.1 | 100% | 0% | 240.8 | ✔ |
| SAC büyük ağ, düşük entropi · 800 bin | 1 | 279.1 | 100% | 0% | 229.7 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 2 | 277.8 | 100% | 0% | 231.4 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 3 | 272.3 | 100% | 0% | 221.5 | ✘ |
| SAC büyük ağ, düşük entropi · 800 bin | 4 | 281.1 | 99% | 0% | 66.3 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 0 | 286.8 | 100% | 0% | 239.4 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 1 | 284.1 | 100% | 0% | 231.0 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 2 | 287.8 | 100% | 0% | 243.3 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 3 | 284.6 | 100% | 0% | 238.0 | ✔ |
| SAC büyük ağ, düşük entropi · 1,6 milyon | 4 | 288.3 | 100% | 0% | 239.9 | ✔ |
| SAC büyük ağ · 800 bin | 0 | 286.0 | 100% | 0% | 235.1 | ✔ |
| SAC büyük ağ · 800 bin | 1 | 281.5 | 100% | 0% | 230.3 | ✔ |
| SAC büyük ağ · 800 bin | 2 | 279.5 | 100% | 0% | 233.1 | ✘ |
| SAC büyük ağ · 800 bin | 3 | 15.2 | 0% | 0% | -32.7 | ✘ |
| SAC büyük ağ · 800 bin | 4 | 283.1 | 100% | 0% | 234.7 | ✔ |
| SAC büyük ağ · 1,6 milyon | 0 | 286.0 | 100% | 0% | 239.6 | ✔ |
| SAC büyük ağ · 1,6 milyon | 1 | 288.4 | 100% | 0% | 240.2 | ✔ |
| SAC büyük ağ · 1,6 milyon | 2 | 285.1 | 100% | 0% | 234.2 | ✔ |
| SAC büyük ağ · 1,6 milyon | 3 | 281.1 | 100% | 0% | 232.3 | ✔ |
| SAC büyük ağ · 1,6 milyon | 4 | 286.8 | 100% | 0% | 236.0 | ✔ |
| SAC frenli (güçlü ceza)† · 800 bin | 0 | 282.4 | 100% | 0% | 232.8 | ✔ |
| SAC frenli (güçlü ceza)† · 800 bin | 1 | 270.2 | 100% | 0% | 222.0 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 2 | 258.1 | 100% | 0% | 206.8 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 3 | 271.1 | 100% | 0% | 213.0 | ✘ |
| SAC frenli (güçlü ceza)† · 800 bin | 4 | 279.1 | 100% | 0% | 237.3 | ✘ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 0 | 285.4 | 100% | 0% | 238.4 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 1 | 286.7 | 100% | 0% | 237.2 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 2 | 283.3 | 100% | 0% | 235.6 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 3 | 282.9 | 100% | 0% | 233.5 | ✔ |
| SAC frenli (güçlü ceza)† · 1,6 milyon | 4 | 287.9 | 100% | 0% | 238.2 | ✔ |
| SAC frenli (hafif ceza)† · 800 bin | 0 | 279.7 | 100% | 0% | 234.2 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 1 | 276.6 | 100% | 0% | 232.1 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 2 | 274.8 | 99% | 1% | 44.9 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 3 | 275.0 | 100% | 0% | 235.3 | ✘ |
| SAC frenli (hafif ceza)† · 800 bin | 4 | 281.8 | 100% | 0% | 232.6 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 0 | 288.7 | 100% | 0% | 239.8 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 1 | 282.3 | 100% | 0% | 236.2 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 2 | 282.4 | 100% | 0% | 238.8 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 3 | 285.0 | 100% | 0% | 240.1 | ✔ |
| SAC frenli (hafif ceza)† · 1,6 milyon | 4 | 287.7 | 99% | 0% | 182.1 | ✔ |
