### Sonuçlar — EN YENİ TEST 60000–61999 (resmi 100 + ek 1900 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 büyük ağ · 800 bin | orijinal | 5 | 289.4 ± 0.9 | 290.3 | 100.0% | 0.0% (3/10000) | 2/5 | 37.0 | 2/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.7 ± 0.4 | 291.6 | 99.9% | 0.1% (8/10000) | 2/5 | 48.9 | 2/5 |
| TD3 erken fren (güçlü ceza)† · 800 bin | sert iniş cezası | 5 | 288.7 ± 1.5 | 289.7 | 99.9% | 0.0% (1/10000) | 4/5 | 34.2 | 4/5 |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | sert iniş cezası | 5 | 289.9 ± 0.7 | 290.8 | 100.0% | 0.0% (1/10000) | 4/5 | 67.5 | 4/5 |
| TD3 erken fren (hafif ceza)† · 800 bin | sert iniş cezası | 5 | 289.6 ± 0.7 | 290.5 | 100.0% | 0.0% (0/10000) | 5/5 | 239.4 | 5/5 |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | sert iniş cezası | 5 | 290.4 ± 0.5 | 291.3 | 100.0% | 0.0% (3/10000) | 4/5 | 40.1 | 4/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yere hızlı değmeye ek ceza verildi (Aşama 8, kullanıcı isteğiyle). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
