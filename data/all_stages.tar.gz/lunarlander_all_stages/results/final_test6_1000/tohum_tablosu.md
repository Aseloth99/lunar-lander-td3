| Grup | Tohum | Ort. puan | Başarı (≥200) | Çakılma | En kötü bölüm | Hedef |
|---|---:|---:|---:|---:|---:|:---:|
| TD3 büyük ağ · 800 bin | 0 | 288.7 | 100% | 0% | 59.2 | ✘ |
| TD3 büyük ağ · 800 bin | 1 | 289.0 | 100% | 0% | 37.0 | ✘ |
| TD3 büyük ağ · 800 bin | 2 | 290.6 | 100% | 0% | 237.6 | ✔ |
| TD3 büyük ağ · 800 bin | 3 | 289.1 | 100% | 0% | 239.7 | ✔ |
| TD3 büyük ağ · 800 bin | 4 | 289.4 | 100% | 0% | 79.1 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 0 | 290.7 | 100% | 0% | 56.6 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 1 | 291.1 | 100% | 0% | 241.9 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 2 | 290.7 | 100% | 0% | 60.2 | ✘ |
| TD3 büyük ağ · 1,6 milyon | 3 | 290.5 | 100% | 0% | 243.5 | ✔ |
| TD3 büyük ağ · 1,6 milyon | 4 | 290.3 | 100% | 0% | 48.9 | ✘ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 0 | 286.9 | 100% | 0% | 176.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 1 | 290.3 | 100% | 0% | 238.4 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 2 | 288.9 | 100% | 0% | 34.2 | ✘ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 3 | 288.7 | 100% | 0% | 239.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 800 bin | 4 | 288.8 | 100% | 0% | 185.1 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 0 | 289.1 | 100% | 0% | 67.5 | ✘ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 1 | 290.4 | 100% | 0% | 240.7 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 2 | 289.9 | 100% | 0% | 239.5 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 3 | 289.8 | 100% | 0% | 241.4 | ✔ |
| TD3 erken fren (güçlü ceza)† · 1,6 milyon | 4 | 290.5 | 100% | 0% | 239.7 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 0 | 289.6 | 100% | 0% | 239.4 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 1 | 290.4 | 100% | 0% | 239.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 2 | 289.9 | 100% | 0% | 240.8 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 3 | 289.4 | 100% | 0% | 240.4 | ✔ |
| TD3 erken fren (hafif ceza)† · 800 bin | 4 | 288.9 | 100% | 0% | 240.4 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 0 | 290.3 | 100% | 0% | 40.1 | ✘ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 1 | 291.1 | 100% | 0% | 239.1 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 2 | 290.4 | 100% | 0% | 241.1 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 3 | 290.2 | 100% | 0% | 240.7 | ✔ |
| TD3 erken fren (hafif ceza)† · 1,6 milyon | 4 | 289.9 | 100% | 0% | 189.8 | ✔ |
