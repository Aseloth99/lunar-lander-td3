### Sonuçlar — BAĞIMSIZ DOĞRULAMA v3: 6000–6399 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v2b (ana sonuç) | orijinal | 5 | 282.7 ± 3.6 | 283.8 | 99.9% | 0.1% (1/2000) | 4/5 | 82.2 | 3/5 |
| TD3 v3 uzun (800k) | orijinal | 5 | 289.6 ± 1.4 | 290.8 | 100.0% | 0.0% (0/2000) | 5/5 | 140.6 | 5/5 |
| TD3 v3 büyük ağ | orijinal | 5 | 284.5 ± 3.3 | 285.6 | 100.0% | 0.0% (0/2000) | 5/5 | 233.5 | 5/5 |
| TD3 v3 + yakıt cezası† | yakıt cezası 2× | 5 | 283.3 ± 6.7 | 285.5 | 99.6% | 0.3% (6/2000) | 2/5 | -114.5 | 2/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
