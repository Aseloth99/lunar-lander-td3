### Sonuçlar — BAĞIMSIZ DOĞRULAMA v4: 6400–6799 (test değil)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v3 uzun (800k) | orijinal | 5 | 288.5 ± 1.5 | 289.0 | 100.0% | 0.0% (0/2000) | 5/5 | 115.4 | 5/5 |
| TD3 büyük ağ · 800 bin | orijinal | 5 | 289.1 ± 0.9 | 289.5 | 100.0% | 0.0% (0/2000) | 5/5 | 240.9 | 5/5 |
| TD3 büyük ağ · 1,6 milyon | orijinal | 5 | 290.2 ± 0.7 | 290.8 | 99.9% | 0.1% (3/2000) | 3/5 | 43.4 | 3/5 |
| TD3 küçük ağ · 800 bin | orijinal | 5 | 288.6 ± 1.4 | 289.0 | 99.9% | 0.1% (2/2000) | 4/5 | 45.4 | 4/5 |
| TD3 küçük ağ · 1,6 milyon | orijinal | 5 | 289.9 ± 0.6 | 290.6 | 99.9% | 0.1% (3/2000) | 3/5 | 33.7 | 3/5 |
| SAC uzun · 800 bin | orijinal | 5 | 279.3 ± 6.5 | 279.7 | 100.0% | 0.1% (1/2000) | 4/5 | 13.0 | 3/5 |
| SAC uzun · 1,6 milyon | orijinal | 5 | 284.6 ± 1.1 | 285.2 | 100.0% | 0.0% (0/2000) | 5/5 | 235.8 | 5/5 |
| PPO (Optuna) | orijinal | 5 | 277.1 ± 6.1 | 277.8 | 99.8% | 0.2% (5/2000) | 2/5 | 27.4 | 0/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
