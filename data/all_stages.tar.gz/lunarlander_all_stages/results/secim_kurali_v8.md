# Seçim kuralı v8 (Aşama 10: "SAC daha agresif olsun; hem yüksek puan alsın hem çakılmasın") — ÖNCEDEN KAYIT

Yazıldığı an: 2026-10-26, Aşama 10 eğitimleri BAŞLAMADAN önce. Bu anda `runs/sac/v10brake` ve `runs/sac/v10soft`
yoktu; 90000–91999 doğrulaması ve 100000–101999 test bölümleri hiçbir ajan için çalıştırılmamıştı (`FROZEN8` yok).
Aşama 9 sürüyordu (ilk 6 eğitim ~%57); Aşama 9'un bağımsız doğrulaması (70000–71999) ve testi (80000–81999) henüz
çalıştırılmamıştı. Aşama 9'dan görülen tek bilgi, eğitim sırasındaki kısa doğrulama eğrileriydi (5000–5019, 20 bölüm);
yalnızca eğitimin sağlıklı gittiğini görmek için bakıldı. Bu dosya sonradan değiştirilmeyecek.

**Bağlam:** TD3'te eğitimde sert inişe ek ceza ("erken fren", Aşama 8) aynı 10 000 test bölümünde çakılmayı 8'den 1'e
indirdi, bedeli ~0,8 puandı; hafif çeşidin 800 bin adımlık hali 20 000 doğrulama + test bölümünde hiç çakılmadı. SAC'ta
bu hiç denenmedi. Kullanıcı isteği: SAC'ı daha agresif yapmak (puan için) ve aynı anda çakılmayı önlemek.

**Yeni çeşitler** (ikisi de `sac/v9lowent`'in aynısı: SAC, ağ [400,300], γ 0,995, entropi hedefi −4 (agresif: daha az
rastgelelik), lr 3e-4 sabit, tampon 1e6, batch 256, τ 0,01, güncelleme/veri oranı 0,5, 1,6M adım, eğitim tohumları 0–4;
tek fark YALNIZCA eğitimde sert iniş cezası, `common.TouchdownPenalty`; değerlendirme her zaman orijinal ödülle):
- `sac/v10brake`: güçlü ceza, |vy| > 0,25 ise 100 × fark (`configs/sac_v10brake.json`; `td3/v6brake` ile aynı ceza)
- `sac/v10soft`: hafif ceza, |vy| > 0,30 ise 50 × fark (`configs/sac_v10soft.json`; `td3/v6soft` ile aynı ceza)

**Kontrol noktası seçimi:** `reselect.py`, yalnızca 5100–5599 doğrulama bölümleriyle; 800k için 400k–800k, 1600k için
800k–1,6M aralığı (önceki aşamalarla aynı).

**Adaylar (11):**
- Yeni: `sac/v10brake@800k`, `sac/v10brake@1600k`, `sac/v10soft@800k`, `sac/v10soft@1600k`.
- Karşılaştırma (modelleri değişmeden, aynı yeni testte): `td3/v4big@1600k` (en yüksek puanlı TD3), `td3/v6brake@1600k`
  (en güvenli TD3), `td3/v6soft@800k` (20 000 bölümde sıfır çakılmalı TD3), Aşama 9'un dört SAC adayı
  `sac/v9lowent@800k`, `sac/v9lowent@1600k` (yeni çeşitlerin cezasız hali), `sac/v9big@800k`, `sac/v9big@1600k`.

**Sıralama verisi:** yeni bağımsız doğrulama 90000–91999 (tohum başına 2000 bölüm). Kontrol noktası seçiminde
kullanılmaz.

**Kurallar** (uygunluk her ikisinde de: 5 tohumun her birinde doğrulama ortalaması ≥ 280):
1. **Aşama 10 seçimi (frenli SAC'ların en iyisi):** 4 yeni aday arasında uygun olanlardan en az çakılma, eşitlikte en az
   200 altı, eşitlikte en yüksek ortalama. Hiçbiri uygun değilse aynı sıralama uygunluk aranmadan.
2. **Aşama 10 kural seçimi (genel, güvenlik önce; Aşama 8–9 ile aynı kural):** BÜTÜN 11 aday arasında uygun olanlardan en
   az çakılma, eşitlikte en az 200 altı, eşitlikte en yüksek ortalama.

**Test:** Seçimden sonra `FROZEN8` oluşturulur; bütün adayların bütün koşuları 100000–100099 (resmi, 100 bölüm) +
100100–101999 (ek, 1900 bölüm) test bölümlerinde bir kez ölçülür (tohum başına 2000, aday başına 10 000); hepsi
raporlanır.

**Önceden tanımlı sorular (cevaplar olduğu gibi yazılır; hepsi aynı 10 000 test bölümünde):**
- **"Hem yüksek puan hem sıfır çakılma?"** Kural 1'in seçtiği aday için: ortalaması `td3/v4big@1600k`'nın
  ortalamasından düşük değilse VE hiç çakılmadıysa EVET. Değilse HAYIR; iki şartın her biri ayrı ayrı yazılır.
- **"Fren SAC'ta ne kazandırdı, neye mal oldu?"** `sac/v10brake@1600k` ve `sac/v10soft@1600k`, cezasız hali
  `sac/v9lowent@1600k` ile: çakılma sayıları ve ortalama farkı. (800k için de aynı karşılaştırma ayrıca yazılır.)
- **"Güçlü mü hafif mi?"** `@1600k`'da daha az çakılan; eşitlikte ortalaması yüksek olan.
- **"Frenli SAC, en güvenli TD3 kadar güvenli mi?"** Kural 1'in seçtiği adayın çakılması ≤ `td3/v6brake@1600k`'nınki
  ise EVET.
- Ek: Aşama 9 adayları ve TD3'ler için bu, üçüncü bağımsız test (Aşama 8 ve 9 testlerinden sonra); sonuçlar karşılaştırılır.
- Ek (tanı): yakıt, iniş süresi, yere değme hızı (en sert %5), çakılmaların yeniden oynatılması.
