### Sonuçlar — EN YENİ TEST 30000–30099 (resmi, 100 bölüm)

| Grup | Eğitim ödülü | Tohum | Ort. puan ± %95 GA | IQM | Başarı (≥200) | Çakılma (bölüm) | Çakılmasız tohum | En kötü bölüm | Hedefi sağlayan tohum |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TD3 v2b (ana sonuç) | orijinal | 5 | 284.2 ± 3.5 | 284.9 | 100.0% | 0.0% (0/500) | 5/5 | 237.7 | 5/5 |
| TD3 v3 uzun (800k) | orijinal | 5 | 290.0 ± 2.1 | 291.2 | 99.8% | 0.0% (0/500) | 5/5 | 86.0 | 5/5 |
| TD3 v3 büyük ağ | orijinal | 5 | 284.8 ± 4.2 | 286.5 | 99.8% | 0.2% (1/500) | 4/5 | -23.2 | 4/5 |
| TD3 v3 + yakıt cezası† | yakıt cezası 2× | 5 | 283.8 ± 6.8 | 285.6 | 99.6% | 0.2% (1/500) | 4/5 | -19.1 | 3/5 |

_Hedef: HER tohumda (bu kümenin tüm bölümlerinde) ortalama ≥ 280, bölümlerin ≥ %99'u ≥ 200 ve hiç çakılma yok; en az 5 tohum. Resmi tanım 100 bölümlük testtir._
_GA: tohum ortalamaları üzerinden t dağılımıyla %95 güven aralığı (az tohumda geniştir). IQM: tüm bölümler birleşik, alt-üst %25 atılmış ortalama._
_† Eğitim sırasında yakıt cezası 2 katına çıkarıldı (ilk yöntem listesinde yoktu, kullanıcı onayıyla eklendi). Değerlendirme her satırda ORİJİNAL ödülle yapıldı._
